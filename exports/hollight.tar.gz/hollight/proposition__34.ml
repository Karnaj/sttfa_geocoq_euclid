(*proposition__34 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((pG A) C) D) B) ==> ((mat_and ((((cong A) B) C) D)) ((mat_and ((((cong A) C) B) D)) ((mat_and ((((((congA C) A) B) B) D) C)) ((mat_and ((((((congA A) B) D) D) C) A)) ((((((cong__3 C) A) B) B) D) C)))))))))`*)
let proposition__34 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((pG (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
     (MP  
      (DISCH `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
       (MP  
        (DISCH `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
         (MP  
          (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
           (MP  
            (MP  
             (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (x : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
               (SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
             ) (GEN `(M : mat_Point)` 
                (DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                 (MP  
                  (MP  
                   (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                    (SPEC `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                     (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                      (DISCH `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                       (MP  
                        (MP  
                         (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                          (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                           (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                            (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (MP  
                              (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                               (MP  
                                (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))))))) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                 (DISCH `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (DISCH `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                    (MP  
                                     (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                      (MP  
                                       (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                        (MP  
                                         (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `((((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                            (DISCH `mat_not (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                             (MP  
                                              (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                               (DISCH `(((tS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (MP  
                                                 (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (MP  
                                                   (CONV_CONV_rule `((((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                    (DISCH `mat_not (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                     (MP  
                                                      (DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                           (MP  
                                                            (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                             (MP  
                                                              (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                               (DISCH `(((tS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    DISCH `((triangle (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))))) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))) ==> (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (C : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> ((eq (D : mat_Point)) (D : mat_Point)))) ==> (((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ==> ((eq (D : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> ((eq (A : mat_Point)) (A : mat_Point)))) ==> (((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ==> ((eq (A : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesflip
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__26A
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                   ))))
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__29B
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                              ) (MP  
                                                                 (SPEC `(M : mat_Point)` 
                                                                  (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))` 
                                                                   (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                            ) (MP  
                                                               (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                               ) (MP  
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                  ) (
                                                                  ASSUME `mat_not (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                  ))))
                                                          ) (MP  
                                                             (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                  (SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(M : mat_Point)` 
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (lemma__collinearorder
                                                                   )))
                                                                ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                ))))
                                                        ) (MP  
                                                           (MP  
                                                            (SPEC `(B : mat_Point)` 
                                                             (SPEC `(C : mat_Point)` 
                                                              (SPEC `(D : mat_Point)` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                            ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                            )
                                                           ) (ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                           )))
                                                      ) (MP  
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (lemma__ABCequalsCBA
                                                            )))
                                                         ) (MP  
                                                            (SPEC `(D : mat_Point)` 
                                                             (SPEC `(C : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (nCol__notCol)
                                                              ))
                                                            ) (ASSUME `mat_not (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                            )))))
                                                   ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                      (MP  
                                                       (DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                        (MP  
                                                         (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                          (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                           (MP  
                                                            (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                             (DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                (DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                  ) (
                                                                  ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                  )))
                                                               ) (MP  
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                  )))))))
                                                            ) (MP  
                                                               (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                                (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                 (or__intror)
                                                                )
                                                               ) (MP  
                                                                  (SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                                   (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                                   (SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                  ))))))
                                                         ) (SPEC `(B : mat_Point)` 
                                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                                             (eq__refl))))
                                                       ) (MP  
                                                          (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                              (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                               (SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                            ))
                                                          ) (MP  
                                                             (SPEC `(D : mat_Point)` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (lemma__collinearorder
                                                                )))
                                                             ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                             ))))))
                                                 ) (MP  
                                                    (MP  
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(D : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (proposition__29B)))
                                                      )
                                                     ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                     )
                                                    ) (ASSUME `(((tS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                    ))))
                                              ) (MP  
                                                 (SPEC `(M : mat_Point)` 
                                                  (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))))` 
                                                   (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                    (PINST [(`:mat_Point`,`:A`)] [] 
                                                     (ex__intro))))
                                                 ) (MP  
                                                    (MP  
                                                     (SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                      (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                       (conj))
                                                     ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                     )
                                                    ) (MP  
                                                       (MP  
                                                        (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                         (SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                          (conj))
                                                        ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                        )
                                                       ) (MP  
                                                          (SPEC `(A : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (nCol__notCol)))
                                                          ) (ASSUME `mat_not (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                          )))))))
                                           ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                              (MP  
                                               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                  (DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                   (MP  
                                                    (CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point))))))) ==> mat_false` 
                                                     (DISCH `((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (MP  
                                                       (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                        (DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                           (ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                           )
                                                          ) (ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                          )))
                                                       ) (MP  
                                                          (SPEC `(C : mat_Point)` 
                                                           (CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                            (SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                                              (ex__intro))))
                                                          ) (MP  
                                                             (MP  
                                                              (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                (conj))
                                                              ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                              )
                                                             ) (MP  
                                                                (MP  
                                                                 (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                  (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                   (conj))
                                                                 ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                 )
                                                                ) (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                   )))))))
                                                    ) (MP  
                                                       (SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                        (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                         (or__intror))
                                                       ) (MP  
                                                          (SPEC `(mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                           (SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                            (or__introl))
                                                          ) (ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                          )))))
                                                 ) (SPEC `(C : mat_Point)` 
                                                    (PINST [(`:mat_Point`,`:A`)] [] 
                                                     (eq__refl))))
                                               ) (MP  
                                                  (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                       (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                        (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                             (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                              (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                   (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                ))))
                                                          ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                    ))
                                                  ) (MP  
                                                     (SPEC `(A : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (lemma__collinearorder
                                                        )))
                                                     ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                     ))))))
                                         ) (MP  
                                            (CONV_CONV_rule `((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((neq (C : mat_Point)) (D : mat_Point))` 
                                             (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                              (MP  
                                               (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                    (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                                      (ex__ind))))
                                                  ) (GEN `(x : mat_Point)` 
                                                     (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                         (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                          (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                                            (ex__ind))))
                                                        ) (GEN `(x0 : mat_Point)` 
                                                           (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                               (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))))` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (ex__ind)))
                                                               )
                                                              ) (GEN `(x1 : mat_Point)` 
                                                                 (DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x8 : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x9 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x10 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x11 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x12 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x13 : mat_Point. (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x13 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))`
                                                                   ))))
                                                             ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))`
                                                             ))))
                                                       ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                       ))))
                                                 ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                 ))
                                               ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                               )))
                                            ) (ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                            )))
                                       ) (MP  
                                          (CONV_CONV_rule `((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((neq (A : mat_Point)) (B : mat_Point))` 
                                           (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                            (MP  
                                             (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                  (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                    (ex__ind))))
                                                ) (GEN `(x : mat_Point)` 
                                                   (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                       (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                        (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                         (PINST [(`:mat_Point`,`:A`)] [] 
                                                          (ex__ind))))
                                                      ) (GEN `(x0 : mat_Point)` 
                                                         (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                             (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                              (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))))` 
                                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                                (ex__ind))))
                                                            ) (GEN `(x1 : mat_Point)` 
                                                               (DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                   (CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                  ) (
                                                                  GEN `(x2 : mat_Point)` 
                                                                  (DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x8 : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x9 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x10 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x11 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x12 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x13 : mat_Point. (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x13 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))`
                                                                    ))))
                                                                 ) (ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))`
                                                                 ))))
                                                           ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))`
                                                           ))))
                                                     ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                     ))))
                                               ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                               ))
                                             ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                             )))
                                          ) (ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                          )))
                                     ) (MP  
                                        (CONV_CONV_rule `((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                         (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                          (MP  
                                           (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                  (ex__ind))))
                                              ) (GEN `(x : mat_Point)` 
                                                 (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                     (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                      (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                                        (ex__ind))))
                                                    ) (GEN `(x0 : mat_Point)` 
                                                       (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                           (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                            (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))))` 
                                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                                              (ex__ind))))
                                                          ) (GEN `(x1 : mat_Point)` 
                                                             (DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                 (CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                  (SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))` 
                                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                  ))
                                                                ) (GEN `(x2 : mat_Point)` 
                                                                   (DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x8 : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x9 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x10 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x11 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x12 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x13 : mat_Point. (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x13 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))`
                                                                    ))))
                                                               ) (ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))`
                                                               ))))
                                                         ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))`
                                                         ))))
                                                   ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                   ))))
                                             ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                             ))
                                           ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                           )))
                                        ) (ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                        )))
                                   ) (MP  
                                      (DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                          (SPEC `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                           (SPEC `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                 (SPEC `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                  (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                      (SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                       (SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                        (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                            (SPEC `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                             (SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                              (DISCH `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                               (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                               )))
                                                          ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
                                              ))))
                                        ) (ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))))`
                                        ))
                                      ) (MP  
                                         (SPEC `(C : mat_Point)` 
                                          (SPEC `(M : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (lemma__collinearorder)))
                                         ) (ASSUME `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                         )))))
                                ) (MP  
                                   (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))))` 
                                    (SPEC `(eq (B : mat_Point)) (M : mat_Point)` 
                                     (or__intror))
                                   ) (MP  
                                      (SPEC `(mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))))` 
                                       (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                        (or__intror))
                                      ) (MP  
                                         (SPEC `(mat_or (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                          (SPEC `(eq (M : mat_Point)) (C : mat_Point)` 
                                           (or__intror))
                                         ) (MP  
                                            (SPEC `(mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                             (SPEC `((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (or__intror))
                                            ) (MP  
                                               (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                 (or__introl))
                                               ) (ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                               )))))))
                              ) (MP  
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(M : mat_Point)` 
                                   (SPEC `(C : mat_Point)` 
                                    (axiom__betweennesssymmetry)))
                                 ) (ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                 )))))
                        ) (ASSUME `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                        ))))
                  ) (ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                  ))))
            ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
            ))
          ) (MP  
             (MP  
              (SPEC `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
               (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                 (and__ind)))
              ) (DISCH `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                 (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (MP  
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(D : mat_Point)` 
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(A : mat_Point)` (lemma__diagonalsmeet))))
                   ) (ASSUME `(((pG (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                   ))))
             ) (ASSUME `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
             )))
        ) (MP  
           (MP  
            (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
             (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
              (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
               (and__ind)))
            ) (DISCH `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
               (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (MP  
                 (DISCH `(mat_and ((((par (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                  (MP  
                   (MP  
                    (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                     (SPEC `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                      (SPEC `(((par (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `(((par (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                       (DISCH `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                        (MP  
                         (MP  
                          (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                           (SPEC `(((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                            (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                             (DISCH `(((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                              (ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                              )))
                         ) (ASSUME `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                         ))))
                   ) (ASSUME `(mat_and ((((par (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                   ))
                 ) (MP  
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(D : mat_Point)` 
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(A : mat_Point)` (lemma__parallelflip))))
                    ) (ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                    )))))
           ) (ASSUME `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
           )))
      ) (MP  
         (CONV_CONV_rule `((((pG (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> ((mat_and ((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
          (DISCH `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
           (MP  
            (DISCH `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
             (MP  
              (MP  
               (SPEC `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                 (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                  (and__ind)))
               ) (DISCH `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                  (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                   (MP  
                    (MP  
                     (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                      (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                       (conj))
                     ) (ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                     )
                    ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                    ))))
              ) (ASSUME `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
              ))
            ) (ASSUME `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
            )))
         ) (ASSUME `(((pG (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
         )))))))
 ;;


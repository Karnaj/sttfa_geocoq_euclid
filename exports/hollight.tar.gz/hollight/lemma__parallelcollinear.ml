(*lemma__parallelcollinear :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((tP A) B) c) d) ==> ((((col c) d) C) ==> (((neq C) d) ==> ((((tP A) B) C) d))))))))`*)
let lemma__parallelcollinear =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(c : mat_Point)` 
    (GEN `(d : mat_Point)` 
     (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
      (DISCH `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
       (DISCH `(neq (C : mat_Point)) (d : mat_Point)` 
        (MP  
         (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
          (MP  
           (DISCH `(mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))))))` 
            (MP  
             (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
              (ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)`
              )
             ) (MP  
                (DISCH `(mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))))))` 
                 (MP  
                  (DISCH `(mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))))))` 
                   (MP  
                    (MP  
                     (MP  
                      (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                       (SPEC `(mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)))))` 
                        (SPEC `(eq (c : mat_Point)) (d : mat_Point)` 
                         (or__ind)))
                      ) (DISCH `(eq (c : mat_Point)) (d : mat_Point)` 
                         (MP  
                          (CONV_CONV_rule `((mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                           (DISCH `mat_not (mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)))` 
                            (MP  
                             (CONV_CONV_rule `((mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                              (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                               (nNPP))
                             ) (DISCH `mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                (MP  
                                 (CONV_CONV_rule `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                                  (MP  
                                   (SPEC `mat_false` 
                                    (SPEC `(mat_and (mat_not ((eq (c : mat_Point)) (d : mat_Point)))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                     (SPEC `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                                      (and__ind)))
                                   ) (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                                      (DISCH `(mat_and (mat_not ((eq (c : mat_Point)) (d : mat_Point)))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `mat_false` 
                                          (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                           (SPEC `mat_not ((eq (c : mat_Point)) (d : mat_Point))` 
                                            (and__ind)))
                                         ) (DISCH `mat_not ((eq (c : mat_Point)) (d : mat_Point))` 
                                            (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `mat_false` 
                                                (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                 (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                  (and__ind)))
                                               ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                  (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                   (MP  
                                                    (DISCH `mat_false` 
                                                     (MP  
                                                      (DISCH `mat_false` 
                                                       (MP  
                                                        (SPEC `mat_false` 
                                                         (false__ind)
                                                        ) (ASSUME `mat_false`
                                                        ))
                                                      ) (MP  
                                                         (CONV_CONV_rule `(mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))) ==> mat_false` 
                                                          (ASSUME `mat_not (mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)))`
                                                          )
                                                         ) (ASSUME `mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))`
                                                         )))
                                                    ) (MP  
                                                       (CONV_CONV_rule `((eq (c : mat_Point)) (d : mat_Point)) ==> mat_false` 
                                                        (ASSUME `mat_not ((eq (c : mat_Point)) (d : mat_Point))`
                                                        )
                                                       ) (ASSUME `(eq (c : mat_Point)) (d : mat_Point)`
                                                       )))))
                                              ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and (mat_not ((eq (c : mat_Point)) (d : mat_Point)))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                        )))))
                                 ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                 )))))
                          ) (DISCH `mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `mat_false` 
                                (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                  (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `mat_false` 
                                      (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                       (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                        (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `mat_false` 
                                            (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                             (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                              (and__ind)))
                                           ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                              (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                               (MP  
                                                (CONV_CONV_rule `((eq (c : mat_Point)) (d : mat_Point)) ==> mat_false` 
                                                 (ASSUME `(neq (c : mat_Point)) (d : mat_Point)`
                                                 )
                                                ) (ASSUME `(eq (c : mat_Point)) (d : mat_Point)`
                                                ))))
                                          ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                    ))))
                              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                              )))))
                     ) (DISCH `(mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)))))` 
                        (MP  
                         (MP  
                          (MP  
                           (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                            (SPEC `(mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))))` 
                             (SPEC `(eq (c : mat_Point)) (C : mat_Point)` 
                              (or__ind)))
                           ) (DISCH `(eq (c : mat_Point)) (C : mat_Point)` 
                              (MP  
                               (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                (ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                )
                               ) (MP  
                                  (MP  
                                   (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                    (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                      (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                          (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                           (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                            (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                 (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                  (and__ind)))
                                               ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                  (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                   (MP  
                                                    (MP  
                                                     (MP  
                                                      (MP  
                                                       (MP  
                                                        (MP  
                                                         (CONV_CONV_rule `((eq (c : mat_Point)) (C : mat_Point)) ==> (((((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) ==> (((neq (c : mat_Point)) (d : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))) ==> (((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)))))))` 
                                                          (SPEC `(c : mat_Point)` 
                                                           (MP  
                                                            (CONV_CONV_rule `(((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)) ==> ((((col (C : mat_Point)) (d : mat_Point)) (C : mat_Point)) ==> (((neq (C : mat_Point)) (d : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))) ==> (((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> (((((tP (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (d : mat_Point)) ==> ((((col (x : mat_Point)) (d : mat_Point)) (C : mat_Point)) ==> (((neq (x : mat_Point)) (d : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (d : mat_Point))) ==> (((((oS (x : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)))))))))` 
                                                             (SPEC `\ c0 : mat_Point. (((((tP (A : mat_Point)) (B : mat_Point)) (c0 : mat_Point)) (d : mat_Point)) ==> ((((col (c0 : mat_Point)) (d : mat_Point)) (C : mat_Point)) ==> (((neq (c0 : mat_Point)) (d : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c0 : mat_Point)) (d : mat_Point))) ==> (((((oS (c0 : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)))))))` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                                (eq__ind__r))
                                                              ))
                                                            ) (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                               (DISCH `((col (C : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                (DISCH `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                 (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                  (DISCH `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                   (ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                   ))))))))
                                                         ) (ASSUME `(eq (c : mat_Point)) (C : mat_Point)`
                                                         )
                                                        ) (ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                        )
                                                       ) (ASSUME `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                       )
                                                      ) (ASSUME `(neq (c : mat_Point)) (d : mat_Point)`
                                                      )
                                                     ) (ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))`
                                                     )
                                                    ) (ASSUME `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                    ))))
                                              ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                        ))))
                                  ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                  ))))
                          ) (DISCH `(mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))))` 
                             (MP  
                              (MP  
                               (MP  
                                (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                 (SPEC `(mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)))` 
                                  (SPEC `(eq (d : mat_Point)) (C : mat_Point)` 
                                   (or__ind)))
                                ) (DISCH `(eq (d : mat_Point)) (C : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `((mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                     (DISCH `mat_not (mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)))` 
                                      (MP  
                                       (CONV_CONV_rule `((mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                        (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                         (nNPP))
                                       ) (DISCH `mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                          (MP  
                                           (CONV_CONV_rule `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                                            (MP  
                                             (SPEC `mat_false` 
                                              (SPEC `(mat_and (mat_not ((eq (c : mat_Point)) (d : mat_Point)))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                               (SPEC `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                                                (and__ind)))
                                             ) (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                                                (DISCH `(mat_and (mat_not ((eq (c : mat_Point)) (d : mat_Point)))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `mat_false` 
                                                    (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                     (SPEC `mat_not ((eq (c : mat_Point)) (d : mat_Point))` 
                                                      (and__ind)))
                                                   ) (DISCH `mat_not ((eq (c : mat_Point)) (d : mat_Point))` 
                                                      (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `mat_false` 
                                                          (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                            (and__ind)))
                                                         ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                            (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                             (MP  
                                                              (DISCH `mat_false` 
                                                               (MP  
                                                                (SPEC `mat_false` 
                                                                 (false__ind)
                                                                ) (ASSUME `mat_false`
                                                                ))
                                                              ) (MP  
                                                                 (CONV_CONV_rule `(mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))) ==> mat_false` 
                                                                  (ASSUME `mat_not (mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)))`
                                                                  )
                                                                 ) (ASSUME `mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))`
                                                                 )))))
                                                        ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (mat_not ((eq (c : mat_Point)) (d : mat_Point)))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                  )))))
                                           ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                           )))))
                                    ) (DISCH `mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                       (MP  
                                        (DISCH `(eq (C : mat_Point)) (d : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `((eq (C : mat_Point)) (d : mat_Point)) ==> mat_false` 
                                           (ASSUME `(neq (C : mat_Point)) (d : mat_Point)`
                                           )
                                          ) (ASSUME `(eq (C : mat_Point)) (d : mat_Point)`
                                          ))
                                        ) (MP  
                                           (MP  
                                            (SPEC `(eq (C : mat_Point)) (d : mat_Point)` 
                                             (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                              (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                               (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(eq (C : mat_Point)) (d : mat_Point)` 
                                                   (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                    (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                     (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(eq (C : mat_Point)) (d : mat_Point)` 
                                                         (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                          (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                           (and__ind)))
                                                        ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                           (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                            (MP  
                                                             (SPEC `(d : mat_Point)` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (lemma__equalitysymmetric
                                                               ))
                                                             ) (ASSUME `(eq (d : mat_Point)) (C : mat_Point)`
                                                             ))))
                                                       ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                 ))))
                                           ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                           ))))))
                               ) (DISCH `(mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)))` 
                                  (MP  
                                   (MP  
                                    (MP  
                                     (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                      (SPEC `(mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                       (SPEC `((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                        (or__ind)))
                                     ) (DISCH `((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                        (MP  
                                         (DISCH `((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                          (MP  
                                           (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                            (ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                            )
                                           ) (MP  
                                              (MP  
                                               (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                  (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                      (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                       (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                        (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                            (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                             (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                              (and__ind)))
                                                           ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                              (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(d : mat_Point)` 
                                                                  (SPEC `(c : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelcollinear1
                                                                    )))))
                                                                 ) (ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                ))))
                                                          ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                              )))
                                         ) (MP  
                                            (MP  
                                             (SPEC `((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                              (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                    (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                     (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                      (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                          (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                            (and__ind)))
                                                         ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                            (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                             (MP  
                                                              (SPEC `(C : mat_Point)` 
                                                               (SPEC `(c : mat_Point)` 
                                                                (SPEC `(d : mat_Point)` 
                                                                 (axiom__betweennesssymmetry
                                                                 )))
                                                              ) (ASSUME `((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point)`
                                                              ))))
                                                        ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                  ))))
                                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                            ))))
                                    ) (DISCH `(mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                       (MP  
                                        (MP  
                                         (MP  
                                          (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                           (SPEC `((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                            (SPEC `((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                             (or__ind)))
                                          ) (DISCH `((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (DISCH `((betS (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                               (MP  
                                                (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                         (ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                         )
                                                        ) (MP  
                                                           (MP  
                                                            (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                             (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                              (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                               (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                   (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                  (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (d : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__tarskiparallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                           )))
                                                      ) (MP  
                                                         (MP  
                                                          (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                           (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                            (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                             (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                 (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                  (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                   (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelcollinear2
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                         )))
                                                    ) (MP  
                                                       (MP  
                                                        (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                         (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                          (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                           (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                 (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__tarskiparallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                   ) (
                                                                   ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                       )))
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                       (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                        (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                         (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                             (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                              (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                               (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                   (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                  (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelcollinear1
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                     )))
                                                ) (MP  
                                                   (MP  
                                                    (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                     (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                      (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                       (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                           (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                            (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                             (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                 (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                  (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                   (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (c : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__tarskiparallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                               ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                         ))))
                                                   ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                   )))
                                              ) (MP  
                                                 (MP  
                                                  (SPEC `((betS (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                   (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                    (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                     (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((betS (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                         (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                          (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                           (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((betS (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                               (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                 (and__ind)))
                                                              ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                 (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                  (MP  
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                 ))))
                                         ) (DISCH `((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                            (MP  
                                             (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                              (ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                              )
                                             ) (MP  
                                                (MP  
                                                 (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                  (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                    (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                        (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                         (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                          (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                              (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                (and__ind)))
                                                             ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelcollinear2
                                                                    )))))
                                                                   ) (
                                                                   ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                            ))))
                                                      ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                ))))
                                        ) (ASSUME `(mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))`
                                        )))
                                   ) (ASSUME `(mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)))`
                                   )))
                              ) (ASSUME `(mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))))`
                              )))
                         ) (ASSUME `(mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)))))`
                         )))
                    ) (ASSUME `(mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))))))`
                    ))
                  ) (ASSUME `(mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))))))`
                  ))
                ) (ASSUME `(mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))))))`
                )))
           ) (MP  
              (MP  
               (SPEC `(mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))))))` 
                (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)))
               ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                  (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                   (MP  
                    (MP  
                     (SPEC `(mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))))))` 
                      (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                       (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                        (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                         (MP  
                          (MP  
                           (CONV_CONV_rule `((mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))) ==> (((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)))) ==> (((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> ((mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))))))))` 
                            (SPEC `(mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (d : mat_Point)) (C : mat_Point))) ((mat_or (((betS (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_or (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))))))` 
                             (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                              (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                               (and__ind))))
                           ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                              (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                               (ASSUME `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                               )))
                          ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                          ))))
                    ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                    ))))
              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
              )))
         ) (MP  
            (CONV_CONV_rule `((((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
             (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
              (MP  
               (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                (MP  
                 (MP  
                  (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                   (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                    (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind))
                   )
                  ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                     (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                      (MP  
                       (MP  
                        (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                         (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                          (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                           (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                            (MP  
                             (MP  
                              (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                               (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                 (and__ind)))
                              ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                 (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                  (MP  
                                   (MP  
                                    (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                      (conj))
                                    ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                    )
                                   ) (MP  
                                      (MP  
                                       (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                        (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                         (conj))
                                       ) (ASSUME `(neq (c : mat_Point)) (d : mat_Point)`
                                       )
                                      ) (MP  
                                         (MP  
                                          (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                           (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                            (conj))
                                          ) (ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))`
                                          )
                                         ) (ASSUME `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                         ))))))
                             ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                             ))))
                       ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                       ))))
                 ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                 ))
               ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
               )))
            ) (ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)`
            ))))))))))
 ;;


(*lemma__samesidetransitive :  |- `! A : mat_Point. (! B : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (((((oS P) Q) A) B) ==> (((((oS Q) R) A) B) ==> ((((oS P) R) A) B)))))))`*)
let lemma__samesidetransitive =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(P : mat_Point)` 
   (GEN `(Q : mat_Point)` 
    (GEN `(R : mat_Point)` 
     (DISCH `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
      (DISCH `(((oS (Q : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
       (MP  
        (DISCH `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
         (MP  
          (MP  
           (SPEC `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))) ==> (return : bool)))` 
             (SPEC `\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
           ) (GEN `(E : mat_Point)` 
              (DISCH `ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))` 
               (MP  
                (MP  
                 (SPEC `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))) ==> (return : bool)))` 
                   (SPEC `\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(F : mat_Point)` 
                    (DISCH `ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))` 
                     (MP  
                      (MP  
                       (SPEC `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                        (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))) ==> (return : bool)))` 
                         (SPEC `\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))` 
                          (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                       ) (GEN `(G : mat_Point)` 
                          (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))` 
                           (MP  
                            (MP  
                             (SPEC `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                              (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))` 
                               (SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                    (SPEC `(mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))` 
                                     (SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                      (DISCH `(mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                          (SPEC `(mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                           (SPEC `((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                            (DISCH `(mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                 (SPEC `((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                  (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                      (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                       (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                        (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (Q : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))) ==> ((((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                           (DISCH `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `((((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) ==> ((((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                   ) (
                                                                   GEN `(M : mat_Point)` 
                                                                   (DISCH `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))) ==> ((((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))`
                                                                  )))
                                                               ) (ASSUME `(((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                               ))
                                                             ) (MP  
                                                                (MP  
                                                                 (SPEC `(G : mat_Point)` 
                                                                  (SPEC `(Q : mat_Point)` 
                                                                   (SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__planeseparation
                                                                    )))))
                                                                 ) (ASSUME `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                 )
                                                                ) (ASSUME `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                ))))
                                                          ) (MP  
                                                             (SPEC `(E : mat_Point)` 
                                                              (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (Q : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (Q : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))` 
                                                               (SPEC `\ X : mat_Point. ((mat_and (((betS (Q : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (ex__intro))
                                                               ))
                                                             ) (MP  
                                                                (MP  
                                                                 (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                                  (SPEC `((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                   (conj))
                                                                 ) (ASSUME `((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point)`
                                                                 )
                                                                ) (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                   )))))))
                                                    ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))`
                                              ))))
                                        ) (ASSUME `(mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))`
                                        ))))
                                  ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))`
                                  ))))
                            ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))`
                            ))))
                      ) (ASSUME `ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))`
                      ))))
                ) (ASSUME `ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))`
                ))))
          ) (ASSUME `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))`
          ))
        ) (MP  
           (CONV_CONV_rule `((((oS (Q : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))))` 
            (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
             (MP  
              (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
               (MP  
                (MP  
                 (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))) ==> (return : bool)))` 
                   (SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(x : mat_Point)` 
                    (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))` 
                     (MP  
                      (MP  
                       (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                        (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))) ==> (return : bool)))` 
                         (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))` 
                          (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                       ) (GEN `(x0 : mat_Point)` 
                          (DISCH `ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))` 
                           (MP  
                            (MP  
                             (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                              (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))) ==> (return : bool)))` 
                               (SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))` 
                                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                             ) (GEN `(x1 : mat_Point)` 
                                (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                    (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))` 
                                     (SPEC `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                      (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                          (SPEC `(mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))` 
                                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                            (DISCH `(mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                (SPEC `(mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                                 (SPEC `((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                  (DISCH `(mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                      (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                       (SPEC `((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                        (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                            (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                             (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                              (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `((((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))))` 
                                                                 (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                                                  (MP  
                                                                   (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x0 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x5 : mat_Point. ((ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x5 : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))) ==> (ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x1 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x5 : mat_Point. ((ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x5 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x5 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))) ==> (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x5 : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x5 : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x5 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))) ==> (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (G : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x4 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))`
                                                                    ))
                                                                   ) (
                                                                   ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))`
                                                                   )))
                                                                ) (ASSUME `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                ))))
                                                          ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))`
                                              ))))
                                        ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))`
                                        ))))
                                  ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))`
                                  ))))
                            ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))`
                            ))))
                      ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))`
                      ))))
                ) (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))`
                ))
              ) (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))`
              )))
           ) (ASSUME `(((oS (Q : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)`
           )))))))))
 ;;


(*lemma__3__5b :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((betS A) B) D) ==> ((((betS B) C) D) ==> (((betS A) C) D))))))`*)
let lemma__3__5b =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
     (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
      (MP  
       (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
        (MP  
         (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
          (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`)
         ) (MP  
            (MP  
             (SPEC `(D : mat_Point)` 
              (SPEC `(C : mat_Point)` 
               (SPEC `(B : mat_Point)` 
                (SPEC `(A : mat_Point)` (lemma__3__7a))))
             ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
             )
            ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
            )))
       ) (MP  
          (MP  
           (SPEC `(D : mat_Point)` 
            (SPEC `(C : mat_Point)` 
             (SPEC `(B : mat_Point)` 
              (SPEC `(A : mat_Point)` (axiom__innertransitivity))))
           ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
           )
          ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
          ))))))))
 ;;


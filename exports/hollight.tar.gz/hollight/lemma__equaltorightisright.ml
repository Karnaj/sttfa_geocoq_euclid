(*lemma__equaltorightisright :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. ((((per A) B) C) ==> (((((((congA a) b) c) A) B) C) ==> (((per a) b) c))))))))`*)
let lemma__equaltorightisright =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(a : mat_Point)` 
    (GEN `(b : mat_Point)` 
     (GEN `(c : mat_Point)` 
      (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
        (MP  
         (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
          (MP  
           (CONV_CONV_rule `((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
            (DISCH `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
             (MP  
              (MP  
               (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ F : mat_Point. (ex (\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))) ==> (return : bool)))` 
                 (SPEC `\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))` 
                  (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
               ) (GEN `(E : mat_Point)` 
                  (DISCH `ex (\ F : mat_Point. (ex (\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))` 
                   (MP  
                    (MP  
                     (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. (ex (\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool)))` 
                       (SPEC `\ F : mat_Point. (ex (\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))` 
                        (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                     ) (GEN `(F : mat_Point)` 
                        (DISCH `ex (\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                         (MP  
                          (MP  
                           (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (x : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool)))` 
                             (SPEC `\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))` 
                              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                           ) (GEN `(e : mat_Point)` 
                              (DISCH `ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))` 
                               (MP  
                                (MP  
                                 (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool)))` 
                                   (SPEC `\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)
                                    )))
                                 ) (GEN `(f : mat_Point)` 
                                    (DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                        (SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                         (SPEC `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                          (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                              (SPEC `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                               (SPEC `((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                (DISCH `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                    (SPEC `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                     (SPEC `((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                      (DISCH `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                          (SPEC `(mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                           (SPEC `((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point)` 
                                                            (DISCH `(mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                (SPEC `(mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                 (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                  (DISCH `(mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((per (E : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ W : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point))))) ==> (return : bool))) ==> ((ex (\ W : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ W : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(W : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (E : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (E : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (W : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (W : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ w : mat_Point. ((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (b : mat_Point)) (w : mat_Point)) (e : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((((cong (b : mat_Point)) (x : mat_Point)) (e : mat_Point)) (b : mat_Point))) ==> (return : bool))) ==> ((ex (\ w : mat_Point. ((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (b : mat_Point)) (w : mat_Point)) (e : mat_Point)) (b : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ w : mat_Point. ((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (b : mat_Point)) (w : mat_Point)) (e : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(w : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (e : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (b : mat_Point)) (w : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (w : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (e : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (e : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (w : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (b : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (w : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (w : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (f : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (f : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (w : mat_Point)) (E : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (f : mat_Point)) (w : mat_Point)) (F : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (b : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (b : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (f : mat_Point)) (W : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (W : mat_Point)) (F : mat_Point)) (w : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (f : mat_Point)) (w : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (e : mat_Point)) (b : mat_Point)) (X : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (e : mat_Point)) (f : mat_Point)) (X : mat_Point)) (f : mat_Point))) ((neq (b : mat_Point)) (f : mat_Point))))))) ==> (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `((per (e : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (f : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (e : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (c : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (c : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__8__3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (c : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (e : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (e : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__8__3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (e : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (f : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (e : mat_Point)) (b : mat_Point)) (x : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (e : mat_Point)) (f : mat_Point)) (x : mat_Point)) (f : mat_Point))) ((neq (b : mat_Point)) (f : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (e : mat_Point)) (b : mat_Point)) (X : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (e : mat_Point)) (f : mat_Point)) (X : mat_Point)) (f : mat_Point))) ((neq (b : mat_Point)) (f : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (e : mat_Point)) (b : mat_Point)) (X : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (e : mat_Point)) (f : mat_Point)) (X : mat_Point)) (f : mat_Point))) ((neq (b : mat_Point)) (f : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (e : mat_Point)) (f : mat_Point)) (w : mat_Point)) (f : mat_Point))) ((neq (b : mat_Point)) (f : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (e : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (e : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (e : mat_Point)) (f : mat_Point)) (w : mat_Point)) (f : mat_Point))) ((neq (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (e : mat_Point)) (f : mat_Point)) (w : mat_Point)) (f : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (f : mat_Point)) (w : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (f : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (f : mat_Point)) (W : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (W : mat_Point)) (F : mat_Point)) (w : mat_Point)) (f : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (W : mat_Point)) (F : mat_Point)) (w : mat_Point)) (f : mat_Point))) ((((cong (w : mat_Point)) (f : mat_Point)) (W : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (W : mat_Point)) (F : mat_Point)) (w : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (w : mat_Point)) (f : mat_Point)) (W : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (W : mat_Point)) (F : mat_Point)) (w : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (W : mat_Point)) (F : mat_Point)) (w : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (w : mat_Point)) (f : mat_Point)) (W : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (W : mat_Point)) (F : mat_Point)) (w : mat_Point)) (f : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (W : mat_Point)) (F : mat_Point)) (w : mat_Point)) (f : mat_Point))) ((((cong (w : mat_Point)) (f : mat_Point)) (W : mat_Point)) (F : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (f : mat_Point)) (w : mat_Point)) (F : mat_Point)) (W : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (f : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (b : mat_Point)) (e : mat_Point)) (w : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (w : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (w : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (b : mat_Point)) (e : mat_Point)) (w : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (e : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (e : mat_Point)) (b : mat_Point)) (w : mat_Point)) (b : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (b : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (b : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (w : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (b : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    axiom__5__line
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (w : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (f : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (f : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (e : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (b : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (b : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (w : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (e : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (w : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (W : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (W : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (B : mat_Point)) (W : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (w : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (b : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (e : mat_Point)) (b : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (e : mat_Point)) (b : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (e : mat_Point)) (b : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (e : mat_Point)) (b : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (e : mat_Point)) (b : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (e : mat_Point)) (b : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (e : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (b : mat_Point)) (w : mat_Point)) (e : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ w : mat_Point. ((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (b : mat_Point)) (w : mat_Point)) (e : mat_Point)) (b : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (e : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (e : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__nocollapse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (E : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ W : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (W : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (F : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (F : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__8__3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (F : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__8__3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))`
                                            ))))
                                      ) (ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))`
                                      ))))
                                ) (ASSUME `ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))`
                                ))))
                          ) (ASSUME `ex (\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))`
                          ))))
                    ) (ASSUME `ex (\ F : mat_Point. (ex (\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))`
                    ))))
              ) (ASSUME `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ e : mat_Point. (ex (\ f : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (f : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))`
              )))
           ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
           ))
         ) (MP  
            (SPEC `(C : mat_Point)` 
             (SPEC `(B : mat_Point)` 
              (SPEC `(A : mat_Point)` 
               (SPEC `(c : mat_Point)` 
                (SPEC `(b : mat_Point)` 
                 (SPEC `(a : mat_Point)` (lemma__equalanglessymmetric))))))
            ) (ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
            ))))))))))
 ;;


(*lemma__samesidecollinear :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! P : mat_Point. (! Q : mat_Point. (((((oS P) Q) A) B) ==> ((((col A) B) C) ==> (((neq A) C) ==> ((((oS P) Q) A) C))))))))`*)
let lemma__samesidecollinear =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(P : mat_Point)` 
    (GEN `(Q : mat_Point)` 
     (DISCH `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
      (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
        (MP  
         (DISCH `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
          (MP  
           (MP  
            (SPEC `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))) ==> (return : bool)))` 
              (SPEC `\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))))` 
               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
            ) (GEN `(p : mat_Point)` 
               (DISCH `ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))` 
                (MP  
                 (MP  
                  (SPEC `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))) ==> (return : bool)))` 
                    (SPEC `\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))` 
                     (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                  ) (GEN `(q : mat_Point)` 
                     (DISCH `ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))` 
                      (MP  
                       (MP  
                        (SPEC `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))) ==> (return : bool)))` 
                          (SPEC `\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))` 
                           (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                        ) (GEN `(r : mat_Point)` 
                           (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))` 
                            (MP  
                             (MP  
                              (SPEC `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                               (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                                (SPEC `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                 (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                      (SPEC `((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point)` 
                                       (DISCH `(mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                            (SPEC `((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                             (DISCH `(mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                  (SPEC `((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                   (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                        (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                         (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                            (MP  
                                                             (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                              (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))))) ==> ((((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                 (DISCH `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))))))))))))) ==> ((((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (A : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (C : mat_Point)) (q : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (C : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (q : mat_Point))) ((mat_and (((col (B : mat_Point)) (q : mat_Point)) (A : mat_Point))) ((mat_and (((col (q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (q : mat_Point)) (B : mat_Point))) (((col (q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (q : mat_Point)) (A : mat_Point))) ((mat_and (((col (q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (q : mat_Point)) (B : mat_Point))) (((col (q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (q : mat_Point)) (A : mat_Point))) ((mat_and (((col (q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (q : mat_Point)) (B : mat_Point))) (((col (q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (q : mat_Point)) (B : mat_Point))) (((col (q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (q : mat_Point)) (B : mat_Point))) (((col (q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (q : mat_Point)) (B : mat_Point))) (((col (q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (q : mat_Point)) (B : mat_Point))) (((col (q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (q : mat_Point)) (B : mat_Point))) (((col (q : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (q : mat_Point)) (B : mat_Point))) (((col (q : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (q : mat_Point)) (A : mat_Point))) ((mat_and (((col (q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (q : mat_Point)) (B : mat_Point))) (((col (q : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (q : mat_Point))) ((mat_and (((col (B : mat_Point)) (q : mat_Point)) (A : mat_Point))) ((mat_and (((col (q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (q : mat_Point)) (B : mat_Point))) (((col (q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (C : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                   ))))))
                                                                ) (MP  
                                                                   (SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                   )))))
                                                             ) (SPEC `(A : mat_Point)` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (eq__refl)))
                                                            )
                                                           ) (MP  
                                                              (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point))))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                  (SPEC `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point)))))` 
                                                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (A : mat_Point))))))`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(Q : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                 ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                 ))))))
                                                     ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))`
                                               ))))
                                         ) (ASSUME `(mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))`
                                         ))))
                                   ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))`
                                   ))))
                             ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))`
                             ))))
                       ) (ASSUME `ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))`
                       ))))
                 ) (ASSUME `ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))`
                 ))))
           ) (ASSUME `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))`
           ))
         ) (MP  
            (CONV_CONV_rule `((((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))))))` 
             (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
              (MP  
               (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                (MP  
                 (MP  
                  (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))) ==> (return : bool)))` 
                    (SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))))` 
                     (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                  ) (GEN `(x : mat_Point)` 
                     (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))` 
                      (MP  
                       (MP  
                        (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                         (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))) ==> (return : bool)))` 
                          (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))` 
                           (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                        ) (GEN `(x0 : mat_Point)` 
                           (DISCH `ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))` 
                            (MP  
                             (MP  
                              (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                               (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))) ==> (return : bool)))` 
                                (SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))` 
                                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                              ) (GEN `(x1 : mat_Point)` 
                                 (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                     (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                                      (SPEC `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                       (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                           (SPEC `(mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                            (SPEC `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                             (DISCH `(mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                                 (SPEC `(mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                                  (SPEC `((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                   (DISCH `(mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                                       (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                        (SPEC `((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                         (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                                             (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                              (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                               (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                (MP  
                                                                 (SPEC `(x0 : mat_Point)` 
                                                                  (CONV_CONV_rule `! x2 : mat_Point. ((ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x2 : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))) ==> (ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))))` 
                                                                   (SPEC `\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(x1 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x2 : mat_Point. ((ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x2 : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))) ==> (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x2 : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))) ==> (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (r : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))))))
                                                               ))
                                                           ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))`
                                               ))))
                                         ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))`
                                         ))))
                                   ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))`
                                   ))))
                             ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))`
                             ))))
                       ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))`
                       ))))
                 ) (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))`
                 ))
               ) (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))`
               )))
            ) (ASSUME `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
            ))))))))))
 ;;


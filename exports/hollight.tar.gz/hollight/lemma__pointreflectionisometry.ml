(*lemma__pointreflectionisometry :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! P : mat_Point. (! Q : mat_Point. ((((midpoint A) B) C) ==> ((((midpoint P) B) Q) ==> (((neq A) P) ==> ((((cong A) P) C) Q))))))))`*)
let lemma__pointreflectionisometry =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(P : mat_Point)` 
    (GEN `(Q : mat_Point)` 
     (DISCH `((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
      (DISCH `((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
       (DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
        (MP  
         (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
          (MP  
           (DISCH `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
            (MP  
             (DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
              (ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
              )
             ) (MP  
                (DISCH `(mat_or (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                 (MP  
                  (DISCH `(mat_or (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                   (MP  
                    (DISCH `(mat_or (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                     (MP  
                      (MP  
                       (MP  
                        (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                         (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                          (SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                           (or__ind)))
                        ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                           (MP  
                            (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))))` 
                             (MP  
                              (DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                               (ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                               )
                              ) (MP  
                                 (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))))` 
                                  (MP  
                                   (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))))` 
                                    (MP  
                                     (MP  
                                      (MP  
                                       (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                        (SPEC `(mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))))` 
                                         (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                          (or__ind)))
                                       ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> mat_false) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                            (DISCH `mat_not (mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)))` 
                                             (MP  
                                              (CONV_CONV_rule `((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> mat_false) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                               (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                (nNPP))
                                              ) (DISCH `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `mat_false` 
                                                    (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `mat_false` 
                                                          (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                           (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                            (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                             (MP  
                                                              (DISCH `mat_false` 
                                                               (MP  
                                                                (SPEC `mat_false` 
                                                                 (false__ind)
                                                                ) (ASSUME `mat_false`
                                                                ))
                                                              ) (MP  
                                                                 (CONV_CONV_rule `(mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> mat_false` 
                                                                  (ASSUME `mat_not (mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)))`
                                                                  )
                                                                 ) (ASSUME `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                                 )))))
                                                        ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                  )))))
                                           ) (DISCH `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                              (MP  
                                               (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (MP  
                                                 (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                  (MP  
                                                   (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                    (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                    )
                                                   ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                   ))
                                                 ) (MP  
                                                    (MP  
                                                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                      (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                       (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                        (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                            (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                             (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (MP  
                                                                (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                   )))))
                                                          ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                    )))
                                               ) (MP  
                                                  (MP  
                                                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                     (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                      (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                             (MP  
                                                              (CONV_CONV_rule `(((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                               (MP  
                                                                (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                  (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                   (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                              ) (ASSUME `((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                  ))))))
                                      ) (DISCH `(mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))))` 
                                         (MP  
                                          (MP  
                                           (MP  
                                            (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                             (SPEC `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))` 
                                              (SPEC `(eq (A : mat_Point)) (P : mat_Point)` 
                                               (or__ind)))
                                            ) (DISCH `(eq (A : mat_Point)) (P : mat_Point)` 
                                               (MP  
                                                (CONV_CONV_rule `((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> mat_false) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                 (DISCH `mat_not (mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)))` 
                                                  (MP  
                                                   (CONV_CONV_rule `((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> mat_false) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                    (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                     (nNPP))
                                                   ) (DISCH `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `mat_false` 
                                                         (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `mat_false` 
                                                               (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                 (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (CONV_CONV_rule `((eq (A : mat_Point)) (P : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(eq (A : mat_Point)) (P : mat_Point)`
                                                                   )))))
                                                             ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                       )))))
                                                ) (DISCH `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                   (MP  
                                                    (CONV_CONV_rule `((eq (A : mat_Point)) (P : mat_Point)) ==> mat_false` 
                                                     (ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                                     )
                                                    ) (ASSUME `(eq (A : mat_Point)) (P : mat_Point)`
                                                    )))))
                                           ) (DISCH `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))` 
                                              (MP  
                                               (MP  
                                                (MP  
                                                 (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                  (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                                   (SPEC `(eq (B : mat_Point)) (P : mat_Point)` 
                                                    (or__ind)))
                                                 ) (DISCH `(eq (B : mat_Point)) (P : mat_Point)` 
                                                    (MP  
                                                     (CONV_CONV_rule `((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> mat_false) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                      (DISCH `mat_not (mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)))` 
                                                       (MP  
                                                        (CONV_CONV_rule `((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> mat_false) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                         (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                          (nNPP))
                                                        ) (DISCH `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `mat_false` 
                                                              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                   (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                                    )))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                            )))))
                                                     ) (DISCH `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                        (MP  
                                                         (DISCH `(neq (P : mat_Point)) (B : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(neq (B : mat_Point)) (P : mat_Point)` 
                                                            (MP  
                                                             (CONV_CONV_rule `((eq (B : mat_Point)) (P : mat_Point)) ==> mat_false` 
                                                              (ASSUME `(neq (B : mat_Point)) (P : mat_Point)`
                                                              )
                                                             ) (ASSUME `(eq (B : mat_Point)) (P : mat_Point)`
                                                             ))
                                                           ) (MP  
                                                              (MP  
                                                               (SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                 (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                  (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (P : mat_Point)) ==> ((((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((neq (P : mat_Point)) (B : mat_Point)) ==> ((neq (B : mat_Point)) (P : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((midpoint (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> ((((midpoint (P : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> ((((betS (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> ((((betS (P : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (P : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) ==> (((neq (P : mat_Point)) (P : mat_Point)) ==> ((neq (P : mat_Point)) (P : mat_Point)))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (P : mat_Point)) ==> ((((midpoint (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((midpoint (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((betS (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (x : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> (((neq (P : mat_Point)) (x : mat_Point)) ==> ((neq (x : mat_Point)) (P : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. ((((midpoint (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B0 : mat_Point)) (Q : mat_Point)) ==> ((((betS (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((betS (P : mat_Point)) (B0 : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (P : mat_Point)) ==> (((neq (P : mat_Point)) (B0 : mat_Point)) ==> ((neq (B0 : mat_Point)) (P : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((midpoint (A : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((midpoint (P : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (P : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (P : mat_Point)) (P : mat_Point)`
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                              )))
                                                         ) (MP  
                                                            (MP  
                                                             (SPEC `(neq (P : mat_Point)) (B : mat_Point)` 
                                                              (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                               (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (P : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                            ))))))
                                                ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                       (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                        (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                         (or__ind)))
                                                      ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                               (MP  
                                                                (DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    DISCH `(((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ H25 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H25 : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (H25 : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ H26 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ H26 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (Q : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__differenceofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (H26 : mat_Point)) ==> ((((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> ((((out (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> ((((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((midpoint (A : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) ==> (((((lt (H26 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((lt (H26 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (H26 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> (((((lt (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> ((((out (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point)) ==> ((((out (B : mat_Point)) (Q : mat_Point)) (H26 : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> ((((betS (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point)) ==> (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (H26 : mat_Point)) ==> ((((midpoint (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((lt (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((lt (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((lt (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((out (B : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((out (B : mat_Point)) (Q : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> ((((betS (B : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. ((((midpoint (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (B : mat_Point)) (C0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) ==> (((((lt (C0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((lt (C0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (C0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((lt (B : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> ((((out (B : mat_Point)) (C0 : mat_Point)) (Q : mat_Point)) ==> ((((out (B : mat_Point)) (Q : mat_Point)) (C0 : mat_Point)) ==> (((((cong (B : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> ((((betS (B : mat_Point)) (C0 : mat_Point)) (Q : mat_Point)) ==> (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(H26 : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((midpoint (A : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H26 : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (H26 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (H26 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (H26 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H26 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (Q : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (H26 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H26 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (H26 : mat_Point)) ==> ((((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> ((((out (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((midpoint (A : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) ==> (((((lt (H26 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((lt (H26 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (H26 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> (((((lt (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> ((((out (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point)) ==> ((((out (B : mat_Point)) (Q : mat_Point)) (H26 : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> (((betS (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (H26 : mat_Point)) ==> ((((midpoint (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((lt (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((lt (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((lt (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((out (B : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((out (B : mat_Point)) (Q : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> (((betS (B : mat_Point)) (x : mat_Point)) (Q : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. ((((midpoint (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (B : mat_Point)) (C0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) ==> (((((lt (C0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((lt (C0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (C0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((lt (B : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> ((((out (B : mat_Point)) (C0 : mat_Point)) (Q : mat_Point)) ==> ((((out (B : mat_Point)) (Q : mat_Point)) (C0 : mat_Point)) ==> (((((cong (B : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) (H26 : mat_Point)) ==> (((betS (B : mat_Point)) (C0 : mat_Point)) (Q : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(H26 : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((midpoint (A : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H26 : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (H26 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (H26 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (H26 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H26 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (Q : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (H26 : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (H26 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H26 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H26 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (Q : mat_Point)) (H26 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H26 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H26 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__3__7a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H26 : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H26 : mat_Point)) (Q : mat_Point))) (((betS (B : mat_Point)) (Q : mat_Point)) (H26 : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (H26 : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (H26 : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ H25 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H25 : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (H25 : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H25 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H25 : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (H25 : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)))) ==> (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (ex (\ H27 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H27 : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (H27 : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `ex (\ H27 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H27 : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (H27 : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (P : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                   (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                  )))
                                                                ) (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                   )))
                                                              ) (MP  
                                                                 (MP  
                                                                  (SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                   (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                  (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                 )))
                                                            ) (MP  
                                                               (MP  
                                                                (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                 (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                  (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                   (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                               )))
                                                          ) (MP  
                                                             (MP  
                                                              (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                 (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                             ))))
                                                     ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                            (SPEC `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                             (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                              (or__ind)))
                                                           ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> mat_false) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                (DISCH `mat_not (mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)))` 
                                                                 (MP  
                                                                  (CONV_CONV_rule `((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> mat_false) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                   (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (nNPP))
                                                                  ) (
                                                                  DISCH `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                   )))))
                                                               ) (DISCH `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `((((betS (B : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (P : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (Q : mat_Point)) (A : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((midpoint (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point)))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (x : mat_Point))) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (x : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ Q0 : mat_Point. ((((midpoint (P : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q0 : mat_Point))) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (B : mat_Point)) (Q0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q0 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((midpoint (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (P : mat_Point)) (C : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (P : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((midpoint (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((midpoint (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (A : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ P0 : mat_Point. ((((midpoint (P0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (P0 : mat_Point)) ==> (((((cong (P0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (P0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P0 : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (P0 : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P0 : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> (((((cong (B : mat_Point)) (P0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (P0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (P0 : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P0 : mat_Point)) (C : mat_Point)) (A : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((midpoint (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(eq (P : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (P : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (P : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (Q : mat_Point)) (A : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((midpoint (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point)))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (x : mat_Point))) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ Q0 : mat_Point. ((((midpoint (P : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q0 : mat_Point))) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (B : mat_Point)) (Q0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((midpoint (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (P : mat_Point)) (C : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (P : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((midpoint (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((midpoint (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (A : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ P0 : mat_Point. ((((midpoint (P0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (P0 : mat_Point)) ==> (((((cong (P0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (P0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P0 : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (P0 : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P0 : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> (((((cong (B : mat_Point)) (P0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (P0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P0 : mat_Point)) (C : mat_Point)) (A : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((midpoint (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (P : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (P : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (P : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__extensionunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (P : mat_Point)) (C : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((neq (A : mat_Point)) (P : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((betS (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((midpoint (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((neq (A : mat_Point)) (C : mat_Point)) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((midpoint (x : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((betS (x : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ P0 : mat_Point. ((((midpoint (P0 : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((neq (A : mat_Point)) (P0 : mat_Point)) ==> ((((betS (P0 : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (P0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P0 : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (P0 : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P0 : mat_Point))) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> (((((cong (B : mat_Point)) (P0 : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((betS (P0 : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((midpoint (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (P : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (P : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (P : mat_Point)) (C : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((neq (A : mat_Point)) (P : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((midpoint (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((neq (A : mat_Point)) (C : mat_Point)) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((midpoint (x : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ P0 : mat_Point. ((((midpoint (P0 : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((neq (A : mat_Point)) (P0 : mat_Point)) ==> ((((betS (P0 : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (P0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> ((mat_not ((((cong (A : mat_Point)) (P0 : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (P0 : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P0 : mat_Point))) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P0 : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((midpoint (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (P : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (P : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__outerconnectivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (P : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    axiom__innertransitivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))))
                                                                   ) (
                                                                   DISCH `((betS (B : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__3__7a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (P : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))))))
                                                          ) (DISCH `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                               (MP  
                                                                (DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (Q : mat_Point)) (B : mat_Point))))) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    DISCH `(((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ H27 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H27 : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (H27 : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ==> (return : bool))) ==> ((ex (\ H28 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H28 : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (Q : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ H28 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H28 : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (H28 : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (H28 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (H28 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (Q : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((((cong (P : mat_Point)) (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((((cong (P : mat_Point)) (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((((cong (P : mat_Point)) (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((((cong (P : mat_Point)) (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((((cong (P : mat_Point)) (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__differenceofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (Q : mat_Point)) (H28 : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((lt (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> ((((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> (((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((midpoint (P : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) ==> (((((lt (H28 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((lt (H28 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (H28 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> (((((lt (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (H28 : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> ((((betS (B : mat_Point)) (H28 : mat_Point)) (C : mat_Point)) ==> (((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (H28 : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((lt (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((lt (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((lt (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> ((((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ Q0 : mat_Point. ((((midpoint (P : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (B : mat_Point)) (Q0 : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) ==> (((((lt (Q0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((lt (Q0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (Q0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((lt (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> ((((betS (B : mat_Point)) (Q0 : mat_Point)) (C : mat_Point)) ==> (((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `(H28 : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((midpoint (P : mat_Point)) (B : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H28 : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (H28 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (H28 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (H28 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H28 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (H28 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (H28 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (H28 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (Q : mat_Point)) (H28 : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((lt (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> (((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((midpoint (P : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) ==> (((((lt (H28 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((lt (H28 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (H28 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> (((((lt (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (H28 : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> (((betS (B : mat_Point)) (H28 : mat_Point)) (C : mat_Point))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (H28 : mat_Point)) ==> ((((midpoint (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((lt (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((lt (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((lt (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ Q0 : mat_Point. ((((midpoint (P : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> ((((betS (P : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (B : mat_Point)) (Q0 : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((((cong (B : mat_Point)) (P : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) ==> (((((lt (Q0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((lt (Q0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (Q0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((lt (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (H28 : mat_Point)) ==> (((betS (B : mat_Point)) (Q0 : mat_Point)) (C : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(H28 : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((midpoint (P : mat_Point)) (B : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H28 : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (H28 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (H28 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (H28 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H28 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (H28 : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (B : mat_Point)) (H28 : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (H28 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (H28 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H28 : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (H28 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (H28 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(H28 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H28 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H28 : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (H28 : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (H28 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (H28 : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__3__6a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (H28 : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (H28 : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ H27 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H27 : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (H27 : mat_Point)) (B : mat_Point)) (Q : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H27 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H27 : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (H27 : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((lt (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ==> (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (ex (\ H29 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H29 : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (H29 : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))` 
                                                                    (
                                                                    SPEC `ex (\ H29 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H29 : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (H29 : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((lt (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (Q : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                   (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                  )))
                                                                ) (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                   )))
                                                              ) (MP  
                                                                 (MP  
                                                                  (SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                   (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                  (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                 ))))
                                                         ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))`
                                                         )))
                                                    ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))`
                                                    )))
                                               ) (ASSUME `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))`
                                               )))
                                          ) (ASSUME `(mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))))`
                                          )))
                                     ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))))`
                                     ))
                                   ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))))`
                                   ))
                                 ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))))`
                                 )))
                            ) (MP  
                               (MP  
                                (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))))` 
                                 (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                  (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                   (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                    (MP  
                                     (MP  
                                      (CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))) ==> (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))))))` 
                                       (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))))` 
                                        (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (and__ind))))
                                      ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                          )))
                                     ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                     ))))
                               ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                               ))))
                       ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                          (MP  
                           (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (MP  
                             (DISCH `((nCol (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (MP  
                               (DISCH `(((((congA (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                (MP  
                                 (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                  (MP  
                                   (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (MP  
                                     (DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                      (MP  
                                       (DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                        (ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                        )
                                       ) (MP  
                                          (MP  
                                           (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                            (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                             (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                              (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                  (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))` 
                                                       (MP  
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(Q : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (SPEC `(P : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))`
                                                                ))))))
                                                          ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                          )
                                                         ) (ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                         )
                                                        ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                        ))
                                                      ) (GEN `(A0 : mat_Point)` 
                                                         (GEN `(B0 : mat_Point)` 
                                                          (GEN `(C0 : mat_Point)` 
                                                           (GEN `(a : mat_Point)` 
                                                            (GEN `(b : mat_Point)` 
                                                             (GEN `(c : mat_Point)` 
                                                              (DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                               (DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                (DISCH `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                   (DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                  )))))))))))
                                                      ))))
                                                ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                ))))
                                          ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                          )))
                                     ) (MP  
                                        (MP  
                                         (SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                          (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                           (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                            (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                        (SPEC `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                         (SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                          (DISCH `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                              (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                 (ASSUME `(((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                 )))
                                                            ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point))`
                                                            ))))
                                                      ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)))`
                                                      ))
                                                    ) (MP  
                                                       (SPEC `(Q : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(P : mat_Point)` 
                                                           (lemma__congruenceflip
                                                           ))))
                                                       ) (ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                       )))))
                                              ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                        )))
                                   ) (MP  
                                      (MP  
                                       (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                         (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                          (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                       (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                        (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                             (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                               (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                               )))
                                                          ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                    ))
                                                  ) (MP  
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (lemma__congruenceflip
                                                         ))))
                                                     ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                     )))))
                                            ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                      )))
                                 ) (MP  
                                    (MP  
                                     (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                      (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                       (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                        (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                         (MP  
                                          (MP  
                                           (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                            (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(Q : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(C : mat_Point)` 
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(B : mat_Point)` 
                                                      (SPEC `(Q : mat_Point)` 
                                                       (SPEC `(P : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (lemma__equalanglestransitive
                                                          )))))))))
                                                 ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                 )
                                                ) (ASSUME `(((((congA (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                ))))
                                          ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                    )))
                               ) (MP  
                                  (MP  
                                   (SPEC `(((((congA (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                    (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                     (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                      (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((((congA (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(Q : mat_Point)` 
                                                 (lemma__ABCequalsCBA)))
                                              ) (ASSUME `((nCol (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                              ))))
                                        ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                        ))))
                                  ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                  )))
                             ) (MP  
                                (MP  
                                 (SPEC `((nCol (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                   (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                    (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                     (MP  
                                      (MP  
                                       (SPEC `((nCol (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (SPEC `(Q : mat_Point)` 
                                               (nCol__notCol)))
                                            ) (MP  
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (SPEC `(Q : mat_Point)` 
                                                  (nCol__not__Col)))
                                               ) (MP  
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(Q : mat_Point)` 
                                                     (SPEC `(P : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (lemma__equalanglesNC
                                                        ))))))
                                                  ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                  ))))))
                                      ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                )))
                           ) (MP  
                              (MP  
                               (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                 (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                  (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                   (MP  
                                    (MP  
                                     (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (MP  
                                          (MP  
                                           (MP  
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(Q : mat_Point)` 
                                              (SPEC `(P : mat_Point)` 
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (proposition__15a)))))
                                            ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                            )
                                           ) (ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                           )
                                          ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                          ))))
                                    ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                    ))))
                              ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                              ))))
                      ) (ASSUME `(mat_or (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                      ))
                    ) (ASSUME `(mat_or (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                    ))
                  ) (ASSUME `(mat_or (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                  ))
                ) (SPEC `(P : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (col__or__nCol))))))
           ) (MP  
              (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
               (MP  
                (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                 (MP  
                  (MP  
                   (SPEC `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                    (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (MP  
                        (CONV_CONV_rule `(((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                         (DISCH `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                          (MP  
                           (DISCH `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                            (MP  
                             (MP  
                              (SPEC `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                               (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                 (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                  (MP  
                                   (CONV_CONV_rule `(((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                    (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                     (MP  
                                      (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                 (conj))
                                               ) (ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                               )
                                              ) (ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                              ))))
                                        ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                        ))
                                      ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                      )))
                                   ) (ASSUME `((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                   ))))
                             ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                             ))
                           ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                           )))
                        ) (ASSUME `((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                        ))))
                  ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                  ))
                ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                ))
              ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
              )))
         ) (MP  
            (CONV_CONV_rule `(((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
             (DISCH `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
              (MP  
               (DISCH `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                (MP  
                 (MP  
                  (SPEC `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                   (SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                    (SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                     (DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                      (MP  
                       (CONV_CONV_rule `(((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                        (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                         (MP  
                          (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                           (MP  
                            (MP  
                             (SPEC `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (MP  
                                  (MP  
                                   (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (conj))
                                   ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                   )
                                  ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                  ))))
                            ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                            ))
                          ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                          )))
                       ) (ASSUME `((midpoint (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                       ))))
                 ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                 ))
               ) (ASSUME `(mat_and (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
               )))
            ) (ASSUME `((midpoint (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
            ))))))))))
 ;;


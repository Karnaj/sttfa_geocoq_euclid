(*lemma__supplements2 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! J : mat_Point. (! K : mat_Point. (! L : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (((((((rT A) B) C) P) Q) R) ==> (((((((congA A) B) C) J) K) L) ==> (((((((rT J) K) L) D) E) F) ==> ((mat_and ((((((congA P) Q) R) D) E) F)) ((((((congA D) E) F) P) Q) R))))))))))))))))`*)
let lemma__supplements2 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(J : mat_Point)` 
       (GEN `(K : mat_Point)` 
        (GEN `(L : mat_Point)` 
         (GEN `(P : mat_Point)` 
          (GEN `(Q : mat_Point)` 
           (GEN `(R : mat_Point)` 
            (DISCH `(((((rT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
             (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (J : mat_Point)) (K : mat_Point)) (L : mat_Point)` 
              (DISCH `(((((rT (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
               (MP  
                (DISCH `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                 (MP  
                  (MP  
                   (SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                    (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))) ==> (return : bool)))` 
                     (SPEC `\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))))))` 
                      (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                   ) (GEN `(a : mat_Point)` 
                      (DISCH `ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))` 
                       (MP  
                        (MP  
                         (SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (x : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (x : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (x : mat_Point)) (e : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))) ==> (return : bool)))` 
                           (SPEC `\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))))` 
                            (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                         ) (GEN `(b : mat_Point)` 
                            (DISCH `ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))` 
                             (MP  
                              (MP  
                               (SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (x : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))) ==> (return : bool)))` 
                                 (SPEC `\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))` 
                                  (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)))
                                )
                               ) (GEN `(c : mat_Point)` 
                                  (DISCH `ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (x : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x : mat_Point)) (b : mat_Point)) (e : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))) ==> (return : bool)))` 
                                       (SPEC `\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))` 
                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                         (ex__ind))))
                                     ) (GEN `(d : mat_Point)` 
                                        (DISCH `ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))) ==> (return : bool)))` 
                                             (SPEC `\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))` 
                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                               (ex__ind))))
                                           ) (GEN `(e : mat_Point)` 
                                              (DISCH `(mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                  (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))` 
                                                   (SPEC `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                    (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                        (SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                         (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                          (DISCH `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                           (MP  
                                                            (DISCH `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (x : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                 (SPEC `\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point))))))))))))` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (ex__ind))
                                                                 ))
                                                               ) (GEN `(j : mat_Point)` 
                                                                  (DISCH `ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (x : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (x : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (x : mat_Point)) (n : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(k : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (x : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (x : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(l : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (x : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x : mat_Point)) (k : mat_Point)) (n : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(m : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(n : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (J : mat_Point)) (K : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (m : mat_Point)) (k : mat_Point)) (n : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(n : mat_Point)` 
                                                                    (
                                                                    SPEC `(k : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (m : mat_Point)) (k : mat_Point)) (n : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(n : mat_Point)` 
                                                                    (
                                                                    SPEC `(k : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(n : mat_Point)` 
                                                                    (
                                                                    SPEC `(k : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(n : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(k : mat_Point)` 
                                                                    (
                                                                    SPEC `(j : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__supplements
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(k : mat_Point)` 
                                                                    (
                                                                    SPEC `(j : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (J : mat_Point)) (K : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (J : mat_Point)) (K : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))`
                                                                    ))))
                                                              ) (ASSUME `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))`
                                                              ))
                                                            ) (MP  
                                                               (CONV_CONV_rule `((((((rT (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point))))))))))))))` 
                                                                (DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                 (MP  
                                                                  (DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((rT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> (ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point))))))))))))))` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (Z : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x8 : mat_Point. (((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x9 : mat_Point. ((ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (x9 : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x9 : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))) ==> (ex (\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ j : mat_Point. (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (j : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (j : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x0 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x9 : mat_Point. ((ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x9 : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x9 : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (x9 : mat_Point)) (n : mat_Point)))))))))) ==> (ex (\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (x : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ k : mat_Point. (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (x : mat_Point)) (k : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (k : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (k : mat_Point)) (n : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x2 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x9 : mat_Point. ((ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x9 : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x9 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (x0 : mat_Point)) (n : mat_Point)))))))) ==> (ex (\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (x0 : mat_Point)) (n : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ l : mat_Point. (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (l : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (l : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (x0 : mat_Point)) (n : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x3 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x9 : mat_Point. ((ex (\ n : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x9 : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x9 : mat_Point)) (x0 : mat_Point)) (n : mat_Point)))))) ==> (ex (\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (x0 : mat_Point)) (n : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ m : mat_Point. (ex (\ n : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (m : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (m : mat_Point)) (x0 : mat_Point)) (n : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x1 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x9 : mat_Point. (((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x9 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x9 : mat_Point)))) ==> (ex (\ n : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (n : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ n : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (n : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (n : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (Z : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((rT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
                                                                    ))
                                                                  ) (
                                                                  ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
                                                                  )))
                                                               ) (ASSUME `(((((rT (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                               )))))
                                                      ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))`
                                                ))))
                                          ) (ASSUME `ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))`
                                          ))))
                                    ) (ASSUME `ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))`
                                    ))))
                              ) (ASSUME `ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))`
                              ))))
                        ) (ASSUME `ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))`
                        ))))
                  ) (ASSUME `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))`
                  ))
                ) (MP  
                   (CONV_CONV_rule `((((((rT (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))))))))` 
                    (DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                     (MP  
                      (DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                       (MP  
                        (MP  
                         (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))) ==> (return : bool)))` 
                           (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))))` 
                            (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                         ) (GEN `(x : mat_Point)` 
                            (DISCH `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))` 
                             (MP  
                              (MP  
                               (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool)))` 
                                 (SPEC `\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))` 
                                  (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)))
                                )
                               ) (GEN `(x0 : mat_Point)` 
                                  (DISCH `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                      (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool)))` 
                                       (SPEC `\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point))))))))` 
                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                         (ex__ind))))
                                     ) (GEN `(x1 : mat_Point)` 
                                        (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                            (CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))) ==> (return : bool)))` 
                                             (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))))))` 
                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                               (ex__ind))))
                                           ) (GEN `(x2 : mat_Point)` 
                                              (DISCH `ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                  (CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))) ==> (return : bool)))` 
                                                   (SPEC `\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))))` 
                                                    (PINST [(`:mat_Point`,`:A`)] [] 
                                                     (ex__ind))))
                                                 ) (GEN `(x3 : mat_Point)` 
                                                    (DISCH `(mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                        (SPEC `(mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                         (SPEC `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                          (DISCH `(mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                              (SPEC `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                               (SPEC `(((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                                (DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                 (MP  
                                                                  (CONV_CONV_rule `((((((rT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> (ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))))))))` 
                                                                   (DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (Z : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x8 : mat_Point. (((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x4 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x9 : mat_Point. ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x9 : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x9 : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))) ==> (ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x5 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x9 : mat_Point. ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x9 : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x9 : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (x9 : mat_Point)) (e : mat_Point)))))))))) ==> (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x7 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x9 : mat_Point. ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x9 : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x9 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (x5 : mat_Point)) (e : mat_Point)))))))) ==> (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (x5 : mat_Point)) (e : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (c : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (x5 : mat_Point)) (e : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x8 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x9 : mat_Point. ((ex (\ e : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x9 : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x9 : mat_Point)) (x5 : mat_Point)) (e : mat_Point)))))) ==> (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (x5 : mat_Point)) (e : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (x5 : mat_Point)) (e : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x6 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x9 : mat_Point. (((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (x9 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x9 : mat_Point)))) ==> (ex (\ e : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (e : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ e : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (e : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (x6 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (x6 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (x8 : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x7 : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x6 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (x5 : mat_Point)) (Z : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
                                                                    )))
                                                                  ) (
                                                                  ASSUME `(((((rT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                  ))))
                                                            ) (ASSUME `(mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))`
                                                      ))))
                                                ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))`
                                                ))))
                                          ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))`
                                          ))))
                                    ) (ASSUME `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))`
                                    ))))
                              ) (ASSUME `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))`
                              ))))
                        ) (ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
                        ))
                      ) (ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
                      )))
                   ) (ASSUME `(((((rT (J : mat_Point)) (K : mat_Point)) (L : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                   )))))))))))))))))
 ;;


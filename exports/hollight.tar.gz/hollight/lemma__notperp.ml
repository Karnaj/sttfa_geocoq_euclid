(*lemma__notperp :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! P : mat_Point. ((((betS A) C) B) ==> ((((nCol A) B) P) ==> (ex (\ X : mat_Point. ((mat_and (((nCol A) B) X)) ((mat_and ((((oS X) P) A) B)) (mat_not (((per A) C) X)))))))))))`*)
let lemma__notperp =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(P : mat_Point)` 
    (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
     (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
      (MP  
       (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
        (MP  
         (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
          (MP  
           (CONV_CONV_rule `(((eq (C : mat_Point)) (P : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))` 
            (DISCH `mat_not ((eq (C : mat_Point)) (P : mat_Point))` 
             (MP  
              (DISCH `ex (\ Q : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (P : mat_Point))))` 
               (MP  
                (MP  
                 (SPEC `ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (P : mat_Point))) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (P : mat_Point))))) ==> (return : bool)))` 
                   (SPEC `\ Q : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(Q : mat_Point)` 
                    (DISCH `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (P : mat_Point))` 
                     (MP  
                      (MP  
                       (SPEC `ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))` 
                        (SPEC `(((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                         (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                          (DISCH `(((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `(((eq (P : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))` 
                             (DISCH `mat_not ((eq (P : mat_Point)) (Q : mat_Point))` 
                              (MP  
                               (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))))` 
                                (MP  
                                 (MP  
                                  (SPEC `ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))` 
                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (Q : mat_Point))) ((((cong (x : mat_Point)) (P : mat_Point)) (x : mat_Point)) (Q : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))))) ==> (return : bool)))` 
                                    (SPEC `\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__ind))))
                                  ) (GEN `(M : mat_Point)` 
                                     (DISCH `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (SPEC `ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))` 
                                         (SPEC `(((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                          (SPEC `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                           (DISCH `(((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                            (MP  
                                             (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))` 
                                              (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                               (MP  
                                                (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                   (MP  
                                                    (CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))` 
                                                     (DISCH `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                      (MP  
                                                       (DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                        (MP  
                                                         (DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(((oS (P : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `((betS (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `((out (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ R : mat_Point. (((((perp__at (M : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((((((perp__at (M : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (return : bool))) ==> ((ex (\ R : mat_Point. (((((perp__at (M : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ R : mat_Point. (((((perp__at (M : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(R : mat_Point)` 
                                                                    (
                                                                    DISCH `((((perp__at (M : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((perp__at (M : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `ex (\ E : mat_Point. ((mat_and (((col (M : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((col (M : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((per (x : mat_Point)) (R : mat_Point)) (M : mat_Point))))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((col (M : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ E : mat_Point. ((mat_and (((col (M : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (M : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (M : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (M : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    DISCH `mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((oS (x : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (R : mat_Point)) (C : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((neq (R : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (M : mat_Point)) (C : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((eq (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (Q : mat_Point)) (M : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((per (Q : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (Q : mat_Point)) (R : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (B : mat_Point)) (E : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((neq (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (A : mat_Point)) (E : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (Q : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (M : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not (((per (Q : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((per (Q : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((per (Q : mat_Point)) (M : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (Q : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__8__7
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (M : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((per (Q : mat_Point)) (R : mat_Point)) (M : mat_Point)) ==> (! y : mat_Point. (((eq (R : mat_Point)) (y : mat_Point)) ==> (((per (Q : mat_Point)) (y : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (((per (Q : mat_Point)) (X : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((per (Q : mat_Point)) (R : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (R : mat_Point)) (C : mat_Point))) ==> ((eq (R : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (C : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (R : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (E : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (R : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__trans
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__sym))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (R : mat_Point)) (C : mat_Point))) ==> ((eq (R : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (C : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (R : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (B : mat_Point)) (E : mat_Point))) ==> ((eq (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (E : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (! y : mat_Point. (((eq (B : mat_Point)) (y : mat_Point)) ==> (((col (A : mat_Point)) (y : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (((col (A : mat_Point)) (X : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (B : mat_Point)) (E : mat_Point))) ==> ((eq (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (E : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (E : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((col (R : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> (((col (A : mat_Point)) (E : mat_Point)) (x : mat_Point))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (((col (A : mat_Point)) (E : mat_Point)) (X : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (! y : mat_Point. (((eq (B : mat_Point)) (y : mat_Point)) ==> (((col (A : mat_Point)) (y : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (((col (A : mat_Point)) (X : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (B : mat_Point)) (E : mat_Point))) ==> ((eq (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (E : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (R : mat_Point)) (C : mat_Point))) ==> ((eq (R : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (C : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (R : mat_Point)) (C : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (Q : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (M : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not (((per (Q : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((per (Q : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((per (Q : mat_Point)) (M : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (Q : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__8__7
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (M : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((per (Q : mat_Point)) (R : mat_Point)) (M : mat_Point)) ==> (! y : mat_Point. (((eq (R : mat_Point)) (y : mat_Point)) ==> (((per (Q : mat_Point)) (y : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (((per (Q : mat_Point)) (X : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((per (Q : mat_Point)) (R : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (R : mat_Point)) (C : mat_Point))) ==> ((eq (R : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (C : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (R : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (E : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (R : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (E : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (E : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (E : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (E : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (E : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (Q : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__trans
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__sym))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (R : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__sym))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (R : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (R : mat_Point)) (C : mat_Point))) ==> ((eq (R : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (C : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (R : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (Q : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (Q : mat_Point)) (M : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (Q : mat_Point)) (M : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (M : mat_Point)) (C : mat_Point))) ==> ((mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (M : mat_Point)) (C : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (C : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (C : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (C : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(eq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (M : mat_Point)) (R : mat_Point))) ==> ((((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (M : mat_Point)) (C : mat_Point)) ==> ((((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> ((((betS (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) ==> ((((out (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> ((((((perp__at (M : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (M : mat_Point)) (R : mat_Point)) (R : mat_Point)) ==> ((((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)) ==> ((((per (M : mat_Point)) (R : mat_Point)) (E : mat_Point)) ==> ((mat_not ((eq (M : mat_Point)) (R : mat_Point))) ==> ((((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> (((((cong (C : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> ((((betS (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> ((((out (Q : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> (((((oS (P : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((oS (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((((((perp__at (C : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (C : mat_Point)) (R : mat_Point)) (R : mat_Point)) ==> ((((per (E : mat_Point)) (R : mat_Point)) (C : mat_Point)) ==> ((((per (C : mat_Point)) (R : mat_Point)) (E : mat_Point)) ==> ((mat_not ((eq (C : mat_Point)) (R : mat_Point))) ==> ((((per (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((betS (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> (((((cong (x : mat_Point)) (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((betS (Q : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point)) ==> (((((oS (P : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((oS (x : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ==> ((((((perp__at (x : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (x : mat_Point)) (R : mat_Point)) (R : mat_Point)) ==> ((((per (E : mat_Point)) (R : mat_Point)) (x : mat_Point)) ==> ((((per (x : mat_Point)) (R : mat_Point)) (E : mat_Point)) ==> ((mat_not ((eq (x : mat_Point)) (R : mat_Point))) ==> ((((per (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ M0 : mat_Point. ((((betS (P : mat_Point)) (M0 : mat_Point)) (Q : mat_Point)) ==> (((((cong (M0 : mat_Point)) (P : mat_Point)) (M0 : mat_Point)) (Q : mat_Point)) ==> ((((betS (Q : mat_Point)) (M0 : mat_Point)) (P : mat_Point)) ==> ((((out (Q : mat_Point)) (P : mat_Point)) (M0 : mat_Point)) ==> (((((oS (P : mat_Point)) (M0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((oS (M0 : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (M0 : mat_Point))) ==> ((((((perp__at (M0 : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (M0 : mat_Point)) (R : mat_Point)) (R : mat_Point)) ==> ((((per (E : mat_Point)) (R : mat_Point)) (M0 : mat_Point)) ==> ((((per (M0 : mat_Point)) (R : mat_Point)) (E : mat_Point)) ==> ((mat_not ((eq (M0 : mat_Point)) (R : mat_Point))) ==> ((((per (A : mat_Point)) (C : mat_Point)) (M0 : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (M0 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (Q : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (P : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((((perp__at (C : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (C : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(eq (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((perp__at (M : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (R : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (M : mat_Point)) (R : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (M : mat_Point)) (R : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `(neq (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (R : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not (((per (M : mat_Point)) (R : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (R : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (M : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((per (M : mat_Point)) (R : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((per (M : mat_Point)) (R : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (M : mat_Point)) (R : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (R : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (R : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (R : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (R : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (R : mat_Point))) (((col (E : mat_Point)) (R : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (R : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (R : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (R : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (R : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (P : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (P : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (C : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__8__7
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (R : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (R : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (C : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (C : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(eq (M : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (M : mat_Point)) (R : mat_Point)) ==> ((((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> ((((betS (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) ==> ((((out (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> ((((((perp__at (M : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (M : mat_Point)) (R : mat_Point)) (R : mat_Point)) ==> ((((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)) ==> ((((per (M : mat_Point)) (R : mat_Point)) (E : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> (((((cong (R : mat_Point)) (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((betS (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)) ==> ((((out (Q : mat_Point)) (P : mat_Point)) (R : mat_Point)) ==> (((((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((oS (R : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ==> ((((((perp__at (R : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (R : mat_Point)) (R : mat_Point)) (R : mat_Point)) ==> ((((per (E : mat_Point)) (R : mat_Point)) (R : mat_Point)) ==> ((((per (R : mat_Point)) (R : mat_Point)) (E : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (R : mat_Point)) ==> ((((betS (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> (((((cong (x : mat_Point)) (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((betS (Q : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point)) ==> (((((oS (P : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((oS (x : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ==> ((((((perp__at (x : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (x : mat_Point)) (R : mat_Point)) (R : mat_Point)) ==> ((((per (E : mat_Point)) (R : mat_Point)) (x : mat_Point)) ==> ((((per (x : mat_Point)) (R : mat_Point)) (E : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ M0 : mat_Point. ((((betS (P : mat_Point)) (M0 : mat_Point)) (Q : mat_Point)) ==> (((((cong (M0 : mat_Point)) (P : mat_Point)) (M0 : mat_Point)) (Q : mat_Point)) ==> ((((betS (Q : mat_Point)) (M0 : mat_Point)) (P : mat_Point)) ==> ((((out (Q : mat_Point)) (P : mat_Point)) (M0 : mat_Point)) ==> (((((oS (P : mat_Point)) (M0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((oS (M0 : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (M0 : mat_Point))) ==> ((((((perp__at (M0 : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (M0 : mat_Point)) (R : mat_Point)) (R : mat_Point)) ==> ((((per (E : mat_Point)) (R : mat_Point)) (M0 : mat_Point)) ==> ((((per (M0 : mat_Point)) (R : mat_Point)) (E : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (M0 : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (R : mat_Point)) (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (Q : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (P : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `((((perp__at (R : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (R : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (M : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((perp__at (M : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (R : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (M : mat_Point)) (R : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ E : mat_Point. ((mat_and (((col (M : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (R : mat_Point)) (M : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((((perp__at (M : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ R : mat_Point. (((((perp__at (M : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__12
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (P : mat_Point)) (M : mat_Point))) ((mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (M : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (Q : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (M : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (M : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (M : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (M : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__sameside2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((oS (P : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (P : mat_Point))) (((betS (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(neq (Q : mat_Point)) (P : mat_Point)`
                                                                   )))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                               ) (MP  
                                                                  (CONV_CONV_rule `(mat_not ((eq (P : mat_Point)) (Q : mat_Point))) ==> ((neq (Q : mat_Point)) (P : mat_Point))` 
                                                                   (SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                  ) (
                                                                  ASSUME `mat_not ((eq (P : mat_Point)) (Q : mat_Point))`
                                                                  )))
                                                             ) (MP  
                                                                (SPEC `(P : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (lemma__samesidereflexive
                                                                   )))
                                                                ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                )))
                                                           ) (MP  
                                                              (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                  (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                   (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                 ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                 ))))
                                                         ) (MP  
                                                            (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                (SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                              ))
                                                            ) (MP  
                                                               (SPEC `(Q : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (lemma__collinearorder
                                                                  )))
                                                               ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                               ))))
                                                       ) (MP  
                                                          (CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))` 
                                                           (SPEC `(Q : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (not__nCol__Col
                                                              ))))
                                                          ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(Q : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (col__nCol__False
                                                                  )))
                                                               ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                               )
                                                              ) (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                 )))))))
                                                    ) (MP  
                                                       (SPEC `(mat_or ((eq (C : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))` 
                                                        (SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                         (or__intror))
                                                       ) (MP  
                                                          (SPEC `(mat_or ((eq (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                           (SPEC `(eq (C : mat_Point)) (Q : mat_Point)` 
                                                            (or__intror))
                                                          ) (MP  
                                                             (SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                              (SPEC `(eq (B : mat_Point)) (Q : mat_Point)` 
                                                               (or__intror))
                                                             ) (MP  
                                                                (SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                 (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                  (or__introl
                                                                  ))
                                                                ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                ))))))
                                                  ) (MP  
                                                     (DISCH `(mat_and ((neq (M : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                         (SPEC `(mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                          (SPEC `(neq (M : mat_Point)) (Q : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(neq (M : mat_Point)) (Q : mat_Point)` 
                                                           (DISCH `(mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                (SPEC `(neq (P : mat_Point)) (M : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(neq (P : mat_Point)) (M : mat_Point)` 
                                                                 (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                  (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                  )))
                                                             ) (ASSUME `(mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((neq (M : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))`
                                                       ))
                                                     ) (MP  
                                                        (SPEC `(Q : mat_Point)` 
                                                         (SPEC `(M : mat_Point)` 
                                                          (SPEC `(P : mat_Point)` 
                                                           (lemma__betweennotequal
                                                           )))
                                                        ) (ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                        ))))
                                                ) (MP  
                                                   (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                       (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                        (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                         (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                             (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                              (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                               (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                   (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                                     ))
                                                   ) (MP  
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(C : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (lemma__collinearorder
                                                         )))
                                                      ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                      )))))
                                             ) (MP  
                                                (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                 (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                  (or__intror))
                                                ) (MP  
                                                   (SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                    (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                     (or__intror))
                                                   ) (MP  
                                                      (SPEC `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                       (SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                        (or__intror))
                                                      ) (MP  
                                                         (SPEC `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                          (SPEC `((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (or__intror))
                                                         ) (MP  
                                                            (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                             (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                              (or__introl))
                                                            ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                            )))))))))
                                       ) (ASSUME `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))`
                                       ))))
                                 ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))))`
                                 ))
                               ) (MP  
                                  (CONV_CONV_rule `(mat_not ((eq (P : mat_Point)) (Q : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (X : mat_Point)) (Q : mat_Point))) ((((cong (X : mat_Point)) (P : mat_Point)) (X : mat_Point)) (Q : mat_Point)))))` 
                                   (SPEC `(Q : mat_Point)` 
                                    (SPEC `(P : mat_Point)` (proposition__10)
                                    ))
                                  ) (ASSUME `mat_not ((eq (P : mat_Point)) (Q : mat_Point))`
                                  ))))
                            ) (DISCH `(eq (P : mat_Point)) (Q : mat_Point)` 
                               (MP  
                                (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                 (DISCH `((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                  (MP  
                                   (DISCH `((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                    (MP  
                                     (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                      (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                       (MP  
                                        (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                         (MP  
                                          (DISCH `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                           (MP  
                                            (DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                             (MP  
                                              (DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(P : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (col__nCol__False)))
                                                 ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                 )
                                                ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                ))
                                              ) (MP  
                                                 (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                     (SPEC `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                      (SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                       (DISCH `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                           (SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                            (SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                             (DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                  (SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                   ))
                                                 ) (MP  
                                                    (SPEC `(P : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (lemma__collinearorder
                                                       )))
                                                    ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                    ))))
                                            ) (MP  
                                               (CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                                (SPEC `(P : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (not__nCol__Col))))
                                               ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(P : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (col__nCol__False)))
                                                    ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                    )
                                                   ) (MP  
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(P : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (lemma__collinear4
                                                            ))))
                                                        ) (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                        )
                                                       ) (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                       )
                                                      ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                      ))))))
                                          ) (MP  
                                             (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                 (SPEC `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                  (SPEC `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                   (DISCH `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                       (SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                        (SPEC `((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                         (DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                             (SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                              (SPEC `((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                   (SPEC `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                  (DISCH `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                   (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                   )))
                                                                 ) (ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                               ))
                                             ) (MP  
                                                (SPEC `(P : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (lemma__collinearorder)))
                                                ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                                ))))
                                        ) (MP  
                                           (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                               (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                 (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                     (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                      (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                       (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                           (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                            (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                             (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                 (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                  (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                             ))
                                           ) (MP  
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (lemma__collinearorder)))
                                              ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                              )))))
                                     ) (MP  
                                        (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                         (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                          (or__intror))
                                        ) (MP  
                                           (SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                            (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                             (or__intror))
                                           ) (MP  
                                              (SPEC `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                               (SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                (or__intror))
                                              ) (MP  
                                                 (SPEC `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                  (SPEC `((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                   (or__intror))
                                                 ) (MP  
                                                    (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                      (or__introl))
                                                    ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                    )))))))
                                   ) (MP  
                                      (MP  
                                       (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (P : mat_Point))) ==> (((((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (CONV_CONV_rule `((eq (P : mat_Point)) (Q : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((mat_not ((eq (C : mat_Point)) (P : mat_Point))) ==> (((((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)))))` 
                                           (SPEC `(P : mat_Point)` 
                                            (MP  
                                             (CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((mat_not ((eq (C : mat_Point)) (Q : mat_Point))) ==> (((((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (Q : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((mat_not ((eq (C : mat_Point)) (x : mat_Point))) ==> (((((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (x : mat_Point)))))))` 
                                              (SPEC `\ P0 : mat_Point. ((((nCol (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> ((mat_not ((eq (C : mat_Point)) (P0 : mat_Point))) ==> (((((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (P0 : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (P0 : mat_Point)))))` 
                                               (SPEC `(Q : mat_Point)` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (eq__ind__r))))
                                             ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                (DISCH `mat_not ((eq (C : mat_Point)) (Q : mat_Point))` 
                                                 (DISCH `(((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                  (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                  ))))))
                                          ) (ASSUME `(eq (P : mat_Point)) (Q : mat_Point)`
                                          )
                                         ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                         ))
                                       ) (ASSUME `mat_not ((eq (C : mat_Point)) (P : mat_Point))`
                                       )
                                      ) (ASSUME `(((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                      ))))
                                ) (MP  
                                   (SPEC `(mat_or ((eq (B : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)))))` 
                                    (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                     (or__intror))
                                   ) (MP  
                                      (SPEC `(mat_or ((eq (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))))` 
                                       (SPEC `(eq (B : mat_Point)) (Q : mat_Point)` 
                                        (or__intror))
                                      ) (MP  
                                         (SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)))` 
                                          (SPEC `(eq (C : mat_Point)) (Q : mat_Point)` 
                                           (or__intror))
                                         ) (MP  
                                            (SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))` 
                                             (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                              (or__intror))
                                            ) (MP  
                                               (SPEC `((betS (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                 (or__introl))
                                               ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                               )))))))))))
                      ) (ASSUME `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (P : mat_Point))`
                      ))))
                ) (ASSUME `ex (\ Q : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (P : mat_Point))))`
                ))
              ) (MP  
                 (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (P : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (C : mat_Point)) (P : mat_Point)))))` 
                  (MP  
                   (SPEC `(P : mat_Point)` 
                    (SPEC `(C : mat_Point)` 
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(B : mat_Point)` (lemma__extension))))
                   ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`))
                 ) (ASSUME `mat_not ((eq (C : mat_Point)) (P : mat_Point))`))
             ))
           ) (DISCH `(eq (C : mat_Point)) (P : mat_Point)` 
              (MP  
               (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                  (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                   (MP  
                    (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (MP  
                      (MP  
                       (SPEC `(C : mat_Point)` 
                        (SPEC `(B : mat_Point)` 
                         (SPEC `(A : mat_Point)` (col__nCol__False)))
                       ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                       )
                      ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                      ))
                    ) (MP  
                       (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                        (MP  
                         (MP  
                          (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                           (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                            (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                             (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                              (MP  
                               (MP  
                                (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                  (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                   (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                    (MP  
                                     (MP  
                                      (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                        (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                         (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                              (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                )))
                                           ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                           ))))
                                     ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                     ))))
                               ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                               ))))
                         ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                         ))
                       ) (MP  
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(A : mat_Point)` (lemma__collinearorder)))
                          ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                          )))))
                 ) (MP  
                    (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                     (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                      (or__intror))
                    ) (MP  
                       (SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                        (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                         (or__intror))
                       ) (MP  
                          (SPEC `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                           (SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                            (or__intror))
                          ) (MP  
                             (SPEC `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                              (SPEC `((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                               (or__intror))
                             ) (MP  
                                (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                  (or__introl))
                                ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                )))))))
               ) (MP  
                  (MP  
                   (MP  
                    (MP  
                     (CONV_CONV_rule `((eq (C : mat_Point)) (P : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                      (SPEC `(C : mat_Point)` 
                       (MP  
                        (CONV_CONV_rule `((((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> (((neq (P : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (P : mat_Point)) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (P : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (x : mat_Point)))))))` 
                         (SPEC `\ C0 : mat_Point. ((((betS (A : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) ==> (((neq (C0 : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (C0 : mat_Point)) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)))))` 
                          (SPEC `(P : mat_Point)` 
                           (PINST [(`:mat_Point`,`:A`)] [] (eq__ind__r))))
                        ) (DISCH `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                           (DISCH `(neq (P : mat_Point)) (B : mat_Point)` 
                            (DISCH `(neq (B : mat_Point)) (P : mat_Point)` 
                             (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                             ))))))
                     ) (ASSUME `(eq (C : mat_Point)) (P : mat_Point)`)
                    ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                    )) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`)
                  ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`)))))
         ) (MP  
            (SPEC `(B : mat_Point)` 
             (SPEC `(C : mat_Point)` (lemma__inequalitysymmetric))
            ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`)))
       ) (MP  
          (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
           (MP  
            (MP  
             (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
              (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
               (SPEC `(neq (C : mat_Point)) (B : mat_Point)` (and__ind)))
             ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                 (MP  
                  (MP  
                   (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                    (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                     (SPEC `(neq (A : mat_Point)) (C : mat_Point)` (and__ind)
                     ))
                   ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                      (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                       (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`)))
                  ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                  ))))
            ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
            ))
          ) (MP  
             (SPEC `(B : mat_Point)` 
              (SPEC `(C : mat_Point)` 
               (SPEC `(A : mat_Point)` (lemma__betweennotequal)))
             ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
             )))))))))
 ;;


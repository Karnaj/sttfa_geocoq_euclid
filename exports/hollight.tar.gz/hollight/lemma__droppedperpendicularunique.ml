(*lemma__droppedperpendicularunique :  |- `! A : mat_Point. (! J : mat_Point. (! M : mat_Point. (! P : mat_Point. ((((per A) M) P) ==> ((((per A) J) P) ==> ((((col A) M) J) ==> ((eq M) J)))))))`*)
let lemma__droppedperpendicularunique =

 GEN `(A : mat_Point)` 
 (GEN `(J : mat_Point)` 
  (GEN `(M : mat_Point)` 
   (GEN `(P : mat_Point)` 
    (DISCH `((per (A : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
     (DISCH `((per (A : mat_Point)) (J : mat_Point)) (P : mat_Point)` 
      (DISCH `((col (A : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
       (MP  
        (CONV_CONV_rule `(((neq (M : mat_Point)) (J : mat_Point)) ==> mat_false) ==> ((eq (M : mat_Point)) (J : mat_Point))` 
         (DISCH `mat_not ((neq (M : mat_Point)) (J : mat_Point))` 
          (MP  
           (CONV_CONV_rule `((mat_not ((eq (M : mat_Point)) (J : mat_Point))) ==> mat_false) ==> ((eq (M : mat_Point)) (J : mat_Point))` 
            (SPEC `(eq (M : mat_Point)) (J : mat_Point)` (nNPP))
           ) (DISCH `mat_not ((eq (M : mat_Point)) (J : mat_Point))` 
              (MP  
               (DISCH `mat_false` 
                (MP  (SPEC `mat_false` (false__ind)) (ASSUME `mat_false`))
               ) (MP  
                  (CONV_CONV_rule `(mat_not ((eq (M : mat_Point)) (J : mat_Point))) ==> mat_false` 
                   (ASSUME `mat_not ((neq (M : mat_Point)) (J : mat_Point))`)
                  ) (ASSUME `mat_not ((eq (M : mat_Point)) (J : mat_Point))`)
               )))))
        ) (DISCH `(neq (M : mat_Point)) (J : mat_Point)` 
           (MP  
            (DISCH `(neq (J : mat_Point)) (M : mat_Point)` 
             (MP  
              (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (M : mat_Point)) (J : mat_Point)) (E : mat_Point))) ((((cong (J : mat_Point)) (E : mat_Point)) (M : mat_Point)) (J : mat_Point))))` 
               (MP  
                (MP  
                 (SPEC `mat_false` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (M : mat_Point)) (J : mat_Point)) (x : mat_Point))) ((((cong (J : mat_Point)) (x : mat_Point)) (M : mat_Point)) (J : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (M : mat_Point)) (J : mat_Point)) (E : mat_Point))) ((((cong (J : mat_Point)) (E : mat_Point)) (M : mat_Point)) (J : mat_Point))))) ==> (return : bool)))` 
                   (SPEC `\ E : mat_Point. ((mat_and (((betS (M : mat_Point)) (J : mat_Point)) (E : mat_Point))) ((((cong (J : mat_Point)) (E : mat_Point)) (M : mat_Point)) (J : mat_Point)))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(E : mat_Point)` 
                    (DISCH `(mat_and (((betS (M : mat_Point)) (J : mat_Point)) (E : mat_Point))) ((((cong (J : mat_Point)) (E : mat_Point)) (M : mat_Point)) (J : mat_Point))` 
                     (MP  
                      (MP  
                       (SPEC `mat_false` 
                        (SPEC `(((cong (J : mat_Point)) (E : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                         (SPEC `((betS (M : mat_Point)) (J : mat_Point)) (E : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((betS (M : mat_Point)) (J : mat_Point)) (E : mat_Point)` 
                          (DISCH `(((cong (J : mat_Point)) (E : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                           (MP  
                            (DISCH `(neq (M : mat_Point)) (E : mat_Point)` 
                             (MP  
                              (DISCH `ex (\ F : mat_Point. ((mat_and (((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (E : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `mat_false` 
                                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (J : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((((cong (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) (E : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (E : mat_Point))))) ==> (return : bool)))` 
                                   (SPEC `\ F : mat_Point. ((mat_and (((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (E : mat_Point)))` 
                                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)
                                    )))
                                 ) (GEN `(F : mat_Point)` 
                                    (DISCH `(mat_and (((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (E : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `mat_false` 
                                        (SPEC `(((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                         (SPEC `((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                          (DISCH `(((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                           (MP  
                                            (DISCH `((betS (E : mat_Point)) (J : mat_Point)) (M : mat_Point)` 
                                             (MP  
                                              (DISCH `((betS (E : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                               (MP  
                                                (DISCH `((betS (F : mat_Point)) (J : mat_Point)) (E : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((betS (E : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(neq (J : mat_Point)) (F : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(neq (F : mat_Point)) (J : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `((mat_or ((eq (J : mat_Point)) (M : mat_Point))) ((mat_or ((eq (J : mat_Point)) (F : mat_Point))) ((mat_or ((eq (M : mat_Point)) (F : mat_Point))) ((mat_or (((betS (M : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_or (((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((betS (J : mat_Point)) (F : mat_Point)) (M : mat_Point))))))) ==> mat_false` 
                                                         (DISCH `((col (J : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                          (MP  
                                                           (DISCH `((col (M : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                            (MP  
                                                             (DISCH `((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(neq (J : mat_Point)) (M : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(neq (M : mat_Point)) (J : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `((col (J : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (F : mat_Point)) (J : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (F : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (F : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (P : mat_Point)) (E : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((midpoint (F : mat_Point)) (J : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((midpoint (F : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (J : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (J : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (J : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__midpointunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((midpoint (F : mat_Point)) (J : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (F : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (P : mat_Point)) (F : mat_Point)) (P : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (F : mat_Point)) (E : mat_Point)) (P : mat_Point))) ((((cong (F : mat_Point)) (P : mat_Point)) (P : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (P : mat_Point)) (F : mat_Point)) (E : mat_Point)) (P : mat_Point))) ((((cong (F : mat_Point)) (P : mat_Point)) (P : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (F : mat_Point)) (P : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (P : mat_Point)) (F : mat_Point)) (P : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (P : mat_Point)) (F : mat_Point)) (E : mat_Point)) (P : mat_Point))) ((((cong (F : mat_Point)) (P : mat_Point)) (P : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (P : mat_Point)) (P : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (F : mat_Point)) (E : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (P : mat_Point)) (F : mat_Point)) (E : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (P : mat_Point)) (P : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (P : mat_Point)) (F : mat_Point)) (E : mat_Point)) (P : mat_Point))) ((((cong (F : mat_Point)) (P : mat_Point)) (P : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (P : mat_Point)) (F : mat_Point)) (P : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (F : mat_Point)) (E : mat_Point)) (P : mat_Point))) ((((cong (F : mat_Point)) (P : mat_Point)) (P : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (P : mat_Point)) (E : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__altitudebisectsbase
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (J : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (P : mat_Point)) (E : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (F : mat_Point)) (J : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__rightreverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (F : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (F : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((((cong (M : mat_Point)) (F : mat_Point)) (E : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((((cong (M : mat_Point)) (F : mat_Point)) (E : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((((cong (M : mat_Point)) (F : mat_Point)) (E : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (F : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (F : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((((cong (M : mat_Point)) (F : mat_Point)) (E : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((((cong (M : mat_Point)) (F : mat_Point)) (E : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (M : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (M : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (M : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (M : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (M : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (M : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (M : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (M : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (M : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (M : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (M : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (J : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (J : mat_Point)) (M : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (J : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (J : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (J : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (J : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (J : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (J : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (J : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (J : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (J : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (J : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (J : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (J : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (J : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (J : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (J : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (CONV_CONV_rule `((((nCol (J : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (J : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                   ) (
                                                                   DISCH `((nCol (J : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (J : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (J : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (J : mat_Point)`
                                                                    ))))))
                                                                 ) (ASSUME `(neq (M : mat_Point)) (J : mat_Point)`
                                                                 ))
                                                               ) (MP  
                                                                  (DISCH `(mat_and ((neq (M : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (M : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (M : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (M : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (J : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (M : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (M : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(F : mat_Point)` 
                                                                   (SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((betS (E : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                  ))))
                                                             ) (MP  
                                                                (DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point))) ((mat_and (((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))) (((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))) (((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))) (((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))) (((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))) (((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))) (((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))) (((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))) (((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))) (((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))) (((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (J : mat_Point))) ((mat_and (((col (M : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (M : mat_Point))) (((col (J : mat_Point)) (M : mat_Point)) (A : mat_Point)))))`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((col (A : mat_Point)) (M : mat_Point)) (J : mat_Point)`
                                                                   ))))
                                                           ) (MP  
                                                              (DISCH `(mat_and (((col (M : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_and (((col (M : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and (((col (F : mat_Point)) (J : mat_Point)) (M : mat_Point))) ((mat_and (((col (J : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((col (F : mat_Point)) (M : mat_Point)) (J : mat_Point)))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((col (M : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                  (SPEC `(mat_and (((col (M : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and (((col (F : mat_Point)) (J : mat_Point)) (M : mat_Point))) ((mat_and (((col (J : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((col (F : mat_Point)) (M : mat_Point)) (J : mat_Point))))` 
                                                                   (SPEC `((col (M : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((col (M : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and (((col (F : mat_Point)) (J : mat_Point)) (M : mat_Point))) ((mat_and (((col (J : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((col (F : mat_Point)) (M : mat_Point)) (J : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (J : mat_Point)) (M : mat_Point))) ((mat_and (((col (J : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((col (F : mat_Point)) (M : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (J : mat_Point)) (M : mat_Point))) ((mat_and (((col (J : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((col (F : mat_Point)) (M : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((col (F : mat_Point)) (M : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((col (F : mat_Point)) (M : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (J : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((col (F : mat_Point)) (M : mat_Point)) (J : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (J : mat_Point)) (M : mat_Point))) ((mat_and (((col (J : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((col (F : mat_Point)) (M : mat_Point)) (J : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and (((col (F : mat_Point)) (J : mat_Point)) (M : mat_Point))) ((mat_and (((col (J : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((col (F : mat_Point)) (M : mat_Point)) (J : mat_Point))))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and (((col (M : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_and (((col (M : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and (((col (F : mat_Point)) (J : mat_Point)) (M : mat_Point))) ((mat_and (((col (J : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((col (F : mat_Point)) (M : mat_Point)) (J : mat_Point)))))`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(F : mat_Point)` 
                                                                  (SPEC `(M : mat_Point)` 
                                                                   (SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                 ) (ASSUME `((col (J : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                 )))))
                                                        ) (MP  
                                                           (SPEC `(mat_or ((eq (J : mat_Point)) (F : mat_Point))) ((mat_or ((eq (M : mat_Point)) (F : mat_Point))) ((mat_or (((betS (M : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_or (((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((betS (J : mat_Point)) (F : mat_Point)) (M : mat_Point)))))` 
                                                            (SPEC `(eq (J : mat_Point)) (M : mat_Point)` 
                                                             (or__intror))
                                                           ) (MP  
                                                              (SPEC `(mat_or ((eq (M : mat_Point)) (F : mat_Point))) ((mat_or (((betS (M : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_or (((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((betS (J : mat_Point)) (F : mat_Point)) (M : mat_Point))))` 
                                                               (SPEC `(eq (J : mat_Point)) (F : mat_Point)` 
                                                                (or__intror))
                                                              ) (MP  
                                                                 (SPEC `(mat_or (((betS (M : mat_Point)) (J : mat_Point)) (F : mat_Point))) ((mat_or (((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((betS (J : mat_Point)) (F : mat_Point)) (M : mat_Point)))` 
                                                                  (SPEC `(eq (M : mat_Point)) (F : mat_Point)` 
                                                                   (or__intror
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point))) (((betS (J : mat_Point)) (F : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (J : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (J : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                    )))))))
                                                      ) (MP  
                                                         (SPEC `(F : mat_Point)` 
                                                          (SPEC `(J : mat_Point)` 
                                                           (lemma__inequalitysymmetric
                                                           ))
                                                         ) (ASSUME `(neq (J : mat_Point)) (F : mat_Point)`
                                                         )))
                                                    ) (MP  
                                                       (DISCH `(mat_and ((neq (J : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (J : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(neq (J : mat_Point)) (F : mat_Point)` 
                                                           (SPEC `(mat_and ((neq (E : mat_Point)) (J : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                                            (SPEC `(neq (J : mat_Point)) (F : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(neq (J : mat_Point)) (F : mat_Point)` 
                                                             (DISCH `(mat_and ((neq (E : mat_Point)) (J : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(neq (J : mat_Point)) (F : mat_Point)` 
                                                                 (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                  (SPEC `(neq (E : mat_Point)) (J : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(neq (E : mat_Point)) (J : mat_Point)` 
                                                                   (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (J : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and ((neq (E : mat_Point)) (J : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((neq (J : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (J : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(F : mat_Point)` 
                                                           (SPEC `(J : mat_Point)` 
                                                            (SPEC `(E : mat_Point)` 
                                                             (lemma__betweennotequal
                                                             )))
                                                          ) (ASSUME `((betS (E : mat_Point)) (J : mat_Point)) (F : mat_Point)`
                                                          ))))
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(F : mat_Point)` 
                                                       (SPEC `(M : mat_Point)` 
                                                        (SPEC `(J : mat_Point)` 
                                                         (SPEC `(E : mat_Point)` 
                                                          (lemma__3__7a))))
                                                      ) (ASSUME `((betS (E : mat_Point)) (J : mat_Point)) (M : mat_Point)`
                                                      )
                                                     ) (ASSUME `((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                     )))
                                                ) (MP  
                                                   (SPEC `(F : mat_Point)` 
                                                    (SPEC `(J : mat_Point)` 
                                                     (SPEC `(E : mat_Point)` 
                                                      (axiom__betweennesssymmetry
                                                      )))
                                                   ) (ASSUME `((betS (E : mat_Point)) (J : mat_Point)) (F : mat_Point)`
                                                   )))
                                              ) (MP  
                                                 (MP  
                                                  (SPEC `(F : mat_Point)` 
                                                   (SPEC `(M : mat_Point)` 
                                                    (SPEC `(J : mat_Point)` 
                                                     (SPEC `(E : mat_Point)` 
                                                      (lemma__3__7b))))
                                                  ) (ASSUME `((betS (E : mat_Point)) (J : mat_Point)) (M : mat_Point)`
                                                  )
                                                 ) (ASSUME `((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                 )))
                                            ) (MP  
                                               (SPEC `(E : mat_Point)` 
                                                (SPEC `(J : mat_Point)` 
                                                 (SPEC `(M : mat_Point)` 
                                                  (axiom__betweennesssymmetry
                                                  )))
                                               ) (ASSUME `((betS (M : mat_Point)) (J : mat_Point)) (E : mat_Point)`
                                               )))))
                                      ) (ASSUME `(mat_and (((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (E : mat_Point))`
                                      ))))
                                ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (J : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (E : mat_Point))))`
                                ))
                              ) (MP  
                                 (MP  
                                  (SPEC `(E : mat_Point)` 
                                   (SPEC `(M : mat_Point)` 
                                    (SPEC `(M : mat_Point)` 
                                     (SPEC `(J : mat_Point)` 
                                      (lemma__extension))))
                                  ) (ASSUME `(neq (J : mat_Point)) (M : mat_Point)`
                                  )
                                 ) (ASSUME `(neq (M : mat_Point)) (E : mat_Point)`
                                 )))
                            ) (MP  
                               (DISCH `(mat_and ((neq (J : mat_Point)) (E : mat_Point))) ((mat_and ((neq (M : mat_Point)) (J : mat_Point))) ((neq (M : mat_Point)) (E : mat_Point)))` 
                                (MP  
                                 (MP  
                                  (SPEC `(neq (M : mat_Point)) (E : mat_Point)` 
                                   (SPEC `(mat_and ((neq (M : mat_Point)) (J : mat_Point))) ((neq (M : mat_Point)) (E : mat_Point))` 
                                    (SPEC `(neq (J : mat_Point)) (E : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(neq (J : mat_Point)) (E : mat_Point)` 
                                     (DISCH `(mat_and ((neq (M : mat_Point)) (J : mat_Point))) ((neq (M : mat_Point)) (E : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (M : mat_Point)) (E : mat_Point)` 
                                         (SPEC `(neq (M : mat_Point)) (E : mat_Point)` 
                                          (SPEC `(neq (M : mat_Point)) (J : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (M : mat_Point)) (J : mat_Point)` 
                                           (DISCH `(neq (M : mat_Point)) (E : mat_Point)` 
                                            (ASSUME `(neq (M : mat_Point)) (E : mat_Point)`
                                            )))
                                       ) (ASSUME `(mat_and ((neq (M : mat_Point)) (J : mat_Point))) ((neq (M : mat_Point)) (E : mat_Point))`
                                       ))))
                                 ) (ASSUME `(mat_and ((neq (J : mat_Point)) (E : mat_Point))) ((mat_and ((neq (M : mat_Point)) (J : mat_Point))) ((neq (M : mat_Point)) (E : mat_Point)))`
                                 ))
                               ) (MP  
                                  (SPEC `(E : mat_Point)` 
                                   (SPEC `(J : mat_Point)` 
                                    (SPEC `(M : mat_Point)` 
                                     (lemma__betweennotequal)))
                                  ) (ASSUME `((betS (M : mat_Point)) (J : mat_Point)) (E : mat_Point)`
                                  ))))))
                      ) (ASSUME `(mat_and (((betS (M : mat_Point)) (J : mat_Point)) (E : mat_Point))) ((((cong (J : mat_Point)) (E : mat_Point)) (M : mat_Point)) (J : mat_Point))`
                      ))))
                ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (M : mat_Point)) (J : mat_Point)) (E : mat_Point))) ((((cong (J : mat_Point)) (E : mat_Point)) (M : mat_Point)) (J : mat_Point))))`
                ))
              ) (MP  
                 (MP  
                  (SPEC `(J : mat_Point)` 
                   (SPEC `(M : mat_Point)` 
                    (SPEC `(J : mat_Point)` 
                     (SPEC `(M : mat_Point)` (lemma__extension))))
                  ) (ASSUME `(neq (M : mat_Point)) (J : mat_Point)`)
                 ) (ASSUME `(neq (M : mat_Point)) (J : mat_Point)`)))
            ) (MP  
               (SPEC `(J : mat_Point)` 
                (SPEC `(M : mat_Point)` (lemma__inequalitysymmetric))
               ) (ASSUME `(neq (M : mat_Point)) (J : mat_Point)`)))))))))))
 ;;


(*lemma__equalanglesflip :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (((((((congA A) B) C) D) E) F) ==> ((((((congA C) B) A) F) E) D)))))))`*)
let lemma__equalanglesflip =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
       (MP  
        (DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
         (MP  
          (DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
           (MP  
            (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
             (MP  
              (CONV_CONV_rule `((((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false) ==> ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
               (DISCH `mat_not (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                (MP  
                 (DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                  (MP  
                   (DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                    (MP  
                     (DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                      (MP  
                       (DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                        (ASSUME `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                        )
                       ) (MP  
                          (MP  
                           (SPEC `(D : mat_Point)` 
                            (SPEC `(E : mat_Point)` 
                             (SPEC `(F : mat_Point)` 
                              (SPEC `(F : mat_Point)` 
                               (SPEC `(E : mat_Point)` 
                                (SPEC `(D : mat_Point)` 
                                 (SPEC `(A : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(C : mat_Point)` 
                                    (lemma__equalanglestransitive)))))))))
                           ) (ASSUME `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                           )
                          ) (ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                          )))
                     ) (MP  
                        (SPEC `(F : mat_Point)` 
                         (SPEC `(E : mat_Point)` 
                          (SPEC `(D : mat_Point)` (lemma__ABCequalsCBA)))
                        ) (ASSUME `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                        )))
                   ) (MP  
                      (MP  
                       (SPEC `(F : mat_Point)` 
                        (SPEC `(E : mat_Point)` 
                         (SPEC `(D : mat_Point)` 
                          (SPEC `(C : mat_Point)` 
                           (SPEC `(B : mat_Point)` 
                            (SPEC `(A : mat_Point)` 
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(B : mat_Point)` 
                               (SPEC `(C : mat_Point)` 
                                (lemma__equalanglestransitive)))))))))
                       ) (ASSUME `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                       )
                      ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                      )))
                 ) (MP  
                    (SPEC `(A : mat_Point)` 
                     (SPEC `(B : mat_Point)` 
                      (SPEC `(C : mat_Point)` (lemma__ABCequalsCBA)))
                    ) (MP  
                       (SPEC `(A : mat_Point)` 
                        (SPEC `(B : mat_Point)` 
                         (SPEC `(C : mat_Point)` (nCol__notCol)))
                       ) (ASSUME `mat_not (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                       )))))
              ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                 (MP  
                  (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (MP  
                    (MP  
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(B : mat_Point)` 
                       (SPEC `(A : mat_Point)` (col__nCol__False)))
                     ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                     )
                    ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                    ))
                  ) (MP  
                     (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                      (MP  
                       (MP  
                        (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                          (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                           (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                            (MP  
                             (MP  
                              (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                      (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                       (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                             (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                              )))
                                         ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                         ))))
                                   ) (ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                   ))))
                             ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                             ))))
                       ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                       ))
                     ) (MP  
                        (SPEC `(A : mat_Point)` 
                         (SPEC `(B : mat_Point)` 
                          (SPEC `(C : mat_Point)` (lemma__collinearorder)))
                        ) (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                        ))))))
            ) (MP  
               (SPEC `(C : mat_Point)` 
                (SPEC `(B : mat_Point)` 
                 (SPEC `(A : mat_Point)` (nCol__notCol)))
               ) (MP  
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (nCol__not__Col)))
                  ) (MP  
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(B : mat_Point)` 
                       (SPEC `(A : mat_Point)` 
                        (SPEC `(F : mat_Point)` 
                         (SPEC `(E : mat_Point)` 
                          (SPEC `(D : mat_Point)` (lemma__equalanglesNC))))))
                     ) (ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                     )))))
          ) (MP  
             (SPEC `(F : mat_Point)` 
              (SPEC `(E : mat_Point)` 
               (SPEC `(D : mat_Point)` 
                (SPEC `(C : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` (lemma__equalanglessymmetric))))))
             ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
             )))
        ) (MP  
           (SPEC `(F : mat_Point)` 
            (SPEC `(E : mat_Point)` (SPEC `(D : mat_Point)` (nCol__notCol)))
           ) (MP  
              (SPEC `(F : mat_Point)` 
               (SPEC `(E : mat_Point)` 
                (SPEC `(D : mat_Point)` (nCol__not__Col)))
              ) (MP  
                 (SPEC `(F : mat_Point)` 
                  (SPEC `(E : mat_Point)` 
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(C : mat_Point)` 
                     (SPEC `(B : mat_Point)` 
                      (SPEC `(A : mat_Point)` (lemma__equalanglesNC))))))
                 ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                 )))))))))))
 ;;


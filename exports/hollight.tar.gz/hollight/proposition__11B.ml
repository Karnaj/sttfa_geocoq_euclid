(*proposition__11B :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! P : mat_Point. ((((betS A) C) B) ==> ((((nCol A) B) P) ==> (ex (\ X : mat_Point. ((mat_and (((per A) C) X)) ((((tS X) A) B) P)))))))))`*)
let proposition__11B =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(P : mat_Point)` 
    (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
     (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
      (MP  
       (DISCH `ex (\ M : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))))))` 
        (MP  
         (MP  
          (SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((oS (x : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))))))) ==> (return : bool)))` 
            (SPEC `\ M : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)))))` 
             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
          ) (GEN `(M : mat_Point)` 
             (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))))` 
              (MP  
               (MP  
                (SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                 (SPEC `(mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                  (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                   (and__ind)))
                ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                   (DISCH `(mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                    (MP  
                     (MP  
                      (SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                       (SPEC `mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                        (SPEC `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                         (DISCH `mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                          (MP  
                           (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                            (MP  
                             (DISCH `ex (\ Q : mat_Point. (((((perp__at (M : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                              (MP  
                               (MP  
                                (SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((((((perp__at (M : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. (((((perp__at (M : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))) ==> (return : bool)))` 
                                  (SPEC `\ Q : mat_Point. (((((perp__at (M : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))
                                  ))
                                ) (GEN `(Q : mat_Point)` 
                                   (DISCH `((((perp__at (M : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                    (MP  
                                     (CONV_CONV_rule `(((((perp__at (M : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                      (DISCH `ex (\ E : mat_Point. ((mat_and (((col (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point))))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((col (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((per (x : mat_Point)) (Q : mat_Point)) (M : mat_Point))))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((col (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point))))))) ==> (return : bool)))` 
                                           (SPEC `\ E : mat_Point. ((mat_and (((col (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)))))` 
                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                             (ex__ind))))
                                         ) (GEN `(E : mat_Point)` 
                                            (DISCH `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)))` 
                                                 (SPEC `((col (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((col (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                  (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                      (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point))` 
                                                       (SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                        (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                            (SPEC `((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                             (SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                              (DISCH `((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `(((eq (M : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                 (DISCH `mat_not ((eq (M : mat_Point)) (Q : mat_Point))` 
                                                                  (MP  
                                                                   (DISCH `(neq (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (C : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ G : mat_Point. ((mat_and (((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((cong (G : mat_Point)) (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (Q : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((((cong (x : mat_Point)) (Q : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and (((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((cong (G : mat_Point)) (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ G : mat_Point. ((mat_and (((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((cong (G : mat_Point)) (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((cong (G : mat_Point)) (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (M : mat_Point)) (G : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (M : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ H34 : mat_Point. ((mat_and (((betS (M : mat_Point)) (G : mat_Point)) (H34 : mat_Point))) ((((cong (G : mat_Point)) (H34 : mat_Point)) (M : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (M : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((((cong (G : mat_Point)) (x : mat_Point)) (M : mat_Point)) (G : mat_Point))) ==> (return : bool))) ==> ((ex (\ H35 : mat_Point. ((mat_and (((betS (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point))) ((((cong (G : mat_Point)) (H35 : mat_Point)) (M : mat_Point)) (G : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ H35 : mat_Point. ((mat_and (((betS (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point))) ((((cong (G : mat_Point)) (H35 : mat_Point)) (M : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(H35 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point))) ((((cong (G : mat_Point)) (H35 : mat_Point)) (M : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H35 : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (H35 : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (G : mat_Point)) (G : mat_Point)) (H35 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((betS (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point))) ((((cong (M : mat_Point)) (G : mat_Point)) (G : mat_Point)) (H35 : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((midpoint (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((midpoint (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (Q : mat_Point)) (G : mat_Point))) ((mat_or ((eq (Q : mat_Point)) (C : mat_Point))) ((mat_or ((eq (G : mat_Point)) (C : mat_Point))) ((mat_or (((betS (G : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((betS (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (G : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ J : mat_Point. ((mat_and (((betS (M : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (Q : mat_Point)) (J : mat_Point)) (M : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (M : mat_Point)) (Q : mat_Point)) (x : mat_Point))) ((((cong (Q : mat_Point)) (x : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ==> (return : bool))) ==> ((ex (\ J : mat_Point. ((mat_and (((betS (M : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (Q : mat_Point)) (J : mat_Point)) (M : mat_Point)) (Q : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ J : mat_Point. ((mat_and (((betS (M : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (Q : mat_Point)) (J : mat_Point)) (M : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (M : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (Q : mat_Point)) (J : mat_Point)) (M : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (J : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (M : mat_Point)) (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (J : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (M : mat_Point)) (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (G : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (J : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (J : mat_Point)) (Q : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (J : mat_Point)) (Q : mat_Point)) (X : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (J : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (G : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((per (J : mat_Point)) (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (J : mat_Point)) (G : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (J : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ K : mat_Point. ((mat_and (((betS (J : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((cong (G : mat_Point)) (K : mat_Point)) (J : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (J : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((((cong (G : mat_Point)) (x : mat_Point)) (J : mat_Point)) (G : mat_Point))) ==> (return : bool))) ==> ((ex (\ K : mat_Point. ((mat_and (((betS (J : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((cong (G : mat_Point)) (K : mat_Point)) (J : mat_Point)) (G : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ K : mat_Point. ((mat_and (((betS (J : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((cong (G : mat_Point)) (K : mat_Point)) (J : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (J : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((cong (G : mat_Point)) (K : mat_Point)) (J : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (K : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (J : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (J : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (K : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (J : mat_Point)) (G : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((betS (J : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((cong (J : mat_Point)) (G : mat_Point)) (G : mat_Point)) (K : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((midpoint (J : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (Q : mat_Point)) (H35 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (J : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (J : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (J : mat_Point)) (H35 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H35 : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (M : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H35 : mat_Point)) (G : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (J : mat_Point)) (G : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H35 : mat_Point)) (G : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H35 : mat_Point)) (C : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H35 : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H35 : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (H35 : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (H35 : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (H35 : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (G : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((per (H35 : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (G : mat_Point)) (C : mat_Point)) (H35 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (C : mat_Point)) (H35 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (M : mat_Point)) (X : mat_Point)) (H35 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))))) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    DISCH `(((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H35 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H35 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (H35 : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((per (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((tS (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (H35 : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (C : mat_Point)) (H35 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (C : mat_Point)) (H35 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (H35 : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H35 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__planeseparation
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H35 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (M : mat_Point)) (x : mat_Point)) (H35 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (M : mat_Point)) (X : mat_Point)) (H35 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (M : mat_Point)) (X : mat_Point)) (H35 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (G : mat_Point)) (C : mat_Point)) (H35 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (A : mat_Point)) (G : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (A : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))) (((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))) (((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))) (((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))) (((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))) (((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))) (((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))) (((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))) (((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))) (((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))) (((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))) (((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (Q : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (Q : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (Q : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (Q : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear5
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (H35 : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (H35 : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (H35 : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (H35 : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (G : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (H35 : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (H35 : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (H35 : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (G : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (H35 : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (H35 : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (H35 : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (G : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H35 : mat_Point)) (C : mat_Point))) ((neq (H35 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H35 : mat_Point)) (C : mat_Point))) ((neq (H35 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H35 : mat_Point)) (C : mat_Point))) ((neq (H35 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H35 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H35 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H35 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (H35 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H35 : mat_Point)) (C : mat_Point))) ((neq (H35 : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H35 : mat_Point)) (C : mat_Point))) ((neq (H35 : mat_Point)) (K : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (H35 : mat_Point)) (K : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (H35 : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (H35 : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (H35 : mat_Point)) (K : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((((cong (H35 : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (H35 : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (H35 : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (J : mat_Point)) (C : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (H35 : mat_Point)) (C : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (J : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (H35 : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (C : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (C : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (H35 : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H35 : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H35 : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H35 : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((cong (H35 : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (H35 : mat_Point)) (G : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (H35 : mat_Point)) (G : mat_Point)) (J : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (J : mat_Point)) (G : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((cong (J : mat_Point)) (G : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (H35 : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (M : mat_Point)) (J : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (M : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (M : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((((cong (M : mat_Point)) (G : mat_Point)) (G : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (M : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (G : mat_Point)) (M : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((((cong (M : mat_Point)) (G : mat_Point)) (G : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (M : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (M : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (M : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((((cong (M : mat_Point)) (G : mat_Point)) (G : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (M : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (G : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (M : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (M : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (G : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (G : mat_Point)) (M : mat_Point)) (J : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (M : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((((cong (M : mat_Point)) (G : mat_Point)) (G : mat_Point)) (J : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (M : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (M : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((((cong (M : mat_Point)) (G : mat_Point)) (G : mat_Point)) (J : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (G : mat_Point)) (J : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H35 : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (H35 : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H35 : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H35 : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (H35 : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (H35 : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H35 : mat_Point)) (G : mat_Point)) (G : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((((cong (G : mat_Point)) (H35 : mat_Point)) (G : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H35 : mat_Point)) (M : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__betweennesspreserved
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (H35 : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (J : mat_Point)) (H35 : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (J : mat_Point)) (C : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (Q : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__pointreflectionisometry
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((midpoint (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (J : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__pointreflectionisometry
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((midpoint (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (J : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (J : mat_Point))) ((mat_and ((neq (M : mat_Point)) (Q : mat_Point))) ((neq (M : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (M : mat_Point)) (Q : mat_Point))) ((neq (M : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (Q : mat_Point))) ((neq (M : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (M : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (Q : mat_Point))) ((neq (M : mat_Point)) (J : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (J : mat_Point))) ((mat_and ((neq (M : mat_Point)) (Q : mat_Point))) ((neq (M : mat_Point)) (J : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (Q : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (J : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((mat_and ((neq (J : mat_Point)) (Q : mat_Point))) ((neq (J : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (J : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (J : mat_Point)) (Q : mat_Point))) ((neq (J : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (J : mat_Point)) (Q : mat_Point))) ((neq (J : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (J : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (J : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (J : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (J : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (J : mat_Point)) (Q : mat_Point))) ((neq (J : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((mat_and ((neq (J : mat_Point)) (Q : mat_Point))) ((neq (J : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (M : mat_Point)) (Q : mat_Point))) ==> ((((cong (M : mat_Point)) (Q : mat_Point)) (H35 : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__pointreflectionisometry
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((midpoint (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (M : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (J : mat_Point)) (G : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (J : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (J : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (J : mat_Point)) (G : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (K : mat_Point)) (J : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (J : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((cong (G : mat_Point)) (K : mat_Point)) (J : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ K : mat_Point. ((mat_and (((betS (J : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((cong (G : mat_Point)) (K : mat_Point)) (J : mat_Point)) (G : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (J : mat_Point)) (G : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (J : mat_Point)) (G : mat_Point)) (X : mat_Point))) ((((cong (G : mat_Point)) (X : mat_Point)) (J : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (J : mat_Point)) (G : mat_Point))) ==> (((neq (J : mat_Point)) (G : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (J : mat_Point)) (G : mat_Point)) (X : mat_Point))) ((((cong (G : mat_Point)) (X : mat_Point)) (J : mat_Point)) (G : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (J : mat_Point)) (G : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (J : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (J : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (J : mat_Point)) (G : mat_Point))) ((mat_or ((eq (Q : mat_Point)) (G : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_or (((betS (J : mat_Point)) (Q : mat_Point)) (G : mat_Point))) (((betS (J : mat_Point)) (G : mat_Point)) (Q : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (J : mat_Point)) (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (J : mat_Point)) (Q : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (J : mat_Point)) (Q : mat_Point)) (G : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__rightangleNC
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (J : mat_Point)) (Q : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (J : mat_Point)) (G : mat_Point))) ((mat_or ((eq (Q : mat_Point)) (G : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_or (((betS (J : mat_Point)) (Q : mat_Point)) (G : mat_Point))) (((betS (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (J : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (Q : mat_Point)) (G : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_or (((betS (J : mat_Point)) (Q : mat_Point)) (G : mat_Point))) (((betS (J : mat_Point)) (G : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (J : mat_Point)) (G : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (J : mat_Point)) (Q : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (J : mat_Point)) (Q : mat_Point)) (x : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (J : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (G : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (J : mat_Point)) (Q : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (J : mat_Point)) (Q : mat_Point)) (X : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (J : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (G : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (J : mat_Point)) (Q : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (J : mat_Point)) (Q : mat_Point)) (X : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (J : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (J : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (J : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (J : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (J : mat_Point)) (G : mat_Point)) (M : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (G : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (G : mat_Point)) (J : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (J : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (Q : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (Q : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (J : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (J : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (Q : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (Q : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (J : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (Q : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (J : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (Q : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__rightreverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (M : mat_Point)) (Q : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (Q : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (G : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (J : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (M : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (Q : mat_Point)) (J : mat_Point)) (M : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ J : mat_Point. ((mat_and (((betS (M : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (Q : mat_Point)) (J : mat_Point)) (M : mat_Point)) (Q : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (M : mat_Point)) (Q : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (M : mat_Point)) (Q : mat_Point)) (X : mat_Point))) ((((cong (Q : mat_Point)) (X : mat_Point)) (M : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (M : mat_Point)) (Q : mat_Point))) ==> (((neq (M : mat_Point)) (Q : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (M : mat_Point)) (Q : mat_Point)) (X : mat_Point))) ((((cong (Q : mat_Point)) (X : mat_Point)) (M : mat_Point)) (Q : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (M : mat_Point)) (Q : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (M : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (C : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (Q : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (C : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (G : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (G : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (Q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (Q : mat_Point)) (C : mat_Point))) ((mat_or ((eq (G : mat_Point)) (C : mat_Point))) ((mat_or (((betS (G : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((betS (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (C : mat_Point))) ((mat_or (((betS (G : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((betS (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (G : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((betS (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((betS (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((cong (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((cong (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((cong (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((cong (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (G : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((cong (G : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (G : mat_Point)) (G : mat_Point)) (H35 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (G : mat_Point)) (G : mat_Point)) (H35 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H35 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H35 : mat_Point)) (M : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (M : mat_Point)) (G : mat_Point)) (H35 : mat_Point))) ((((cong (G : mat_Point)) (H35 : mat_Point)) (M : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ H34 : mat_Point. ((mat_and (((betS (M : mat_Point)) (G : mat_Point)) (H34 : mat_Point))) ((((cong (G : mat_Point)) (H34 : mat_Point)) (M : mat_Point)) (G : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (M : mat_Point)) (G : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (M : mat_Point)) (G : mat_Point)) (X : mat_Point))) ((((cong (G : mat_Point)) (X : mat_Point)) (M : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (M : mat_Point)) (G : mat_Point))) ==> (((neq (M : mat_Point)) (G : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (M : mat_Point)) (G : mat_Point)) (X : mat_Point))) ((((cong (G : mat_Point)) (X : mat_Point)) (M : mat_Point)) (G : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (M : mat_Point)) (G : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (M : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (Q : mat_Point)) (M : mat_Point))) ((mat_or ((eq (Q : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (C : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (Q : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (C : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (M : mat_Point))) ((neq (Q : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))) (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (Q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (Q : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (Q : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (Q : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (M : mat_Point)) (Q : mat_Point))) ==> (((neq (Q : mat_Point)) (M : mat_Point)) ==> ((((per (C : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> (((betS (Q : mat_Point)) (M : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (M : mat_Point)) (G : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> ((((((perp__at (M : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) ==> ((((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> ((mat_not ((eq (M : mat_Point)) (Q : mat_Point))) ==> (((neq (Q : mat_Point)) (M : mat_Point)) ==> ((((per (C : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> (((betS (Q : mat_Point)) (M : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) ==> (((((oS (G : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((per (A : mat_Point)) (C : mat_Point)) (G : mat_Point))) ==> ((((((perp__at (G : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (G : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) ==> ((((per (E : mat_Point)) (Q : mat_Point)) (G : mat_Point)) ==> ((mat_not ((eq (G : mat_Point)) (Q : mat_Point))) ==> (((neq (Q : mat_Point)) (G : mat_Point)) ==> ((((per (C : mat_Point)) (Q : mat_Point)) (G : mat_Point)) ==> (((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (G : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((oS (x : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((per (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ==> ((((((perp__at (x : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (x : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) ==> ((((per (E : mat_Point)) (Q : mat_Point)) (x : mat_Point)) ==> ((mat_not ((eq (x : mat_Point)) (Q : mat_Point))) ==> (((neq (Q : mat_Point)) (x : mat_Point)) ==> ((((per (C : mat_Point)) (Q : mat_Point)) (x : mat_Point)) ==> (((betS (Q : mat_Point)) (x : mat_Point)) (C : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ M0 : mat_Point. ((((nCol (A : mat_Point)) (B : mat_Point)) (M0 : mat_Point)) ==> (((((oS (M0 : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((per (A : mat_Point)) (C : mat_Point)) (M0 : mat_Point))) ==> ((((((perp__at (M0 : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (M0 : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) ==> ((((per (E : mat_Point)) (Q : mat_Point)) (M0 : mat_Point)) ==> ((mat_not ((eq (M0 : mat_Point)) (Q : mat_Point))) ==> (((neq (Q : mat_Point)) (M0 : mat_Point)) ==> ((((per (C : mat_Point)) (Q : mat_Point)) (M0 : mat_Point)) ==> (((betS (Q : mat_Point)) (M0 : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (G : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((per (A : mat_Point)) (C : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    DISCH `((((perp__at (G : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (G : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (M : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((perp__at (M : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (M : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((cong (G : mat_Point)) (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ G : mat_Point. ((mat_and (((betS (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((cong (G : mat_Point)) (Q : mat_Point)) (G : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    proposition__10
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (Q : mat_Point))) ==> ((neq (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (C : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (Q : mat_Point))) ==> (((per (C : mat_Point)) (Q : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (C : mat_Point)) (Q : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (Q : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (Q : mat_Point))) (((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (Q : mat_Point))) (((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (Q : mat_Point))) (((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (Q : mat_Point))) (((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (Q : mat_Point))) (((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (Q : mat_Point))) (((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (Q : mat_Point))) (((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (Q : mat_Point))) (((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (Q : mat_Point))) (((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (Q : mat_Point))) (((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (Q : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (Q : mat_Point))) (((col (E : mat_Point)) (Q : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (Q : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear5
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(eq (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (Q : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((per (E : mat_Point)) (C : mat_Point)) (M : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> ((mat_not (((per (A : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ==> ((((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) ==> (((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (Q : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((mat_not (((per (A : mat_Point)) (x : mat_Point)) (M : mat_Point))) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((per (E : mat_Point)) (x : mat_Point)) (M : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. ((((betS (A : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) ==> ((mat_not (((per (A : mat_Point)) (C0 : mat_Point)) (M : mat_Point))) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> (((per (E : mat_Point)) (C0 : mat_Point)) (M : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((per (A : mat_Point)) (Q : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                   ) (
                                                                   MP  
                                                                   (CONV_CONV_rule `(mat_not ((eq (M : mat_Point)) (Q : mat_Point))) ==> ((neq (Q : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                   ) (
                                                                   ASSUME `mat_not ((eq (M : mat_Point)) (Q : mat_Point))`
                                                                   ))))
                                                                ) (DISCH `(eq (M : mat_Point)) (Q : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (M : mat_Point)) (Q : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> ((((((perp__at (M : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) ==> ((((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((per (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ==> ((((((perp__at (Q : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (Q : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) ==> ((((per (E : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (Q : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((oS (x : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((per (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ==> ((((((perp__at (x : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (x : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) ==> ((((per (E : mat_Point)) (Q : mat_Point)) (x : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ M0 : mat_Point. ((((nCol (A : mat_Point)) (B : mat_Point)) (M0 : mat_Point)) ==> (((((oS (M0 : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((mat_not (((per (A : mat_Point)) (C : mat_Point)) (M0 : mat_Point))) ==> ((((((perp__at (M0 : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (M0 : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) ==> ((((per (E : mat_Point)) (Q : mat_Point)) (M0 : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (M0 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((per (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    DISCH `((((perp__at (Q : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((perp__at (M : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )))))))
                                                          ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point))))`
                                              ))))
                                        ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((col (M : mat_Point)) (Q : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((per (E : mat_Point)) (Q : mat_Point)) (M : mat_Point))))))`
                                        )))
                                     ) (ASSUME `((((perp__at (M : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                     ))))
                               ) (ASSUME `ex (\ Q : mat_Point. (((((perp__at (M : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))`
                               ))
                             ) (MP  
                                (SPEC `(M : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(A : mat_Point)` (proposition__12)))
                                ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                )))
                           ) (MP  
                              (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                               (MP  
                                (MP  
                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                  (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                   (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                    (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                        (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                         (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                           (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                           )))
                                      ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                ))
                              ) (MP  
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(C : mat_Point)` 
                                   (SPEC `(A : mat_Point)` 
                                    (lemma__betweennotequal)))
                                 ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                 ))))))
                     ) (ASSUME `(mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point)))`
                     ))))
               ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))))`
               ))))
         ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and ((((oS (M : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) (mat_not (((per (A : mat_Point)) (C : mat_Point)) (M : mat_Point))))))`
         ))
       ) (MP  
          (MP  
           (SPEC `(P : mat_Point)` 
            (SPEC `(C : mat_Point)` 
             (SPEC `(B : mat_Point)` 
              (SPEC `(A : mat_Point)` (lemma__notperp))))
           ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
           )
          ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
          ))))))))
 ;;


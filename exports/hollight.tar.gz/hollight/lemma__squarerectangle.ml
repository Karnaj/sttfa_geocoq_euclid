(*lemma__squarerectangle :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((sQ A) B) C) D) ==> ((((rE A) B) C) D)))))`*)
let lemma__squarerectangle =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
       (MP  
        (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
         (MP  
          (DISCH `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
           (ASSUME `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
           )
          ) (MP  
             (MP  
              (SPEC `(C : mat_Point)` 
               (SPEC `(B : mat_Point)` 
                (SPEC `(D : mat_Point)` 
                 (SPEC `(A : mat_Point)` (lemma__PGrectangle))))
              ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
              )
             ) (ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
             )))
        ) (MP  
           (CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
            (MP  
             (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
              (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
               (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (and__ind)))
             ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                 (MP  
                  (MP  
                   (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                    (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                     (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                       (MP  
                        (MP  
                         (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                          (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                           (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                            (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                             (MP  
                              (MP  
                               (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                 (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                  (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                      (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                       (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                            (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                             (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                              (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                               (ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                               )))
                                          ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                    ))))
                              ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                              ))))
                        ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                        ))))
                  ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                  )))))
           ) (ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
           )))
      ) (MP  
         (SPEC `(D : mat_Point)` 
          (SPEC `(C : mat_Point)` 
           (SPEC `(B : mat_Point)` 
            (SPEC `(A : mat_Point)` (lemma__squareparallelogram))))
         ) (ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
         )))))))
 ;;


(*lemma__EFreflexive :  |- `! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! p : mat_Point. ((((betS a) p) c) ==> ((((betS b) p) d) ==> ((((nCol a) b) c) ==> ((((((((eF a) b) c) d) a) b) c) d))))))))`*)
let lemma__EFreflexive =

 GEN `(a : mat_Point)` 
 (GEN `(b : mat_Point)` 
  (GEN `(c : mat_Point)` 
   (GEN `(d : mat_Point)` 
    (GEN `(p : mat_Point)` 
     (DISCH `((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
      (DISCH `((betS (b : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
       (DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
        (MP  
         (DISCH `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
          (MP  
           (CONV_CONV_rule `((((col (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> mat_false) ==> ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
            (DISCH `mat_not (((col (a : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
             (MP  
              (CONV_CONV_rule `(((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
               (DISCH `((triangle (a : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                (MP  
                 (CONV_CONV_rule `(((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) ==> ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                  (DISCH `((triangle (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                   (MP  
                    (DISCH `(((((cong__3 (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                     (MP  
                      (DISCH `(((((cong__3 (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                       (MP  
                        (DISCH `(((((eT (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                         (MP  
                          (DISCH `(((((eT (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (a : mat_Point)) (p : mat_Point))) ((mat_or ((eq (c : mat_Point)) (p : mat_Point))) ((mat_or (((betS (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_or (((betS (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point))))))) ==> ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                             (DISCH `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                              (MP  
                               (DISCH `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                (MP  
                                 (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (b : mat_Point)) (X : mat_Point)) (d : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (X : mat_Point))) (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))))) ==> ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                  (DISCH `(((tS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                   (MP  
                                    (DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                     (ASSUME `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                     )
                                    ) (MP  
                                       (MP  
                                        (MP  
                                         (MP  
                                          (MP  
                                           (MP  
                                            (SPEC `(p : mat_Point)` 
                                             (SPEC `(d : mat_Point)` 
                                              (SPEC `(b : mat_Point)` 
                                               (SPEC `(c : mat_Point)` 
                                                (SPEC `(a : mat_Point)` 
                                                 (SPEC `(p : mat_Point)` 
                                                  (SPEC `(d : mat_Point)` 
                                                   (SPEC `(b : mat_Point)` 
                                                    (SPEC `(c : mat_Point)` 
                                                     (SPEC `(a : mat_Point)` 
                                                      (axiom__paste3)))))))))
                                             )
                                            ) (ASSUME `(((((eT (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                            )
                                           ) (ASSUME `(((((eT (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                           )
                                          ) (ASSUME `((betS (b : mat_Point)) (p : mat_Point)) (d : mat_Point)`
                                          )
                                         ) (MP  
                                            (SPEC `(mat_or ((eq (a : mat_Point)) (p : mat_Point))) ((eq (p : mat_Point)) (c : mat_Point))` 
                                             (SPEC `((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                              (or__introl))
                                            ) (ASSUME `((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                            ))
                                        ) (ASSUME `((betS (b : mat_Point)) (p : mat_Point)) (d : mat_Point)`
                                        )
                                       ) (MP  
                                          (SPEC `(mat_or ((eq (a : mat_Point)) (p : mat_Point))) ((eq (p : mat_Point)) (c : mat_Point))` 
                                           (SPEC `((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                            (or__introl))
                                          ) (ASSUME `((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                          )))))
                                 ) (MP  
                                    (SPEC `(p : mat_Point)` 
                                     (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (b : mat_Point)) (x : mat_Point)) (d : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (x : mat_Point))) (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (b : mat_Point)) (X : mat_Point)) (d : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (X : mat_Point))) (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))))))` 
                                      (SPEC `\ X : mat_Point. ((mat_and (((betS (b : mat_Point)) (X : mat_Point)) (d : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (X : mat_Point))) (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                        (ex__intro))))
                                    ) (MP  
                                       (MP  
                                        (SPEC `(mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                         (SPEC `((betS (b : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                          (conj))
                                        ) (ASSUME `((betS (b : mat_Point)) (p : mat_Point)) (d : mat_Point)`
                                        )
                                       ) (MP  
                                          (MP  
                                           (SPEC `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                            (SPEC `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                             (conj))
                                           ) (ASSUME `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)`
                                           )
                                          ) (ASSUME `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                          )))))
                               ) (MP  
                                  (DISCH `(mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                      (SPEC `(mat_and (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))))` 
                                       (SPEC `((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                        (DISCH `(mat_and (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                            (SPEC `(mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))` 
                                             (SPEC `((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                              (DISCH `(mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                  (SPEC `(mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))` 
                                                   (SPEC `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                    (DISCH `(mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                        (SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                         (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                          (DISCH `((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                           (ASSUME `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                           )))
                                                      ) (ASSUME `(mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))`
                                                ))))
                                          ) (ASSUME `(mat_and (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))))`
                                          ))))
                                    ) (ASSUME `(mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))))`
                                    ))
                                  ) (MP  
                                     (CONV_CONV_rule `(((triangle (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) ==> ((mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))))))` 
                                      (SPEC `(b : mat_Point)` 
                                       (SPEC `(c : mat_Point)` 
                                        (SPEC `(a : mat_Point)` 
                                         (lemma__NCorder))))
                                     ) (ASSUME `((triangle (a : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                     )))))
                            ) (MP  
                               (SPEC `(mat_or ((eq (a : mat_Point)) (p : mat_Point))) ((mat_or ((eq (c : mat_Point)) (p : mat_Point))) ((mat_or (((betS (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_or (((betS (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point)))))` 
                                (SPEC `(eq (a : mat_Point)) (c : mat_Point)` 
                                 (or__intror))
                               ) (MP  
                                  (SPEC `(mat_or ((eq (c : mat_Point)) (p : mat_Point))) ((mat_or (((betS (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_or (((betS (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point))))` 
                                   (SPEC `(eq (a : mat_Point)) (p : mat_Point)` 
                                    (or__intror))
                                  ) (MP  
                                     (SPEC `(mat_or (((betS (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_or (((betS (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point)))` 
                                      (SPEC `(eq (c : mat_Point)) (p : mat_Point)` 
                                       (or__intror))
                                     ) (MP  
                                        (SPEC `(mat_or (((betS (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point))` 
                                         (SPEC `((betS (c : mat_Point)) (a : mat_Point)) (p : mat_Point)` 
                                          (or__intror))
                                        ) (MP  
                                           (SPEC `((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                            (SPEC `((betS (a : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                             (or__intror))
                                           ) (ASSUME `((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                           )))))))
                          ) (MP  
                             (SPEC `(b : mat_Point)` 
                              (SPEC `(c : mat_Point)` 
                               (SPEC `(a : mat_Point)` 
                                (SPEC `(b : mat_Point)` 
                                 (SPEC `(c : mat_Point)` 
                                  (SPEC `(a : mat_Point)` 
                                   (axiom__congruentequal))))))
                             ) (ASSUME `(((((cong__3 (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                             )))
                        ) (MP  
                           (SPEC `(d : mat_Point)` 
                            (SPEC `(c : mat_Point)` 
                             (SPEC `(a : mat_Point)` 
                              (SPEC `(d : mat_Point)` 
                               (SPEC `(c : mat_Point)` 
                                (SPEC `(a : mat_Point)` 
                                 (axiom__congruentequal))))))
                           ) (ASSUME `(((((cong__3 (a : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                           )))
                      ) (MP  
                         (SPEC `(b : mat_Point)` 
                          (SPEC `(c : mat_Point)` 
                           (SPEC `(a : mat_Point)` (lemma__TCreflexive)))
                         ) (ASSUME `((triangle (a : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                         )))
                    ) (MP  
                       (SPEC `(d : mat_Point)` 
                        (SPEC `(c : mat_Point)` 
                         (SPEC `(a : mat_Point)` (lemma__TCreflexive)))
                       ) (ASSUME `((triangle (a : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                       ))))
                 ) (ASSUME `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                 )))
              ) (MP  
                 (SPEC `(d : mat_Point)` 
                  (SPEC `(c : mat_Point)` 
                   (SPEC `(a : mat_Point)` (nCol__notCol)))
                 ) (ASSUME `mat_not (((col (a : mat_Point)) (c : mat_Point)) (d : mat_Point))`
                 ))))
           ) (DISCH `((col (a : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
              (MP  
               (CONV_CONV_rule `((mat_or ((eq (b : mat_Point)) (p : mat_Point))) ((mat_or ((eq (b : mat_Point)) (d : mat_Point))) ((mat_or ((eq (p : mat_Point)) (d : mat_Point))) ((mat_or (((betS (p : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_or (((betS (b : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((betS (b : mat_Point)) (d : mat_Point)) (p : mat_Point))))))) ==> mat_false` 
                (DISCH `((col (b : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                 (MP  
                  (CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (p : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (p : mat_Point)) (c : mat_Point))) ((mat_or (((betS (p : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (p : mat_Point))))))) ==> mat_false` 
                   (DISCH `((col (a : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                    (MP  
                     (DISCH `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                      (MP  
                       (DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                        (MP  
                         (DISCH `((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                          (MP  
                           (DISCH `((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                            (MP  
                             (DISCH `((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                              (MP  
                               (DISCH `(neq (p : mat_Point)) (d : mat_Point)` 
                                (MP  
                                 (DISCH `(neq (d : mat_Point)) (p : mat_Point)` 
                                  (MP  
                                   (DISCH `((col (p : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                    (MP  
                                     (DISCH `((col (a : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                      (MP  
                                       (DISCH `((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                        (MP  
                                         (DISCH `(neq (p : mat_Point)) (c : mat_Point)` 
                                          (MP  
                                           (DISCH `((col (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                            (MP  
                                             (DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                              (MP  
                                               (MP  
                                                (SPEC `(b : mat_Point)` 
                                                 (SPEC `(c : mat_Point)` 
                                                  (SPEC `(a : mat_Point)` 
                                                   (col__nCol__False)))
                                                ) (ASSUME `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                )
                                               ) (MP  
                                                  (CONV_CONV_rule `((((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) ==> mat_false) ==> (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                   (SPEC `(b : mat_Point)` 
                                                    (SPEC `(c : mat_Point)` 
                                                     (SPEC `(a : mat_Point)` 
                                                      (not__nCol__Col))))
                                                  ) (DISCH `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(c : mat_Point)` 
                                                        (SPEC `(b : mat_Point)` 
                                                         (SPEC `(a : mat_Point)` 
                                                          (col__nCol__False))
                                                        )
                                                       ) (ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                       )
                                                      ) (ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                      )))))
                                             ) (MP  
                                                (DISCH `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                    (SPEC `(mat_and (((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                     (SPEC `((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                      (DISCH `(mat_and (((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                          (SPEC `(mat_and (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                           (SPEC `((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                            (DISCH `(mat_and (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                (SPEC `(mat_and (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                 (SPEC `((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))`
                                                  ))
                                                ) (MP  
                                                   (SPEC `(a : mat_Point)` 
                                                    (SPEC `(b : mat_Point)` 
                                                     (SPEC `(c : mat_Point)` 
                                                      (lemma__collinearorder)
                                                     ))
                                                   ) (ASSUME `((col (c : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                   ))))
                                           ) (MP  
                                              (CONV_CONV_rule `((((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> mat_false) ==> (((col (c : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                               (SPEC `(a : mat_Point)` 
                                                (SPEC `(b : mat_Point)` 
                                                 (SPEC `(c : mat_Point)` 
                                                  (not__nCol__Col))))
                                              ) (DISCH `((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(a : mat_Point)` 
                                                    (SPEC `(b : mat_Point)` 
                                                     (SPEC `(c : mat_Point)` 
                                                      (col__nCol__False)))
                                                   ) (ASSUME `((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                   )
                                                  ) (MP  
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(a : mat_Point)` 
                                                        (SPEC `(b : mat_Point)` 
                                                         (SPEC `(c : mat_Point)` 
                                                          (SPEC `(p : mat_Point)` 
                                                           (lemma__collinear4
                                                           ))))
                                                       ) (ASSUME `((col (p : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                       )
                                                      ) (ASSUME `((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point)`
                                                      )
                                                     ) (ASSUME `(neq (p : mat_Point)) (c : mat_Point)`
                                                     ))))))
                                         ) (MP  
                                            (DISCH `(mat_and ((neq (p : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (p : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(neq (p : mat_Point)) (c : mat_Point)` 
                                                (SPEC `(mat_and ((neq (a : mat_Point)) (p : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))` 
                                                 (SPEC `(neq (p : mat_Point)) (c : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(neq (p : mat_Point)) (c : mat_Point)` 
                                                  (DISCH `(mat_and ((neq (a : mat_Point)) (p : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(neq (p : mat_Point)) (c : mat_Point)` 
                                                      (SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                                                       (SPEC `(neq (a : mat_Point)) (p : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(neq (a : mat_Point)) (p : mat_Point)` 
                                                        (DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                                                         (ASSUME `(neq (p : mat_Point)) (c : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and ((neq (a : mat_Point)) (p : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((neq (p : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (p : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))`
                                              ))
                                            ) (MP  
                                               (SPEC `(c : mat_Point)` 
                                                (SPEC `(p : mat_Point)` 
                                                 (SPEC `(a : mat_Point)` 
                                                  (lemma__betweennotequal)))
                                               ) (ASSUME `((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                               ))))
                                       ) (MP  
                                          (DISCH `(mat_and (((col (p : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                              (SPEC `(mat_and (((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point))))` 
                                               (SPEC `((col (p : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((col (p : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                (DISCH `(mat_and (((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point))))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                    (SPEC `(mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)))` 
                                                     (SPEC `((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                      (DISCH `(mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                          (SPEC `(mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point))` 
                                                           (SPEC `((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point)` 
                                                            (DISCH `(mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                (SPEC `((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)` 
                                                                 (SPEC `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                                                  (DISCH `((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)` 
                                                                   (ASSUME `((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point)`
                                                                   )))
                                                              ) (ASSUME `(mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point))`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point))))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((col (p : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)))))`
                                            ))
                                          ) (MP  
                                             (SPEC `(c : mat_Point)` 
                                              (SPEC `(p : mat_Point)` 
                                               (SPEC `(a : mat_Point)` 
                                                (lemma__collinearorder)))
                                             ) (ASSUME `((col (a : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                             ))))
                                     ) (ASSUME `((col (a : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                     ))
                                   ) (MP  
                                      (CONV_CONV_rule `((((nCol (p : mat_Point)) (c : mat_Point)) (b : mat_Point)) ==> mat_false) ==> (((col (p : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                       (SPEC `(b : mat_Point)` 
                                        (SPEC `(c : mat_Point)` 
                                         (SPEC `(p : mat_Point)` 
                                          (not__nCol__Col))))
                                      ) (DISCH `((nCol (p : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                         (MP  
                                          (MP  
                                           (SPEC `(b : mat_Point)` 
                                            (SPEC `(c : mat_Point)` 
                                             (SPEC `(p : mat_Point)` 
                                              (col__nCol__False)))
                                           ) (ASSUME `((nCol (p : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                           )
                                          ) (MP  
                                             (MP  
                                              (MP  
                                               (SPEC `(b : mat_Point)` 
                                                (SPEC `(c : mat_Point)` 
                                                 (SPEC `(p : mat_Point)` 
                                                  (SPEC `(d : mat_Point)` 
                                                   (lemma__collinear4))))
                                               ) (ASSUME `((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                               )
                                              ) (ASSUME `((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                              )
                                             ) (ASSUME `(neq (d : mat_Point)) (p : mat_Point)`
                                             ))))))
                                 ) (MP  
                                    (SPEC `(d : mat_Point)` 
                                     (SPEC `(p : mat_Point)` 
                                      (lemma__inequalitysymmetric))
                                    ) (ASSUME `(neq (p : mat_Point)) (d : mat_Point)`
                                    )))
                               ) (MP  
                                  (DISCH `(mat_and ((neq (p : mat_Point)) (d : mat_Point))) ((mat_and ((neq (b : mat_Point)) (p : mat_Point))) ((neq (b : mat_Point)) (d : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(neq (p : mat_Point)) (d : mat_Point)` 
                                      (SPEC `(mat_and ((neq (b : mat_Point)) (p : mat_Point))) ((neq (b : mat_Point)) (d : mat_Point))` 
                                       (SPEC `(neq (p : mat_Point)) (d : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(neq (p : mat_Point)) (d : mat_Point)` 
                                        (DISCH `(mat_and ((neq (b : mat_Point)) (p : mat_Point))) ((neq (b : mat_Point)) (d : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(neq (p : mat_Point)) (d : mat_Point)` 
                                            (SPEC `(neq (b : mat_Point)) (d : mat_Point)` 
                                             (SPEC `(neq (b : mat_Point)) (p : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(neq (b : mat_Point)) (p : mat_Point)` 
                                              (DISCH `(neq (b : mat_Point)) (d : mat_Point)` 
                                               (ASSUME `(neq (p : mat_Point)) (d : mat_Point)`
                                               )))
                                          ) (ASSUME `(mat_and ((neq (b : mat_Point)) (p : mat_Point))) ((neq (b : mat_Point)) (d : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and ((neq (p : mat_Point)) (d : mat_Point))) ((mat_and ((neq (b : mat_Point)) (p : mat_Point))) ((neq (b : mat_Point)) (d : mat_Point)))`
                                    ))
                                  ) (MP  
                                     (SPEC `(d : mat_Point)` 
                                      (SPEC `(p : mat_Point)` 
                                       (SPEC `(b : mat_Point)` 
                                        (lemma__betweennotequal)))
                                     ) (ASSUME `((betS (b : mat_Point)) (p : mat_Point)) (d : mat_Point)`
                                     ))))
                             ) (MP  
                                (DISCH `(mat_and (((col (p : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and (((col (p : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and (((col (b : mat_Point)) (d : mat_Point)) (p : mat_Point))) (((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                    (SPEC `(mat_and (((col (p : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and (((col (b : mat_Point)) (d : mat_Point)) (p : mat_Point))) (((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point))))` 
                                     (SPEC `((col (p : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((col (p : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                      (DISCH `(mat_and (((col (p : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and (((col (b : mat_Point)) (d : mat_Point)) (p : mat_Point))) (((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                          (SPEC `(mat_and (((col (d : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and (((col (b : mat_Point)) (d : mat_Point)) (p : mat_Point))) (((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)))` 
                                           (SPEC `((col (p : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((col (p : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                            (DISCH `(mat_and (((col (d : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and (((col (b : mat_Point)) (d : mat_Point)) (p : mat_Point))) (((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                (SPEC `(mat_and (((col (b : mat_Point)) (d : mat_Point)) (p : mat_Point))) (((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point))` 
                                                 (SPEC `((col (d : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((col (d : mat_Point)) (b : mat_Point)) (p : mat_Point)` 
                                                  (DISCH `(mat_and (((col (b : mat_Point)) (d : mat_Point)) (p : mat_Point))) (((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                      (SPEC `((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                       (SPEC `((col (b : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (b : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                        (DISCH `((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)` 
                                                         (ASSUME `((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and (((col (b : mat_Point)) (d : mat_Point)) (p : mat_Point))) (((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((col (d : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and (((col (b : mat_Point)) (d : mat_Point)) (p : mat_Point))) (((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)))`
                                              ))))
                                        ) (ASSUME `(mat_and (((col (p : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and (((col (b : mat_Point)) (d : mat_Point)) (p : mat_Point))) (((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point))))`
                                        ))))
                                  ) (ASSUME `(mat_and (((col (p : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and (((col (p : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (b : mat_Point)) (p : mat_Point))) ((mat_and (((col (b : mat_Point)) (d : mat_Point)) (p : mat_Point))) (((col (d : mat_Point)) (p : mat_Point)) (b : mat_Point)))))`
                                  ))
                                ) (MP  
                                   (SPEC `(d : mat_Point)` 
                                    (SPEC `(p : mat_Point)` 
                                     (SPEC `(b : mat_Point)` 
                                      (lemma__collinearorder)))
                                   ) (ASSUME `((col (b : mat_Point)) (p : mat_Point)) (d : mat_Point)`
                                   ))))
                           ) (MP  
                              (DISCH `(mat_and (((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point))) ((mat_and (((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point)))))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                  (SPEC `(mat_and (((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))))` 
                                   (SPEC `((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                    (DISCH `(mat_and (((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                        (SPEC `(mat_and (((col (p : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point)))` 
                                         (SPEC `((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                          (DISCH `(mat_and (((col (p : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                              (SPEC `(mat_and (((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))` 
                                               (SPEC `((col (p : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((col (p : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                (DISCH `(mat_and (((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                                    (SPEC `((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                     (SPEC `((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                      (DISCH `((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                       (ASSUME `((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                       )))
                                                  ) (ASSUME `(mat_and (((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((col (p : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point)))`
                                            ))))
                                      ) (ASSUME `(mat_and (((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point))) ((mat_and (((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point)))))`
                                ))
                              ) (MP  
                                 (SPEC `(p : mat_Point)` 
                                  (SPEC `(d : mat_Point)` 
                                   (SPEC `(c : mat_Point)` 
                                    (lemma__collinearorder)))
                                 ) (ASSUME `((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point)`
                                 ))))
                         ) (MP  
                            (CONV_CONV_rule `((((nCol (c : mat_Point)) (d : mat_Point)) (p : mat_Point)) ==> mat_false) ==> (((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point))` 
                             (SPEC `(p : mat_Point)` 
                              (SPEC `(d : mat_Point)` 
                               (SPEC `(c : mat_Point)` (not__nCol__Col))))
                            ) (DISCH `((nCol (c : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                               (MP  
                                (MP  
                                 (SPEC `(p : mat_Point)` 
                                  (SPEC `(d : mat_Point)` 
                                   (SPEC `(c : mat_Point)` (col__nCol__False)
                                   ))
                                 ) (ASSUME `((nCol (c : mat_Point)) (d : mat_Point)) (p : mat_Point)`
                                 )
                                ) (MP  
                                   (MP  
                                    (MP  
                                     (SPEC `(p : mat_Point)` 
                                      (SPEC `(d : mat_Point)` 
                                       (SPEC `(c : mat_Point)` 
                                        (SPEC `(a : mat_Point)` 
                                         (lemma__collinear4))))
                                     ) (ASSUME `((col (a : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                     )
                                    ) (ASSUME `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)`
                                    )
                                   ) (ASSUME `(neq (a : mat_Point)) (c : mat_Point)`
                                   ))))))
                       ) (MP  
                          (DISCH `(mat_and ((neq (p : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (p : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))` 
                           (MP  
                            (MP  
                             (SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                              (SPEC `(mat_and ((neq (a : mat_Point)) (p : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))` 
                               (SPEC `(neq (p : mat_Point)) (c : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(neq (p : mat_Point)) (c : mat_Point)` 
                                (DISCH `(mat_and ((neq (a : mat_Point)) (p : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                                    (SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                                     (SPEC `(neq (a : mat_Point)) (p : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(neq (a : mat_Point)) (p : mat_Point)` 
                                      (DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                                       (ASSUME `(neq (a : mat_Point)) (c : mat_Point)`
                                       )))
                                  ) (ASSUME `(mat_and ((neq (a : mat_Point)) (p : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))`
                                  ))))
                            ) (ASSUME `(mat_and ((neq (p : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (p : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))`
                            ))
                          ) (MP  
                             (SPEC `(c : mat_Point)` 
                              (SPEC `(p : mat_Point)` 
                               (SPEC `(a : mat_Point)` 
                                (lemma__betweennotequal)))
                             ) (ASSUME `((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                             ))))
                     ) (MP  
                        (DISCH `(mat_and (((col (p : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)))))` 
                         (MP  
                          (MP  
                           (SPEC `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                            (SPEC `(mat_and (((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point))))` 
                             (SPEC `((col (p : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (p : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                              (DISCH `(mat_and (((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                  (SPEC `(mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)))` 
                                   (SPEC `((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                    (DISCH `(mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                        (SPEC `(mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point))` 
                                         (SPEC `((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point)` 
                                          (DISCH `(mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                              (SPEC `((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)` 
                                               (SPEC `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                                (DISCH `((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)` 
                                                 (ASSUME `((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point))))`
                                ))))
                          ) (ASSUME `(mat_and (((col (p : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((col (c : mat_Point)) (a : mat_Point)) (p : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (a : mat_Point)))))`
                          ))
                        ) (MP  
                           (SPEC `(c : mat_Point)` 
                            (SPEC `(p : mat_Point)` 
                             (SPEC `(a : mat_Point)` (lemma__collinearorder))
                            )
                           ) (ASSUME `((col (a : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                           )))))
                  ) (MP  
                     (SPEC `(mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (p : mat_Point)) (c : mat_Point))) ((mat_or (((betS (p : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (p : mat_Point)))))` 
                      (SPEC `(eq (a : mat_Point)) (p : mat_Point)` 
                       (or__intror))
                     ) (MP  
                        (SPEC `(mat_or ((eq (p : mat_Point)) (c : mat_Point))) ((mat_or (((betS (p : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (p : mat_Point))))` 
                         (SPEC `(eq (a : mat_Point)) (c : mat_Point)` 
                          (or__intror))
                        ) (MP  
                           (SPEC `(mat_or (((betS (p : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (p : mat_Point)))` 
                            (SPEC `(eq (p : mat_Point)) (c : mat_Point)` 
                             (or__intror))
                           ) (MP  
                              (SPEC `(mat_or (((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (p : mat_Point))` 
                               (SPEC `((betS (p : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                (or__intror))
                              ) (MP  
                                 (SPEC `((betS (a : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                  (SPEC `((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                   (or__introl))
                                 ) (ASSUME `((betS (a : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                 ))))))))
               ) (MP  
                  (SPEC `(mat_or ((eq (b : mat_Point)) (d : mat_Point))) ((mat_or ((eq (p : mat_Point)) (d : mat_Point))) ((mat_or (((betS (p : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_or (((betS (b : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((betS (b : mat_Point)) (d : mat_Point)) (p : mat_Point)))))` 
                   (SPEC `(eq (b : mat_Point)) (p : mat_Point)` (or__intror))
                  ) (MP  
                     (SPEC `(mat_or ((eq (p : mat_Point)) (d : mat_Point))) ((mat_or (((betS (p : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_or (((betS (b : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((betS (b : mat_Point)) (d : mat_Point)) (p : mat_Point))))` 
                      (SPEC `(eq (b : mat_Point)) (d : mat_Point)` 
                       (or__intror))
                     ) (MP  
                        (SPEC `(mat_or (((betS (p : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_or (((betS (b : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((betS (b : mat_Point)) (d : mat_Point)) (p : mat_Point)))` 
                         (SPEC `(eq (p : mat_Point)) (d : mat_Point)` 
                          (or__intror))
                        ) (MP  
                           (SPEC `(mat_or (((betS (b : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((betS (b : mat_Point)) (d : mat_Point)) (p : mat_Point))` 
                            (SPEC `((betS (p : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                             (or__intror))
                           ) (MP  
                              (SPEC `((betS (b : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                               (SPEC `((betS (b : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                (or__introl))
                              ) (ASSUME `((betS (b : mat_Point)) (p : mat_Point)) (d : mat_Point)`
                              )))))))))
         ) (MP  
            (DISCH `(mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)))))` 
             (MP  
              (MP  
               (SPEC `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                (SPEC `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                 (SPEC `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                  (and__ind)))
               ) (DISCH `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                  (DISCH `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                   (MP  
                    (MP  
                     (SPEC `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                      (SPEC `(mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                       (SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                        (DISCH `(mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                            (SPEC `(mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                             (SPEC `((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                              (DISCH `(mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                               (MP  
                                (MP  
                                 (SPEC `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                  (SPEC `((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                   (SPEC `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                    (DISCH `((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                     (ASSUME `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                     )))
                                ) (ASSUME `(mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)))`
                          ))))
                    ) (ASSUME `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))))`
                    ))))
              ) (ASSUME `(mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)))))`
              ))
            ) (MP  
               (SPEC `(c : mat_Point)` 
                (SPEC `(b : mat_Point)` 
                 (SPEC `(a : mat_Point)` (lemma__NCorder)))
               ) (ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
               )))))))))))
 ;;


(*lemma__rightreverse :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((per A) B) C) ==> ((((betS A) B) D) ==> (((((cong A) B) B) D) ==> ((((cong A) C) D) C)))))))`*)
let lemma__rightreverse =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
      (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
       (MP  
        (CONV_CONV_rule `(((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
         (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
          (MP  
           (MP  
            (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))) ==> (return : bool)))` 
              (SPEC `\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
            ) (GEN `(E : mat_Point)` 
               (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
                (MP  
                 (MP  
                  (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                   (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                    (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                     (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                      (MP  
                       (MP  
                        (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                         (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                           (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                            (MP  
                             (MP  
                              (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                               (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                    (MP  
                                     (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                      (MP  
                                       (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                        (MP  
                                         (DISCH `(eq (D : mat_Point)) (E : mat_Point)` 
                                          (MP  
                                           (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                            (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                            )
                                           ) (MP  
                                              (MP  
                                               (MP  
                                                (MP  
                                                 (MP  
                                                  (MP  
                                                   (CONV_CONV_rule `((eq (D : mat_Point)) (E : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)))))))` 
                                                    (SPEC `(D : mat_Point)` 
                                                     (MP  
                                                      (CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (E : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point)))))))))` 
                                                       (SPEC `\ D0 : mat_Point. ((((betS (A : mat_Point)) (B : mat_Point)) (D0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D0 : mat_Point)) ==> (((((cong (B : mat_Point)) (D0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (D0 : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (D0 : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (D0 : mat_Point)) (C : mat_Point)))))))` 
                                                        (SPEC `(E : mat_Point)` 
                                                         (PINST [(`:mat_Point`,`:A`)] [] 
                                                          (eq__ind__r))))
                                                      ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                         (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                          (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                            (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                             (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                             ))))))))
                                                   ) (ASSUME `(eq (D : mat_Point)) (E : mat_Point)`
                                                   )
                                                  ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                  )
                                                 ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                 )
                                                ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                )
                                               ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                               )
                                              ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                              )))
                                         ) (MP  
                                            (MP  
                                             (MP  
                                              (SPEC `(E : mat_Point)` 
                                               (SPEC `(D : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (lemma__extensionunique))))
                                              ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                              )
                                             ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                             )
                                            ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                            )))
                                       ) (MP  
                                          (DISCH `(mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                              (SPEC `(mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                               (SPEC `(((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                (DISCH `(mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                    (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                     (SPEC `(((cong (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                      (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                       (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                       )))
                                                  ) (ASSUME `(mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)))`
                                            ))
                                          ) (MP  
                                             (SPEC `(B : mat_Point)` 
                                              (SPEC `(E : mat_Point)` 
                                               (SPEC `(D : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (lemma__congruenceflip))))
                                             ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                             ))))
                                     ) (MP  
                                        (MP  
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(E : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(A : mat_Point)` 
                                             (SPEC `(D : mat_Point)` 
                                              (SPEC `(B : mat_Point)` 
                                               (lemma__congruencetransitive))
                                             ))))
                                         ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                         )
                                        ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                        )))
                                   ) (MP  
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(B : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (lemma__congruencesymmetric))))
                                      ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                      )))))
                             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                             ))))
                       ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                       ))))
                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))`
                 ))))
           ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
           )))
        ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`))
      ))))))
 ;;


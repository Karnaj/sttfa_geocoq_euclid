(*lemma__outerconnectivity :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((betS A) B) C) ==> ((((betS A) B) D) ==> ((mat_not (((betS B) C) D)) ==> ((mat_not (((betS B) D) C)) ==> ((eq C) D))))))))`*)
let lemma__outerconnectivity =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
      (DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
       (DISCH `mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
        (MP  
         (CONV_CONV_rule `(((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
          (DISCH `mat_not ((eq (A : mat_Point)) (C : mat_Point))` 
           (MP  
            (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
             (MP  
              (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
               (MP  
                (MP  
                 (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                   (SPEC `\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(E : mat_Point)` 
                    (DISCH `(mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                     (MP  
                      (MP  
                       (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                        (SPEC `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                         (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                          (DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                           (MP  
                            (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                             (MP  
                              (CONV_CONV_rule `(((eq (A : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((eq (C : mat_Point)) (D : mat_Point))` 
                               (DISCH `mat_not ((eq (A : mat_Point)) (D : mat_Point))` 
                                (MP  
                                 (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (DISCH `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((((cong (D : mat_Point)) (x : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                        (SPEC `\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                         (PINST [(`:mat_Point`,`:A`)] [] 
                                          (ex__ind))))
                                      ) (GEN `(F : mat_Point)` 
                                         (DISCH `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                             (SPEC `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                              (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                               (DISCH `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                (MP  
                                                 (DISCH `((betS (F : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                  (MP  
                                                   (DISCH `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                    (MP  
                                                     (DISCH `((betS (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                      (MP  
                                                       (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(eq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__connectivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__3__6a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__3__6a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (F : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (A : mat_Point)) (C : mat_Point)) (F : mat_Point)) ==> (((((cong (C : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (F : mat_Point)) ==> (((((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (F : mat_Point)) ==> (((((cong (F : mat_Point)) (A : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((betS (A : mat_Point)) (D : mat_Point)) (F : mat_Point))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((((cong (F : mat_Point)) (A : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((betS (A : mat_Point)) (D : mat_Point)) (x : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ E0 : mat_Point. ((((betS (A : mat_Point)) (C : mat_Point)) (E0 : mat_Point)) ==> (((((cong (C : mat_Point)) (E0 : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (E0 : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E0 : mat_Point)) ==> (((((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E0 : mat_Point)) ==> (((((cong (F : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E0 : mat_Point)) ==> (((((cong (A : mat_Point)) (E0 : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (E0 : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (E0 : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((betS (A : mat_Point)) (D : mat_Point)) (E0 : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (F : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__extensionunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__differenceofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (A : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                   )))
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                               ) (SPEC `(A : mat_Point)` 
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (cn__equalityreverse
                                                                   ))))
                                                             ) (MP  
                                                                (SPEC `(D : mat_Point)` 
                                                                 (SPEC `(E : mat_Point)` 
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                ) (ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                )))
                                                           ) (MP  
                                                              (MP  
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (SPEC `(F : mat_Point)` 
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                               ) (ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                               )
                                                              ) (ASSUME `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                              )))
                                                         ) (SPEC `(D : mat_Point)` 
                                                            (SPEC `(F : mat_Point)` 
                                                             (cn__equalityreverse
                                                             ))))
                                                       ) (MP  
                                                          (SPEC `(A : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(F : mat_Point)` 
                                                             (axiom__betweennesssymmetry
                                                             )))
                                                          ) (ASSUME `((betS (F : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                          )))
                                                     ) (MP  
                                                        (MP  
                                                         (SPEC `(A : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(D : mat_Point)` 
                                                            (SPEC `(F : mat_Point)` 
                                                             (lemma__3__5b)))
                                                          )
                                                         ) (ASSUME `((betS (F : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                         )
                                                        ) (ASSUME `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                        )))
                                                   ) (MP  
                                                      (SPEC `(D : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (axiom__betweennesssymmetry
                                                         )))
                                                      ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                      )))
                                                 ) (MP  
                                                    (SPEC `(F : mat_Point)` 
                                                     (SPEC `(D : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (axiom__betweennesssymmetry
                                                       )))
                                                    ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                    )))))
                                           ) (ASSUME `(mat_and (((betS (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                           ))))
                                     ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                     ))
                                   ) (MP  
                                      (MP  
                                       (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (D : mat_Point))) ==> (((neq (A : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) ((((cong (D : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (SPEC `(D : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (lemma__extension)))))
                                       ) (ASSUME `mat_not ((eq (A : mat_Point)) (D : mat_Point))`
                                       )
                                      ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                      )))
                                 ) (MP  
                                    (DISCH `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                         (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                          (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (CONV_CONV_rule `(((neq (A : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (E : mat_Point)) ==> (mat_not ((eq (A : mat_Point)) (C : mat_Point))))) ==> (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))) ==> ((neq (A : mat_Point)) (C : mat_Point)))` 
                                              (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                 (and__ind))))
                                             ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                 (ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`
                                                 )))
                                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))`
                                      ))
                                    ) (MP  
                                       (SPEC `(E : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (lemma__betweennotequal)))
                                       ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                       )))))
                              ) (DISCH `(eq (A : mat_Point)) (D : mat_Point)` 
                                 (MP  
                                  (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                   (MP  
                                    (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                     (MP  
                                      (CONV_CONV_rule `((eq (A : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                       (ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                       )
                                      ) (ASSUME `(eq (A : mat_Point)) (D : mat_Point)`
                                      ))
                                    ) (SPEC `(B : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (axiom__betweennessidentity))))
                                  ) (MP  
                                     (MP  
                                      (MP  
                                       (MP  
                                        (MP  
                                         (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((neq (A : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
                                          (MP  
                                           (MP  
                                            (MP  
                                             (CONV_CONV_rule `((eq (A : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((neq (A : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))))` 
                                              (SPEC `(A : mat_Point)` 
                                               (MP  
                                                (CONV_CONV_rule `((((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_not ((eq (D : mat_Point)) (C : mat_Point))) ==> (((neq (D : mat_Point)) (D : mat_Point)) ==> ((((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> ((((betS (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((betS (D : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_not ((eq (x : mat_Point)) (C : mat_Point))) ==> (((neq (x : mat_Point)) (D : mat_Point)) ==> ((((betS (x : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((betS (x : mat_Point)) (B : mat_Point)) (x : mat_Point)))))))))))` 
                                                 (SPEC `\ A0 : mat_Point. ((((betS (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_not ((eq (A0 : mat_Point)) (C : mat_Point))) ==> (((neq (A0 : mat_Point)) (D : mat_Point)) ==> ((((betS (A0 : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) ==> ((((betS (A0 : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((betS (A0 : mat_Point)) (B : mat_Point)) (A0 : mat_Point)))))))))` 
                                                  (SPEC `(D : mat_Point)` 
                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                    (eq__ind__r))))
                                                ) (DISCH `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `((betS (D : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                    (DISCH `mat_not ((eq (D : mat_Point)) (C : mat_Point))` 
                                                     (DISCH `(neq (D : mat_Point)) (D : mat_Point)` 
                                                      (DISCH `((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                       (DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                        (DISCH `((betS (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                         (ASSUME `((betS (D : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                         ))))))))))
                                             ) (ASSUME `(eq (A : mat_Point)) (D : mat_Point)`
                                             )
                                            ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                            )
                                           ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                           ))
                                         ) (ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`
                                         )
                                        ) (ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                        )
                                       ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                       )
                                      ) (ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                      )
                                     ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                     )))))
                            ) (MP  
                               (MP  
                                (SPEC `(E : mat_Point)` 
                                 (SPEC `(C : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(A : mat_Point)` (lemma__3__6b))))
                                ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                )
                               ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                               )))))
                      ) (ASSUME `(mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                      ))))
                ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point))))`
                ))
              ) (MP  
                 (MP  
                  (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((neq (A : mat_Point)) (D : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (D : mat_Point))))))` 
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(A : mat_Point)` 
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(A : mat_Point)` (lemma__extension)))))
                  ) (ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`)
                 ) (ASSUME `(neq (A : mat_Point)) (D : mat_Point)`)))
            ) (MP  
               (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))` 
                (MP  
                 (MP  
                  (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                   (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                    (SPEC `(neq (B : mat_Point)) (D : mat_Point)` (and__ind))
                   )
                  ) (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                     (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                      (MP  
                       (MP  
                        (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                         (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                          (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                           (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                            (ASSUME `(neq (A : mat_Point)) (D : mat_Point)`))
                        )
                       ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))`
                       ))))
                 ) (ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))`
                 ))
               ) (MP  
                  (SPEC `(D : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (lemma__betweennotequal)))
                  ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                  )))))
         ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
            (MP  
             (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
              (MP  
               (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                (MP  
                 (CONV_CONV_rule `(((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false` 
                  (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                  )
                 ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                 ))
               ) (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` (axiom__betweennessidentity))))
             ) (MP  
                (MP  
                 (MP  
                  (CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                   (SPEC `(A : mat_Point)` 
                    (MP  
                     (CONV_CONV_rule `((((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((betS (x : mat_Point)) (B : mat_Point)) (x : mat_Point))))))` 
                      (SPEC `\ A0 : mat_Point. ((((betS (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((betS (A0 : mat_Point)) (B : mat_Point)) (A0 : mat_Point))))` 
                       (SPEC `(C : mat_Point)` 
                        (PINST [(`:mat_Point`,`:A`)] [] (eq__ind__r))))
                     ) (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                         (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                         )))))
                  ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`)
                 ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 )
                ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                ))))))))))))
 ;;


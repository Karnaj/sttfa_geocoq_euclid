(*proposition__43B :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! G : mat_Point. (! H : mat_Point. (! K : mat_Point. (((((pG A) B) C) D) ==> ((((betS A) H) D) ==> ((((betS A) E) B) ==> ((((betS D) F) C) ==> ((((betS B) G) C) ==> (((((pG E) A) H) K) ==> (((((pG G) K) F) C) ==> ((((pG E) K) G) B))))))))))))))))`*)
let proposition__43B =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(G : mat_Point)` 
       (GEN `(H : mat_Point)` 
        (GEN `(K : mat_Point)` 
         (DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
          (DISCH `((betS (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
           (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
            (DISCH `((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
             (DISCH `((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
              (DISCH `(((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
               (DISCH `(((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                (MP  
                 (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                  (MP  
                   (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                    (MP  
                     (DISCH `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                      (MP  
                       (DISCH `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                        (MP  
                         (DISCH `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                          (MP  
                           (DISCH `(((par (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                            (MP  
                             (DISCH `(((par (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                              (MP  
                               (DISCH `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                (MP  
                                 (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                  (MP  
                                   (DISCH `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                    (MP  
                                     (DISCH `(((par (A : mat_Point)) (H : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                      (MP  
                                       (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (MP  
                                         (DISCH `(((tP (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                          (MP  
                                           (DISCH `(((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                            (MP  
                                             (DISCH `(((tP (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                              (MP  
                                               (DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (MP  
                                                 (DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                    (MP  
                                                     (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                      (MP  
                                                       (DISCH `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(neq (A : mat_Point)) (H : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ e : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (e : mat_Point))) ((((cong (A : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (e : mat_Point))) ((((cong (A : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ e : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (e : mat_Point))) ((((cong (A : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (e : mat_Point))) ((((cong (A : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (A : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (e : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((rT (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (A : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (e : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (H : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((rT (H : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (E : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))))) ==> ((((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (H : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (H : mat_Point)) (K : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (K : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (B : mat_Point))))))) ==> ((((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (G : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (K : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ c : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((cong (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ c : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((cong (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ c : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((cong (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((cong (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (c : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((rT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (c : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((rT (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (G : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (G : mat_Point)) (C : mat_Point))) ((mat_or (((betS (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (G : mat_Point))))))) ==> ((((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> ((((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))))))) ==> ((((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (K : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point))) ==> ((((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((pG (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and ((((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((par (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((par (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((par (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((par (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and ((((par (E : mat_Point)) (B : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((par (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((par (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((par (K : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((par (K : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((par (K : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (K : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (K : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((par (K : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((par (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((par (K : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    proposition__28D
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (K : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesidecollinear
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (K : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (A : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (K : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (A : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (K : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (A : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (A : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (K : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (K : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesidetransitive
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (F : mat_Point)) (K : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (F : mat_Point)) (K : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (F : mat_Point)) (K : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (F : mat_Point)) (K : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (F : mat_Point)) (K : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (K : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__samesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__samesidecollinear
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) ==> ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) ==> ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)) ==> ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__sameside2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (G : mat_Point)) (C : mat_Point))) ((mat_or (((betS (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (C : mat_Point))) ((mat_or (((betS (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `((((((rT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) ==> (((((((rT (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)) ==> ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    ASSUME `((((((rT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) ==> (((((((rT (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)) ==> ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point))))`
                                                                    ) (
                                                                    ASSUME `(((((rT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((rT (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((rT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__supplements2
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((rT (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((rT (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (G : mat_Point))) (((betS (C : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (F : mat_Point))) (((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! B0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G0 : mat_Point. (! H90 : mat_Point. (((((par (G0 : mat_Point)) (B0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)) ==> (((((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) ==> ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    ASSUME `! B0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G0 : mat_Point. (! H90 : mat_Point. (((((par (G0 : mat_Point)) (B0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)) ==> (((((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) ==> ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)))))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    GEN `(E0 : mat_Point)` 
                                                                    (
                                                                    GEN `(G0 : mat_Point)` 
                                                                    (
                                                                    GEN `(H90 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G0 : mat_Point)) (B0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H90 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    proposition__29C
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (G0 : mat_Point)) (B0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    axiom__innertransitivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((((oS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__samesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! B0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G0 : mat_Point. (! H85 : mat_Point. (((((par (G0 : mat_Point)) (B0 : mat_Point)) (H85 : mat_Point)) (D0 : mat_Point)) ==> (((((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) ==> ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (D0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    ASSUME `! B0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G0 : mat_Point. (! H85 : mat_Point. (((((par (G0 : mat_Point)) (B0 : mat_Point)) (H85 : mat_Point)) (D0 : mat_Point)) ==> (((((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) ==> ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (D0 : mat_Point)))))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    GEN `(E0 : mat_Point)` 
                                                                    (
                                                                    GEN `(G0 : mat_Point)` 
                                                                    (
                                                                    GEN `(H85 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G0 : mat_Point)) (B0 : mat_Point)) (H85 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)) (D0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H85 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    proposition__29C
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (G0 : mat_Point)) (B0 : mat_Point)) (H85 : mat_Point)) (D0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H85 : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((cong (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ c : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((cong (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (K : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((((par (K : mat_Point)) (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((((par (K : mat_Point)) (E : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (K : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (K : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((((par (K : mat_Point)) (E : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (K : mat_Point)) (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (K : mat_Point)) (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((((par (K : mat_Point)) (E : mat_Point)) (G : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (K : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((par (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((((par (K : mat_Point)) (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (K : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    proposition__28D
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (K : mat_Point)) (G : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__sameside2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((oS (K : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (G : mat_Point))) (((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (K : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((oS (C : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((oS (K : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (C : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((oS (K : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (K : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (C : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((oS (K : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (C : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (K : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (C : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((oS (K : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (K : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((oS (C : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((oS (K : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (K : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesidetransitive
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (H : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (H : mat_Point)) (K : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__samesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__samesidecollinear
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__sameside2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesidecollinear
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__samesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `((((((rT (H : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) ==> (((((((congA (H : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((((rT (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((((congA (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    ASSUME `((((((rT (H : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) ==> (((((((congA (H : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((((rT (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((((congA (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ) (
                                                                    ASSUME `(((((rT (H : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (E : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((rT (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((rT (H : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((congA (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__supplements2
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((rT (H : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (E : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((rT (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesflip
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (E : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (H : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (K : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (H : mat_Point)) (E : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (H : mat_Point))) (((betS (A : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! B0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G0 : mat_Point. (! H44 : mat_Point. (((((par (G0 : mat_Point)) (B0 : mat_Point)) (H44 : mat_Point)) (D0 : mat_Point)) ==> (((((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) ==> ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (D0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    ASSUME `! B0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G0 : mat_Point. (! H44 : mat_Point. (((((par (G0 : mat_Point)) (B0 : mat_Point)) (H44 : mat_Point)) (D0 : mat_Point)) ==> (((((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) ==> ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (D0 : mat_Point)))))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (H : mat_Point)) (E : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (H : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (e : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    GEN `(E0 : mat_Point)` 
                                                                    (
                                                                    GEN `(G0 : mat_Point)` 
                                                                    (
                                                                    GEN `(H44 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G0 : mat_Point)) (B0 : mat_Point)) (H44 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)) (D0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    proposition__29C
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (G0 : mat_Point)) (B0 : mat_Point)) (H44 : mat_Point)) (D0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H44 : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and ((((oS (H : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((oS (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (H : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((oS (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (H : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((oS (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (H : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (H : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (H : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((oS (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and ((((oS (H : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((oS (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__3__6a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! B0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G0 : mat_Point. (! H39 : mat_Point. (((((par (G0 : mat_Point)) (B0 : mat_Point)) (H39 : mat_Point)) (D0 : mat_Point)) ==> (((((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) ==> ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (D0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    ASSUME `! B0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G0 : mat_Point. (! H39 : mat_Point. (((((par (G0 : mat_Point)) (B0 : mat_Point)) (H39 : mat_Point)) (D0 : mat_Point)) ==> (((((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) ==> ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (D0 : mat_Point)))))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (e : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    GEN `(E0 : mat_Point)` 
                                                                    (
                                                                    GEN `(G0 : mat_Point)` 
                                                                    (
                                                                    GEN `(H39 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G0 : mat_Point)) (B0 : mat_Point)) (H39 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)) (D0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H39 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    proposition__29C
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (G0 : mat_Point)) (B0 : mat_Point)) (H39 : mat_Point)) (D0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (B0 : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H39 : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (e : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (e : mat_Point))) ((((cong (A : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ e : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (e : mat_Point))) ((((cong (A : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                   )))
                                                                 ) (MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                               ) (MP  
                                                                  (DISCH `(mat_and ((neq (G : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                  ))))
                                                             ) (MP  
                                                                (DISCH `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (H : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (H : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(neq (H : mat_Point)) (D : mat_Point)` 
                                                                   (DISCH `(mat_and ((neq (A : mat_Point)) (H : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (H : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (H : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((betS (A : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                   ))))
                                                           ) (MP  
                                                              (DISCH `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                  (SPEC `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                   (SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                 ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                 ))))
                                                         ) (MP  
                                                            (CONV_CONV_rule `((((tP (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                             (MP  
                                                              (SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                 (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) ==> ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)) ==> ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                   )))))
                                                            ) (ASSUME `(((tP (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                            )))
                                                       ) (MP  
                                                          (CONV_CONV_rule `((((tP (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                           (MP  
                                                            (SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                             (SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                              (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                               (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                   (SPEC `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                  (DISCH `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) ==> ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)) ==> ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                 )))))
                                                          ) (ASSUME `(((tP (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                          )))
                                                     ) (MP  
                                                        (CONV_CONV_rule `((((tP (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                         (MP  
                                                          (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                            (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                             (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                 (SPEC `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                  (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                   (DISCH `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) ==> ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)) ==> ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                               )))))
                                                        ) (ASSUME `(((tP (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                        )))
                                                   ) (MP  
                                                      (DISCH `(mat_and ((((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                          (SPEC `(mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                           (SPEC `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                            (DISCH `(mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                (SPEC `(((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (DISCH `(((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (ASSUME `(((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                   )))
                                                              ) (ASSUME `(mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                              ))))
                                                        ) (ASSUME `(mat_and ((((oS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((oS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                        ))
                                                      ) (MP  
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(C : mat_Point)` 
                                                             (lemma__samesidesymmetric
                                                             ))))
                                                         ) (ASSUME `(((oS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                         ))))
                                                 ) (MP  
                                                    (SPEC `(D : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (lemma__samesideflip)
                                                       )))
                                                    ) (ASSUME `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                    )))
                                               ) (MP  
                                                  (CONV_CONV_rule `((((tP (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                   (MP  
                                                    (SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                      (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                       (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (SPEC `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                            (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                             (DISCH `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (SPEC `mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                   (DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) ==> ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)) ==> ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)))) ((((oS (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (F : mat_Point))) ((mat_and (mat_not ((((meet (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ((((oS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ((((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                         )))))
                                                  ) (ASSUME `(((tP (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                  )))
                                             ) (MP  
                                                (SPEC `(D : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (lemma__paralleldef2B))))
                                                ) (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                )))
                                           ) (MP  
                                              (SPEC `(F : mat_Point)` 
                                               (SPEC `(K : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(G : mat_Point)` 
                                                  (lemma__paralleldef2B))))
                                              ) (ASSUME `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                              )))
                                         ) (MP  
                                            (SPEC `(K : mat_Point)` 
                                             (SPEC `(H : mat_Point)` 
                                              (SPEC `(A : mat_Point)` 
                                               (SPEC `(E : mat_Point)` 
                                                (lemma__paralleldef2B))))
                                            ) (ASSUME `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                            )))
                                       ) (MP  
                                          (SPEC `(D : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (lemma__paralleldef2B))))
                                          ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                          )))
                                     ) (MP  
                                        (SPEC `(H : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (SPEC `(K : mat_Point)` 
                                           (SPEC `(E : mat_Point)` 
                                            (lemma__parallelsymmetric))))
                                        ) (ASSUME `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                        )))
                                   ) (MP  
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(C : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (lemma__parallelsymmetric))))
                                      ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                      )))
                                 ) (MP  
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (lemma__parallelsymmetric))))
                                    ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                    )))
                               ) (MP  
                                  (CONV_CONV_rule `((((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) ==> ((((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                   (MP  
                                    (SPEC `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                     (SPEC `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                      (SPEC `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                       (DISCH `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                        (MP  
                                         (CONV_CONV_rule `((((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)) ==> ((((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                          (MP  
                                           (SPEC `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                            (SPEC `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                             (SPEC `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                              (DISCH `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                               (MP  
                                                (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                 (MP  
                                                  (SPEC `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                   (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (ASSUME `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                      ))))
                                                ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                )))))
                                         ) (ASSUME `(((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                         )))))
                                  ) (ASSUME `(((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                  )))
                             ) (MP  
                                (DISCH `(mat_and ((((par (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and ((((par (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((par (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(((par (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                    (SPEC `(mat_and ((((par (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((par (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                     (SPEC `(((par (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(((par (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                      (DISCH `(mat_and ((((par (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((par (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((par (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                          (SPEC `(((par (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                           (SPEC `(((par (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(((par (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                            (DISCH `(((par (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                             (ASSUME `(((par (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                             )))
                                        ) (ASSUME `(mat_and ((((par (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((par (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (G : mat_Point))`
                                        ))))
                                  ) (ASSUME `(mat_and ((((par (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and ((((par (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((par (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (G : mat_Point)))`
                                  ))
                                ) (MP  
                                   (SPEC `(K : mat_Point)` 
                                    (SPEC `(G : mat_Point)` 
                                     (SPEC `(C : mat_Point)` 
                                      (SPEC `(F : mat_Point)` 
                                       (lemma__parallelflip))))
                                   ) (ASSUME `(((par (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                   ))))
                           ) (MP  
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(F : mat_Point)` 
                                (SPEC `(K : mat_Point)` 
                                 (SPEC `(G : mat_Point)` 
                                  (lemma__parallelsymmetric))))
                              ) (ASSUME `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                              )))
                         ) (MP  
                            (CONV_CONV_rule `((((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) ==> ((((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                             (MP  
                              (SPEC `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                               (SPEC `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                (SPEC `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                  (MP  
                                   (CONV_CONV_rule `((((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)) ==> ((((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                    (MP  
                                     (SPEC `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                       (SPEC `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                        (DISCH `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                           (MP  
                                            (SPEC `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                             (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (ASSUME `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                ))))
                                          ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                          )))))
                                   ) (ASSUME `(((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                   )))))
                            ) (ASSUME `(((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                            )))
                       ) (MP  
                          (CONV_CONV_rule `((((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) ==> ((((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point))` 
                           (MP  
                            (SPEC `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                             (SPEC `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                              (SPEC `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                               (DISCH `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                (MP  
                                 (CONV_CONV_rule `((((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)) ==> ((((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point))` 
                                  (MP  
                                   (SPEC `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                    (SPEC `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                     (SPEC `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                      (DISCH `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                       (MP  
                                        (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point))` 
                                         (MP  
                                          (SPEC `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                           (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                             (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (ASSUME `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                              ))))
                                        ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                        )))))
                                 ) (ASSUME `(((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                 )))))
                          ) (ASSUME `(((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                          )))
                     ) (MP  
                        (CONV_CONV_rule `((((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) ==> ((((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                         (MP  
                          (SPEC `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                           (SPEC `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                            (SPEC `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                             (DISCH `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                              (MP  
                               (CONV_CONV_rule `((((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)) ==> ((((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                (MP  
                                 (SPEC `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                  (SPEC `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                   (SPEC `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                    (DISCH `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                     (MP  
                                      (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                       (MP  
                                        (SPEC `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                         (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                           (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (ASSUME `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                            ))))
                                      ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                      )))))
                               ) (ASSUME `(((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                               )))))
                        ) (ASSUME `(((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                        )))
                   ) (MP  
                      (CONV_CONV_rule `((((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                       (MP  
                        (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                         (SPEC `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                          (SPEC `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                           (DISCH `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `((((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                              (MP  
                               (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                (SPEC `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                 (SPEC `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                  (DISCH `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                     (MP  
                                      (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                       (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                          ))))
                                    ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                    )))))
                             ) (ASSUME `(((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                             )))))
                      ) (ASSUME `(((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                      )))
                 ) (MP  
                    (CONV_CONV_rule `((((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                     (MP  
                      (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (SPEC `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                        (SPEC `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `(((par (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                         (DISCH `(((par (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                          (MP  
                           (CONV_CONV_rule `((((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                            (MP  
                             (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (SPEC `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                               (SPEC `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(((par (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                (DISCH `(((par (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                 (MP  
                                  (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                   (MP  
                                    (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                       (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                        ))))
                                  ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                  )))))
                           ) (ASSUME `(((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                           )))))
                    ) (ASSUME `(((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                    ))))))))))))))))))
 ;;


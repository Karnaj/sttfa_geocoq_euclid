(*proposition__43 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! G : mat_Point. (! H : mat_Point. (! K : mat_Point. (((((pG A) B) C) D) ==> ((((betS A) H) D) ==> ((((betS A) E) B) ==> ((((betS D) F) C) ==> ((((betS B) G) C) ==> ((((betS A) K) C) ==> (((((pG E) A) H) K) ==> (((((pG G) K) F) C) ==> ((((((((eF K) G) B) E) D) F) K) H)))))))))))))))))`*)
let proposition__43 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(G : mat_Point)` 
       (GEN `(H : mat_Point)` 
        (GEN `(K : mat_Point)` 
         (DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
          (DISCH `((betS (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
           (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
            (DISCH `((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
             (DISCH `((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
              (DISCH `((betS (A : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
               (DISCH `(((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                (DISCH `(((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                 (MP  
                  (DISCH `(((pG (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                   (MP  
                    (DISCH `(((((cong__3 (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                     (MP  
                      (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                       (MP  
                        (DISCH `(((((cong__3 (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                         (MP  
                          (DISCH `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                           (MP  
                            (DISCH `(((((cong__3 (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                             (MP  
                              (DISCH `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                               (MP  
                                (DISCH `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                 (MP  
                                  (DISCH `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                   (MP  
                                    (DISCH `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                     (MP  
                                      (DISCH `(((((eT (K : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                       (MP  
                                        (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (MP  
                                          (DISCH `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (DISCH `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                             (MP  
                                              (DISCH `(((((eT (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (MP  
                                                (DISCH `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                   (MP  
                                                    (DISCH `((betS (D : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(((((eT (E : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                               (MP  
                                                                (DISCH `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(((((((eF (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (K : mat_Point)) (E : mat_Point)) (B : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) (H : mat_Point)) (D : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    axiom__cutoff2
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (E : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  MP  
                                                                  (DISCH `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)))))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (K : mat_Point)))))))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                  ) (
                                                                  ASSUME `(((((((eF (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                  ))))
                                                                ) (MP  
                                                                   (SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                   ) (
                                                                   ASSUME `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)`
                                                                   )))
                                                              ) (MP  
                                                                 (DISCH `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)))))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point))))))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (K : mat_Point)))))))`
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (K : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                            ) (MP  
                                                               (SPEC `(K : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (SPEC `(E : mat_Point)` 
                                                                  (SPEC `(K : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                               ) (ASSUME `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point)`
                                                               )))
                                                          ) (MP  
                                                             (DISCH `(mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                 (SPEC `(mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                                                  (SPEC `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                   (DISCH `(mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)))))`
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(K : mat_Point)` 
                                                                 (SPEC `(E : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                ) (ASSUME `(((((eT (H : mat_Point)) (A : mat_Point)) (K : mat_Point)) (A : mat_Point)) (E : mat_Point)) (K : mat_Point)`
                                                                ))))
                                                        ) (MP  
                                                           (SPEC `(K : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (SPEC `(H : mat_Point)` 
                                                              (SPEC `(K : mat_Point)` 
                                                               (SPEC `(E : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (axiom__ETsymmetric
                                                                 ))))))
                                                           ) (ASSUME `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (K : mat_Point)`
                                                           )))
                                                      ) (MP  
                                                         (DISCH `(mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point)))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                             (SPEC `(mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point))))` 
                                                              (SPEC `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                               (DISCH `(mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                   (SPEC `(mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                  (DISCH `(mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point))))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (H : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (K : mat_Point)) (H : mat_Point)))))`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(A : mat_Point)` 
                                                             (SPEC `(H : mat_Point)` 
                                                              (SPEC `(K : mat_Point)` 
                                                               (SPEC `(K : mat_Point)` 
                                                                (SPEC `(E : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (axiom__ETpermutation
                                                                  ))))))
                                                            ) (ASSUME `(((((eT (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                            ))))
                                                    ) (MP  
                                                       (SPEC `(D : mat_Point)` 
                                                        (SPEC `(H : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (axiom__betweennesssymmetry
                                                          )))
                                                       ) (ASSUME `((betS (A : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                       )))
                                                  ) (MP  
                                                     (SPEC `(B : mat_Point)` 
                                                      (SPEC `(E : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (axiom__betweennesssymmetry
                                                        )))
                                                     ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                     )))
                                                ) (MP  
                                                   (MP  
                                                    (MP  
                                                     (MP  
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(D : mat_Point)` 
                                                         (SPEC `(F : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(K : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (SPEC `(G : mat_Point)` 
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(K : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (axiom__cutoff1
                                                                  ))))))))))
                                                        ) (ASSUME `((betS (A : mat_Point)) (K : mat_Point)) (C : mat_Point)`
                                                        )
                                                       ) (ASSUME `((betS (A : mat_Point)) (K : mat_Point)) (C : mat_Point)`
                                                       )
                                                      ) (ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                      )
                                                     ) (ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                     )
                                                    ) (ASSUME `(((((eT (K : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                    )
                                                   ) (ASSUME `(((((eT (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                   )))
                                              ) (MP  
                                                 (SPEC `(B : mat_Point)` 
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (SPEC `(D : mat_Point)` 
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (axiom__ETsymmetric)))
                                                    )))
                                                 ) (ASSUME `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                 )))
                                            ) (MP  
                                               (DISCH `(mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                   (SPEC `(mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                    (SPEC `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                     (DISCH `(mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                         (SPEC `(mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                          (SPEC `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                           (DISCH `(mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `(mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                (SPEC `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                 (DISCH `(mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   ASSUME `(mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                 ))
                                               ) (MP  
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (SPEC `(D : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (axiom__ETpermutation
                                                        ))))))
                                                  ) (ASSUME `(((((eT (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                  ))))
                                          ) (MP  
                                             (SPEC `(D : mat_Point)` 
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (axiom__ETsymmetric))))))
                                             ) (ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                             )))
                                        ) (MP  
                                           (DISCH `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (SPEC `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                 (DISCH `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (SPEC `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                      (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                       (DISCH `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                            (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                             (DISCH `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                  (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                         ))))
                                                   ) (ASSUME `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))))`
                                             ))
                                           ) (MP  
                                              (SPEC `(A : mat_Point)` 
                                               (SPEC `(D : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (axiom__ETpermutation))))
                                                ))
                                              ) (ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                              ))))
                                      ) (MP  
                                         (SPEC `(G : mat_Point)` 
                                          (SPEC `(C : mat_Point)` 
                                           (SPEC `(K : mat_Point)` 
                                            (SPEC `(F : mat_Point)` 
                                             (SPEC `(C : mat_Point)` 
                                              (SPEC `(K : mat_Point)` 
                                               (axiom__ETsymmetric))))))
                                         ) (ASSUME `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                         )))
                                    ) (MP  
                                       (DISCH `(mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point)))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                           (SPEC `(mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                            (SPEC `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                             (DISCH `(mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                 (SPEC `(mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                  (SPEC `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                   (DISCH `(mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                       (SPEC `(mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                        (SPEC `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                         (DISCH `(mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                             (SPEC `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                              (SPEC `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                               (DISCH `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                (ASSUME `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                )))
                                                           ) (ASSUME `(mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point)))`
                                                     ))))
                                               ) (ASSUME `(mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point))))`
                                               ))))
                                         ) (ASSUME `(mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)) (G : mat_Point)))))`
                                         ))
                                       ) (MP  
                                          (SPEC `(C : mat_Point)` 
                                           (SPEC `(G : mat_Point)` 
                                            (SPEC `(K : mat_Point)` 
                                             (SPEC `(F : mat_Point)` 
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(K : mat_Point)` 
                                                (axiom__ETpermutation))))))
                                          ) (ASSUME `(((((eT (K : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                          ))))
                                  ) (MP  
                                     (SPEC `(F : mat_Point)` 
                                      (SPEC `(C : mat_Point)` 
                                       (SPEC `(K : mat_Point)` 
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(G : mat_Point)` 
                                          (SPEC `(K : mat_Point)` 
                                           (axiom__ETsymmetric))))))
                                     ) (ASSUME `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                     )))
                                ) (MP  
                                   (DISCH `(mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                       (SPEC `(mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point))))` 
                                        (SPEC `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                         (DISCH `(mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                             (SPEC `(mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)))` 
                                              (SPEC `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                               (DISCH `(mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                   (SPEC `(mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                    (SPEC `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                     (DISCH `(mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                         (SPEC `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                          (SPEC `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                           (DISCH `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                            (ASSUME `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                            )))
                                                       ) (ASSUME `(mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)))`
                                                 ))))
                                           ) (ASSUME `(mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point))))`
                                           ))))
                                     ) (ASSUME `(mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (K : mat_Point)) (C : mat_Point)) (F : mat_Point)))))`
                                     ))
                                   ) (MP  
                                      (SPEC `(K : mat_Point)` 
                                       (SPEC `(F : mat_Point)` 
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(C : mat_Point)` 
                                          (SPEC `(G : mat_Point)` 
                                           (SPEC `(K : mat_Point)` 
                                            (axiom__ETpermutation))))))
                                      ) (ASSUME `(((((eT (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)`
                                      ))))
                              ) (MP  
                                 (SPEC `(K : mat_Point)` 
                                  (SPEC `(F : mat_Point)` 
                                   (SPEC `(C : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(G : mat_Point)` 
                                      (SPEC `(K : mat_Point)` 
                                       (axiom__congruentequal))))))
                                 ) (ASSUME `(((((cong__3 (K : mat_Point)) (G : mat_Point)) (C : mat_Point)) (C : mat_Point)) (F : mat_Point)) (K : mat_Point)`
                                 )))
                            ) (MP  
                               (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))))` 
                                (MP  
                                 (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))))` 
                                  (MP  
                                   (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))` 
                                    (MP  
                                     (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))` 
                                      (MP  
                                       (SPEC `(F : mat_Point)` 
                                        (SPEC `(K : mat_Point)` 
                                         (SPEC `(C : mat_Point)` 
                                          (SPEC `(G : mat_Point)` 
                                           (ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))`
                                           ))))
                                       ) (ASSUME `(((pG (G : mat_Point)) (K : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                       ))
                                     ) (GEN `(A0 : mat_Point)` 
                                        (GEN `(B0 : mat_Point)` 
                                         (GEN `(C0 : mat_Point)` 
                                          (GEN `(D0 : mat_Point)` 
                                           (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                               (SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                                (SPEC `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                                 (DISCH `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                                  (ASSUME `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)`
                                                  )))
                                             ) (MP  
                                                (SPEC `(D0 : mat_Point)` 
                                                 (SPEC `(C0 : mat_Point)` 
                                                  (SPEC `(B0 : mat_Point)` 
                                                   (SPEC `(A0 : mat_Point)` 
                                                    (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))`
                                                    ))))
                                                ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                                )))))))))
                                   ) (GEN `(A0 : mat_Point)` 
                                      (GEN `(B0 : mat_Point)` 
                                       (GEN `(C0 : mat_Point)` 
                                        (GEN `(D0 : mat_Point)` 
                                         (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                          (MP  
                                           (MP  
                                            (SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                             (SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                              (SPEC `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                               (DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                                (ASSUME `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))`
                                                )))
                                           ) (MP  
                                              (SPEC `(D0 : mat_Point)` 
                                               (SPEC `(C0 : mat_Point)` 
                                                (SPEC `(B0 : mat_Point)` 
                                                 (SPEC `(A0 : mat_Point)` 
                                                  (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))))))))`
                                                  ))))
                                              ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                              )))))))))
                                 ) (GEN `(A0 : mat_Point)` 
                                    (GEN `(B0 : mat_Point)` 
                                     (GEN `(C0 : mat_Point)` 
                                      (GEN `(D0 : mat_Point)` 
                                       (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                        (MP  
                                         (MP  
                                          (SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                           (SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                            (SPEC `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                             (DISCH `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                              (ASSUME `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))`
                                              )))
                                         ) (MP  
                                            (SPEC `(D0 : mat_Point)` 
                                             (SPEC `(C0 : mat_Point)` 
                                              (SPEC `(B0 : mat_Point)` 
                                               (SPEC `(A0 : mat_Point)` 
                                                (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((cong (A00 : mat_Point)) (C00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point))) ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))))`
                                                ))))
                                            ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                            )))))))))
                               ) (GEN `(A0 : mat_Point)` 
                                  (GEN `(B0 : mat_Point)` 
                                   (GEN `(C0 : mat_Point)` 
                                    (GEN `(D0 : mat_Point)` 
                                     (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                      (MP  
                                       (MP  
                                        (SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                         (SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                          (SPEC `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                           (DISCH `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                            (ASSUME `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))`
                                            )))
                                       ) (MP  
                                          (SPEC `(D0 : mat_Point)` 
                                           (SPEC `(C0 : mat_Point)` 
                                            (SPEC `(B0 : mat_Point)` 
                                             (SPEC `(A0 : mat_Point)` 
                                              (proposition__34))))
                                          ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                          ))))))))))
                          ) (MP  
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(H : mat_Point)` 
                               (SPEC `(K : mat_Point)` 
                                (SPEC `(K : mat_Point)` 
                                 (SPEC `(E : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (axiom__congruentequal))))))
                             ) (ASSUME `(((((cong__3 (A : mat_Point)) (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                             )))
                        ) (MP  
                           (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))))` 
                            (MP  
                             (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))))` 
                              (MP  
                               (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))` 
                                (MP  
                                 (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))` 
                                  (MP  
                                   (SPEC `(H : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (SPEC `(K : mat_Point)` 
                                      (SPEC `(E : mat_Point)` 
                                       (ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))`
                                       ))))
                                   ) (ASSUME `(((pG (E : mat_Point)) (A : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                   ))
                                 ) (GEN `(A0 : mat_Point)` 
                                    (GEN `(B0 : mat_Point)` 
                                     (GEN `(C0 : mat_Point)` 
                                      (GEN `(D0 : mat_Point)` 
                                       (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                        (MP  
                                         (MP  
                                          (SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                           (SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                            (SPEC `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                             (DISCH `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                              (ASSUME `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)`
                                              )))
                                         ) (MP  
                                            (SPEC `(D0 : mat_Point)` 
                                             (SPEC `(C0 : mat_Point)` 
                                              (SPEC `(B0 : mat_Point)` 
                                               (SPEC `(A0 : mat_Point)` 
                                                (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))`
                                                ))))
                                            ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                            )))))))))
                               ) (GEN `(A0 : mat_Point)` 
                                  (GEN `(B0 : mat_Point)` 
                                   (GEN `(C0 : mat_Point)` 
                                    (GEN `(D0 : mat_Point)` 
                                     (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                      (MP  
                                       (MP  
                                        (SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                         (SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                          (SPEC `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                           (DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                            (ASSUME `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))`
                                            )))
                                       ) (MP  
                                          (SPEC `(D0 : mat_Point)` 
                                           (SPEC `(C0 : mat_Point)` 
                                            (SPEC `(B0 : mat_Point)` 
                                             (SPEC `(A0 : mat_Point)` 
                                              (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))))))))`
                                              ))))
                                          ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                          )))))))))
                             ) (GEN `(A0 : mat_Point)` 
                                (GEN `(B0 : mat_Point)` 
                                 (GEN `(C0 : mat_Point)` 
                                  (GEN `(D0 : mat_Point)` 
                                   (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                    (MP  
                                     (MP  
                                      (SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                       (SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                        (SPEC `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                         (DISCH `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                          (ASSUME `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))`
                                          )))
                                     ) (MP  
                                        (SPEC `(D0 : mat_Point)` 
                                         (SPEC `(C0 : mat_Point)` 
                                          (SPEC `(B0 : mat_Point)` 
                                           (SPEC `(A0 : mat_Point)` 
                                            (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((cong (A00 : mat_Point)) (C00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point))) ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))))`
                                            ))))
                                        ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                        )))))))))
                           ) (GEN `(A0 : mat_Point)` 
                              (GEN `(B0 : mat_Point)` 
                               (GEN `(C0 : mat_Point)` 
                                (GEN `(D0 : mat_Point)` 
                                 (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                  (MP  
                                   (MP  
                                    (SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                     (SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                      (SPEC `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                       (DISCH `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                        (ASSUME `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))`
                                        )))
                                   ) (MP  
                                      (SPEC `(D0 : mat_Point)` 
                                       (SPEC `(C0 : mat_Point)` 
                                        (SPEC `(B0 : mat_Point)` 
                                         (SPEC `(A0 : mat_Point)` 
                                          (proposition__34))))
                                      ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                      ))))))))))
                      ) (MP  
                         (SPEC `(A : mat_Point)` 
                          (SPEC `(D : mat_Point)` 
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(C : mat_Point)` 
                             (SPEC `(B : mat_Point)` 
                              (SPEC `(A : mat_Point)` (axiom__congruentequal)
                              )))))
                         ) (ASSUME `(((((cong__3 (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                         )))
                    ) (MP  
                       (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))))` 
                        (MP  
                         (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))))` 
                          (MP  
                           (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))` 
                            (MP  
                             (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))` 
                              (MP  
                               (SPEC `(D : mat_Point)` 
                                (SPEC `(A : mat_Point)` 
                                 (SPEC `(C : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))`
                                   ))))
                               ) (ASSUME `(((pG (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                               ))
                             ) (GEN `(A0 : mat_Point)` 
                                (GEN `(B0 : mat_Point)` 
                                 (GEN `(C0 : mat_Point)` 
                                  (GEN `(D0 : mat_Point)` 
                                   (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                    (MP  
                                     (MP  
                                      (SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                       (SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                        (SPEC `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                         (DISCH `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                          (ASSUME `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)`
                                          )))
                                     ) (MP  
                                        (SPEC `(D0 : mat_Point)` 
                                         (SPEC `(C0 : mat_Point)` 
                                          (SPEC `(B0 : mat_Point)` 
                                           (SPEC `(A0 : mat_Point)` 
                                            (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))`
                                            ))))
                                        ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                        )))))))))
                           ) (GEN `(A0 : mat_Point)` 
                              (GEN `(B0 : mat_Point)` 
                               (GEN `(C0 : mat_Point)` 
                                (GEN `(D0 : mat_Point)` 
                                 (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                  (MP  
                                   (MP  
                                    (SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                     (SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                      (SPEC `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                       (DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                        (ASSUME `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))`
                                        )))
                                   ) (MP  
                                      (SPEC `(D0 : mat_Point)` 
                                       (SPEC `(C0 : mat_Point)` 
                                        (SPEC `(B0 : mat_Point)` 
                                         (SPEC `(A0 : mat_Point)` 
                                          (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))))))))`
                                          ))))
                                      ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                      )))))))))
                         ) (GEN `(A0 : mat_Point)` 
                            (GEN `(B0 : mat_Point)` 
                             (GEN `(C0 : mat_Point)` 
                              (GEN `(D0 : mat_Point)` 
                               (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                (MP  
                                 (MP  
                                  (SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                   (SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                    (SPEC `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                     (DISCH `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                      (ASSUME `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))`
                                      )))
                                 ) (MP  
                                    (SPEC `(D0 : mat_Point)` 
                                     (SPEC `(C0 : mat_Point)` 
                                      (SPEC `(B0 : mat_Point)` 
                                       (SPEC `(A0 : mat_Point)` 
                                        (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((cong (A00 : mat_Point)) (C00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point))) ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))))`
                                        ))))
                                    ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                    )))))))))
                       ) (GEN `(A0 : mat_Point)` 
                          (GEN `(B0 : mat_Point)` 
                           (GEN `(C0 : mat_Point)` 
                            (GEN `(D0 : mat_Point)` 
                             (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                              (MP  
                               (MP  
                                (SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                 (SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                  (SPEC `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                   (DISCH `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                    (ASSUME `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))`
                                    )))
                               ) (MP  
                                  (SPEC `(D0 : mat_Point)` 
                                   (SPEC `(C0 : mat_Point)` 
                                    (SPEC `(B0 : mat_Point)` 
                                     (SPEC `(A0 : mat_Point)` 
                                      (proposition__34))))
                                  ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                  ))))))))))
                  ) (MP  
                     (SPEC `(D : mat_Point)` 
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(A : mat_Point)` (lemma__PGflip))))
                     ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                     )))))))))))))))))))
 ;;


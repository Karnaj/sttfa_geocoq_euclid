(*lemma__TCreflexive :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((triangle A) B) C) ==> ((((((cong__3 A) B) C) A) B) C))))`*)
let lemma__TCreflexive =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
      (MP  
       (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
        (MP  
         (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
          (MP  
           (CONV_CONV_rule `((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> ((((((cong__3 (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
            (DISCH `(((((cong__3 (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
             (ASSUME `(((((cong__3 (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
             ))
           ) (MP  
              (MP  
               (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                 (conj))
               ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
               )
              ) (MP  
                 (MP  
                  (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                   (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                    (conj))
                  ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  )
                 ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                 ))))
         ) (SPEC `(C : mat_Point)` 
            (SPEC `(A : mat_Point)` (cn__congruencereflexive))))
       ) (SPEC `(C : mat_Point)` 
          (SPEC `(B : mat_Point)` (cn__congruencereflexive))))
     ) (SPEC `(B : mat_Point)` 
        (SPEC `(A : mat_Point)` (cn__congruencereflexive)))))))
 ;;


(*proposition__28B :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! G : mat_Point. (! H : mat_Point. ((((betS A) G) B) ==> ((((betS C) H) D) ==> (((((((rT B) G) H) G) H) D) ==> (((((oS B) D) G) H) ==> ((((par A) B) C) D))))))))))`*)
let proposition__28B =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(G : mat_Point)` 
     (GEN `(H : mat_Point)` 
      (DISCH `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
       (DISCH `((betS (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
        (DISCH `(((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
         (DISCH `(((oS (B : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
          (MP  
           (DISCH `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
            (MP  
             (DISCH `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))))` 
              (MP  
               (MP  
                (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))))) ==> (return : bool)))` 
                  (SPEC `\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point))))))))))))` 
                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                ) (GEN `(a : mat_Point)` 
                   (DISCH `ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))` 
                    (MP  
                     (MP  
                      (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (x : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (x : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (x : mat_Point)) (d : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))) ==> (return : bool)))` 
                        (SPEC `\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point))))))))))` 
                         (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                      ) (GEN `(b : mat_Point)` 
                         (DISCH `ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))` 
                          (MP  
                           (MP  
                            (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (x : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))) ==> (return : bool)))` 
                              (SPEC `\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point))))))))` 
                               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                            ) (GEN `(c : mat_Point)` 
                               (DISCH `ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (x : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))) ==> (return : bool)))` 
                                    (SPEC `\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point))))))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__ind))))
                                  ) (GEN `(d : mat_Point)` 
                                     (DISCH `ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (x : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (x : mat_Point)) (b : mat_Point)) (d : mat_Point)))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))) ==> (return : bool)))` 
                                          (SPEC `\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point))))` 
                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                            (ex__ind))))
                                        ) (GEN `(e : mat_Point)` 
                                           (DISCH `(mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (SPEC `(mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                (SPEC `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                 (DISCH `(mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (SPEC `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                      (SPEC `(((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                       (DISCH `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(((((congA (e : mat_Point)) (b : mat_Point)) (d : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `((eq (H : mat_Point)) (H : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                (DISCH `(eq (H : mat_Point)) (H : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `((out (G : mat_Point)) (H : mat_Point)) (H : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((out (G : mat_Point)) (H : mat_Point)) (H : mat_Point))) (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((((supp (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((((supp (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (e : mat_Point)) (b : mat_Point)) (d : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (G : mat_Point)) (G : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or ((eq (G : mat_Point)) (G : mat_Point))) ((mat_or ((eq (H : mat_Point)) (G : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((betS (G : mat_Point)) (G : mat_Point)) (H : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (G : mat_Point)) (H : mat_Point)) (A : mat_Point)) ==> mat_false) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (G : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__27
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__planeseparation
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (G : mat_Point)) (H : mat_Point)) (A : mat_Point))`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (G : mat_Point))) ((mat_or ((eq (H : mat_Point)) (G : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((betS (G : mat_Point)) (G : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (G : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((betS (G : mat_Point)) (G : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (G : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (G : mat_Point)) (A : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (e : mat_Point)) (b : mat_Point)) (d : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__supplements
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__supplementsymmetric
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((((supp (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (G : mat_Point)) (H : mat_Point)) (H : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (H : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or ((eq (H : mat_Point)) (H : mat_Point))) (((betS (G : mat_Point)) (H : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `((betS (G : mat_Point)) (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(eq (H : mat_Point)) (H : mat_Point)`
                                                                   )))
                                                                  ) (
                                                                  ASSUME `(neq (G : mat_Point)) (H : mat_Point)`
                                                                  ))))
                                                               ) (SPEC `(H : mat_Point)` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (eq__refl)
                                                                  )))
                                                             ) (MP  
                                                                (SPEC `(d : mat_Point)` 
                                                                 (SPEC `(b : mat_Point)` 
                                                                  (SPEC `(e : mat_Point)` 
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                ) (ASSUME `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                )))
                                                           ) (MP  
                                                              (DISCH `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                  (SPEC `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))))` 
                                                                   (SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))))`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(H : mat_Point)` 
                                                                  (SPEC `(G : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                 ) (ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                 ))))
                                                         ) (MP  
                                                            (SPEC `(c : mat_Point)` 
                                                             (SPEC `(b : mat_Point)` 
                                                              (SPEC `(a : mat_Point)` 
                                                               (SPEC `(H : mat_Point)` 
                                                                (SPEC `(G : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (lemma__equalanglessymmetric
                                                                  ))))))
                                                            ) (ASSUME `(((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                            )))))
                                                   ) (ASSUME `(mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))`
                                             ))))
                                       ) (ASSUME `ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))`
                                       ))))
                                 ) (ASSUME `ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))`
                                 ))))
                           ) (ASSUME `ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))`
                           ))))
                     ) (ASSUME `ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))`
                     ))))
               ) (ASSUME `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))))`
               ))
             ) (MP  
                (CONV_CONV_rule `((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) ==> (ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point))))))))))))))` 
                 (DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                  (MP  
                   (DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                    (MP  
                     (MP  
                      (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))))` 
                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))) ==> (return : bool)))` 
                        (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))))` 
                         (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                      ) (GEN `(x : mat_Point)` 
                         (DISCH `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))` 
                          (MP  
                           (MP  
                            (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))))` 
                             (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool)))` 
                              (SPEC `\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))` 
                               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                            ) (GEN `(x0 : mat_Point)` 
                               (DISCH `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))` 
                                (MP  
                                 (MP  
                                  (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))))` 
                                   (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool)))` 
                                    (SPEC `\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point))))))))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__ind))))
                                  ) (GEN `(x1 : mat_Point)` 
                                     (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))))` 
                                         (CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))) ==> (return : bool)))` 
                                          (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))))))` 
                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                            (ex__ind))))
                                        ) (GEN `(x2 : mat_Point)` 
                                           (DISCH `ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))))` 
                                               (CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))) ==> (return : bool)))` 
                                                (SPEC `\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))))` 
                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                  (ex__ind))))
                                              ) (GEN `(x3 : mat_Point)` 
                                                 (DISCH `(mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))))` 
                                                     (SPEC `(mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                      (SPEC `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                       (DISCH `(mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))))` 
                                                           (SPEC `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                            (SPEC `(((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                             (DISCH `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                              (MP  
                                                               (SPEC `(x : mat_Point)` 
                                                                (CONV_CONV_rule `! x4 : mat_Point. ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))) ==> (ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))))))` 
                                                                 (SPEC `\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point))))))))))))` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (ex__intro
                                                                   ))))
                                                               ) (MP  
                                                                  (SPEC `(x0 : mat_Point)` 
                                                                   (CONV_CONV_rule `! x4 : mat_Point. ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x4 : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x4 : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (x4 : mat_Point)) (d : mat_Point)))))))))) ==> (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (b : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(x2 : mat_Point)` 
                                                                   (CONV_CONV_rule `! x4 : mat_Point. ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x4 : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x4 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (x0 : mat_Point)) (d : mat_Point)))))))) ==> (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (x0 : mat_Point)) (d : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (c : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (x0 : mat_Point)) (d : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(x1 : mat_Point)` 
                                                                   (CONV_CONV_rule `! x4 : mat_Point. ((ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (e : mat_Point)) (x4 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (x0 : mat_Point)) (x4 : mat_Point)))))) ==> (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (x0 : mat_Point)) (d : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (x0 : mat_Point)) (d : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(x3 : mat_Point)` 
                                                                   (CONV_CONV_rule `! x4 : mat_Point. (((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x4 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (x4 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))) ==> (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (e : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (e : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (e : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `(((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)`
                                                                  ))))))))))
                                                         ) (ASSUME `(mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))`
                                                   ))))
                                             ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))`
                                             ))))
                                       ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))`
                                       ))))
                                 ) (ASSUME `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))`
                                 ))))
                           ) (ASSUME `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))`
                           ))))
                     ) (ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
                     ))
                   ) (ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
                   )))
                ) (ASSUME `(((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                )))
           ) (MP  
              (DISCH `(mat_and ((((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
               (MP  
                (MP  
                 (SPEC `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                  (SPEC `(mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                   (SPEC `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                    (DISCH `(mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                     (MP  
                      (MP  
                       (SPEC `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                        (SPEC `(((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                         (SPEC `(((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `(((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                          (DISCH `(((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                           (ASSUME `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                           )))
                      ) (ASSUME `(mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point))`
                      ))))
                ) (ASSUME `(mat_and ((((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point)))`
                ))
              ) (MP  
                 (SPEC `(D : mat_Point)` 
                  (SPEC `(B : mat_Point)` 
                   (SPEC `(H : mat_Point)` 
                    (SPEC `(G : mat_Point)` (lemma__samesidesymmetric))))
                 ) (ASSUME `(((oS (B : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                 )))))))))))))
 ;;


(*lemma__squareflip :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((sQ A) B) C) D) ==> ((((sQ B) A) D) C)))))`*)
let lemma__squareflip =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
       (MP  
        (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
         (MP  
          (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
           (MP  
            (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
             (MP  
              (DISCH `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
               (MP  
                (DISCH `((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                 (MP  
                  (DISCH `((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                   (MP  
                    (DISCH `((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                     (MP  
                      (CONV_CONV_rule `((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ==> ((((sQ (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                       (DISCH `(((sQ (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                        (ASSUME `(((sQ (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                        ))
                      ) (MP  
                         (MP  
                          (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                           (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                            (conj))
                          ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                          )
                         ) (MP  
                            (MP  
                             (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                              (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                               (conj))
                             ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                             )
                            ) (MP  
                               (MP  
                                (SPEC `(mat_and (((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                 (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                  (conj))
                                ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                )
                               ) (MP  
                                  (MP  
                                   (SPEC `(mat_and (((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                    (SPEC `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                     (conj))
                                   ) (ASSUME `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                   )
                                  ) (MP  
                                     (MP  
                                      (SPEC `(mat_and (((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                       (SPEC `((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                        (conj))
                                      ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                      )
                                     ) (MP  
                                        (MP  
                                         (SPEC `((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                          (SPEC `((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                           (conj))
                                         ) (ASSUME `((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                         )
                                        ) (ASSUME `((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                        ))))))))
                    ) (MP  
                       (MP  
                        (SPEC `((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                         (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                           (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                            (MP  
                             (MP  
                              (SPEC `((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                               (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                     (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                      (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                       (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                           (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                            (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                             (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                 (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                  (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((per (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                       (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                        (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                          (MP  
                                                           (SPEC `(D : mat_Point)` 
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (lemma__8__2)))
                                                           ) (ASSUME `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                               ))))
                                         ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                         ))))
                                   ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                   ))))
                             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                             ))))
                       ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))`
                       )))
                  ) (MP  
                     (MP  
                      (SPEC `((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                       (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                        (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                         (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                          (MP  
                           (MP  
                            (SPEC `((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                             (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                (MP  
                                 (MP  
                                  (SPEC `((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                   (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                    (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                     (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                         (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                          (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                           (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((per (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                      (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                        (MP  
                                                         (SPEC `(A : mat_Point)` 
                                                          (SPEC `(D : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (lemma__8__2)))
                                                         ) (ASSUME `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                             ))))
                                       ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                       ))))
                                 ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                 ))))
                           ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                           ))))
                     ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))`
                     )))
                ) (MP  
                   (MP  
                    (SPEC `((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                     (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                      (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                       (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                        (MP  
                         (MP  
                          (SPEC `((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                           (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                            (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                             (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                              (MP  
                               (MP  
                                (SPEC `((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                 (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                  (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                   (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                       (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                        (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                             (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                              (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                   (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                    (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                      (MP  
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (lemma__8__2)))
                                                       ) (ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                           ))))
                                     ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                     ))))
                               ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                               ))))
                         ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                         ))))
                   ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))`
                   )))
              ) (MP  
                 (MP  
                  (SPEC `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                   (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                    (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                     (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                      (MP  
                       (MP  
                        (SPEC `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                         (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                           (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                            (MP  
                             (MP  
                              (SPEC `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                               (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                 (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                     (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                      (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                       (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                           (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                            (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                 (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                  (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                    (MP  
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (lemma__8__2)))
                                                     ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                     ))))
                                               ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                         ))))
                                   ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                   ))))
                             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                             ))))
                       ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                       ))))
                 ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))`
                 )))
            ) (MP  
               (MP  
                (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                 (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                  (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                   (and__ind)))
                ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                   (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                    (MP  
                     (MP  
                      (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                       (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                        (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                          (MP  
                           (MP  
                            (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                             (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                               (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                   (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                    (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                     (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                         (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                          (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                               (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                 (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                       (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                        (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                         (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                             (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                              (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                )))
                                                           ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                     ))
                                                   ) (MP  
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (lemma__congruenceflip
                                                          ))))
                                                      ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                      )))))
                                             ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                             ))))
                                       ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                       ))))
                                 ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                 ))))
                           ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                           ))))
                     ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                     ))))
               ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))`
               )))
          ) (MP  
             (MP  
              (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
               (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                 (and__ind)))
              ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                 (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                  (MP  
                   (MP  
                    (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                     (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                      (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                        (MP  
                         (MP  
                          (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                           (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                            (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                             (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                              (MP  
                               (MP  
                                (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                 (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                  (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                   (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                       (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                        (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                             (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                              (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                (MP  
                                                 (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                     (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                      (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                       (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                            (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                             (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                              (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                              )))
                                                         ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))`
                                                   ))
                                                 ) (MP  
                                                    (SPEC `(A : mat_Point)` 
                                                     (SPEC `(D : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (lemma__congruenceflip
                                                        ))))
                                                    ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                    )))))
                                           ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                           ))))
                                     ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                     ))))
                               ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                               ))))
                         ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                         ))))
                   ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                   ))))
             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))`
             )))
        ) (MP  
           (MP  
            (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
             (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
               (and__ind)))
            ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
               (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                (MP  
                 (MP  
                  (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                   (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                    (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                      (MP  
                       (MP  
                        (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                         (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                           (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                            (MP  
                             (MP  
                              (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                               (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                 (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                      (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                           (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                            (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                             (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                              (MP  
                                               (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                    (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                     (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                         (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                            (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                            )))
                                                       ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                 ))
                                               ) (MP  
                                                  (SPEC `(D : mat_Point)` 
                                                   (SPEC `(C : mat_Point)` 
                                                    (SPEC `(B : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (lemma__congruenceflip)
                                                     )))
                                                  ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                  )))))
                                         ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                         ))))
                                   ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                   ))))
                             ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                             ))))
                       ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                       ))))
                 ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                 ))))
           ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))`
           )))
      ) (MP  
         (CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))))` 
          (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
           (MP  
            (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
             (MP  
              (MP  
               (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
                (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                 (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (and__ind)))
               ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                   (MP  
                    (MP  
                     (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
                      (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                       (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                         (MP  
                          (MP  
                           (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
                            (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                             (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                              (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
                                  (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                   (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                    (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
                                        (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                         (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
                                              (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                               (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                    (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (conj))
                                                   ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                   )
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                       (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (conj))
                                                      ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                      )
                                                     ) (MP  
                                                        (MP  
                                                         (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                           (conj))
                                                         ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                         )
                                                        ) (MP  
                                                           (MP  
                                                            (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                             (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                              (conj))
                                                            ) (ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                            )
                                                           ) (MP  
                                                              (MP  
                                                               (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (conj))
                                                               ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                               )
                                                              ) (MP  
                                                                 (MP  
                                                                  (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                   (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                  ) (
                                                                  ASSUME `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                 )))))))))
                                            ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                      ))))
                                ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                ))))
                          ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                          ))))
                    ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                    ))))
              ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))`
              ))
            ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))`
            )))
         ) (ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
         )))))))
 ;;


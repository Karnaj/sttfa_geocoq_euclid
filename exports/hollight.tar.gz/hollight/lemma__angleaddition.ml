(*lemma__angleaddition :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! e : mat_Point. (! f : mat_Point. (! p : mat_Point. (! q : mat_Point. (! r : mat_Point. ((((((((((sumA A) B) C) D) E) F) P) Q) R) ==> (((((((congA A) B) C) a) b) c) ==> (((((((congA D) E) F) d) e) f) ==> ((((((((((sumA a) b) c) d) e) f) p) q) r) ==> ((((((congA P) Q) R) p) q) r))))))))))))))))))))))`*)
let lemma__angleaddition =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(P : mat_Point)` 
       (GEN `(Q : mat_Point)` 
        (GEN `(R : mat_Point)` 
         (GEN `(a : mat_Point)` 
          (GEN `(b : mat_Point)` 
           (GEN `(c : mat_Point)` 
            (GEN `(d : mat_Point)` 
             (GEN `(e : mat_Point)` 
              (GEN `(f : mat_Point)` 
               (GEN `(p : mat_Point)` 
                (GEN `(q : mat_Point)` 
                 (GEN `(r : mat_Point)` 
                  (DISCH `((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                   (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                    (DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (d : mat_Point)) (e : mat_Point)) (f : mat_Point)` 
                     (DISCH `((((((((sumA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                      (MP  
                       (CONV_CONV_rule `(((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                        (DISCH `ex (\ S : mat_Point. ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point)))))` 
                         (MP  
                          (MP  
                           (SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (x : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (x : mat_Point)) (R : mat_Point)))) ==> (return : bool))) ==> ((ex (\ S : mat_Point. ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point)))))) ==> (return : bool)))` 
                             (SPEC `\ S : mat_Point. ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point))))` 
                              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                           ) (GEN `(S : mat_Point)` 
                              (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point)))` 
                               (MP  
                                (MP  
                                 (SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                  (SPEC `(mat_and ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point))` 
                                   (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                    (DISCH `(mat_and ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                        (SPEC `((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                         (SPEC `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                          (DISCH `((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `(((((((((sumA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) ==> ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                                             (DISCH `ex (\ s : mat_Point. ((mat_and ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (p : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and ((((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point))) (((betS (p : mat_Point)) (s : mat_Point)) (r : mat_Point)))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (p : mat_Point)) (q : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (x : mat_Point)) (q : mat_Point)) (r : mat_Point))) (((betS (p : mat_Point)) (x : mat_Point)) (r : mat_Point)))) ==> (return : bool))) ==> ((ex (\ s : mat_Point. ((mat_and ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (p : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and ((((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point))) (((betS (p : mat_Point)) (s : mat_Point)) (r : mat_Point)))))) ==> (return : bool)))` 
                                                  (SPEC `\ s : mat_Point. ((mat_and ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (p : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and ((((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point))) (((betS (p : mat_Point)) (s : mat_Point)) (r : mat_Point))))` 
                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                    (ex__ind))))
                                                ) (GEN `(s : mat_Point)` 
                                                   (DISCH `(mat_and ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (p : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and ((((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point))) (((betS (p : mat_Point)) (s : mat_Point)) (r : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                       (SPEC `(mat_and ((((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point))) (((betS (p : mat_Point)) (s : mat_Point)) (r : mat_Point))` 
                                                        (SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (p : mat_Point)) (q : mat_Point)) (s : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (p : mat_Point)) (q : mat_Point)) (s : mat_Point)` 
                                                         (DISCH `(mat_and ((((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point))) (((betS (p : mat_Point)) (s : mat_Point)) (r : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                             (SPEC `((betS (p : mat_Point)) (s : mat_Point)) (r : mat_Point)` 
                                                              (SPEC `(((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                               (DISCH `((betS (p : mat_Point)) (s : mat_Point)) (r : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `((nCol (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `((nCol (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (p : mat_Point)) (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (s : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ G : mat_Point. ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point))) ((((cong (q : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (q : mat_Point)) (p : mat_Point)) (x : mat_Point))) ((((cong (q : mat_Point)) (x : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point))) ((((cong (q : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (P : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ G : mat_Point. ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point))) ((((cong (q : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point))) ((((cong (q : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (q : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (q : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ H29 : mat_Point. ((mat_and (((out (q : mat_Point)) (s : mat_Point)) (H29 : mat_Point))) ((((cong (q : mat_Point)) (H29 : mat_Point)) (Q : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (q : mat_Point)) (s : mat_Point)) (x : mat_Point))) ((((cong (q : mat_Point)) (x : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ==> (return : bool))) ==> ((ex (\ H30 : mat_Point. ((mat_and (((out (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point))) ((((cong (q : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (S : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ H30 : mat_Point. ((mat_and (((out (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point))) ((((cong (q : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(H30 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point))) ((((cong (q : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (q : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (q : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ K : mat_Point. ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point))) ((((cong (q : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (q : mat_Point)) (r : mat_Point)) (x : mat_Point))) ((((cong (q : mat_Point)) (x : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ==> (return : bool))) ==> ((ex (\ K : mat_Point. ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point))) ((((cong (q : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (R : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ K : mat_Point. ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point))) ((((cong (q : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point))) ((((cong (q : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (q : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (q : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (p : mat_Point)) (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (G : mat_Point)) (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (e : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H30 : mat_Point)) (q : mat_Point)) (K : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((out (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point))) ==> ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    DISCH `((((supp (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))) ==> ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((rT (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (p : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (q : mat_Point))) ((mat_or ((eq (G : mat_Point)) (q : mat_Point))) ((mat_or ((eq (q : mat_Point)) (q : mat_Point))) ((mat_or (((betS (q : mat_Point)) (G : mat_Point)) (q : mat_Point))) ((mat_or (((betS (G : mat_Point)) (q : mat_Point)) (q : mat_Point))) (((betS (G : mat_Point)) (q : mat_Point)) (q : mat_Point))))))) ==> ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (p : mat_Point)) (X : mat_Point)) (r : mat_Point))) ((mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (X : mat_Point))) (((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)))))) ==> ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    DISCH `(((tS (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (r : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (q : mat_Point)) (H30 : mat_Point))) ((mat_or ((eq (q : mat_Point)) (q : mat_Point))) ((mat_or ((eq (H30 : mat_Point)) (q : mat_Point))) ((mat_or (((betS (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point))) ((mat_or (((betS (q : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((betS (q : mat_Point)) (q : mat_Point)) (H30 : mat_Point))))))) ==> ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (H30 : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (q : mat_Point)) (K : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (K : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (q : mat_Point)) (G : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (G : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (K : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H30 : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (G : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (K : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (P : mat_Point)) (S : mat_Point))) ((mat_or ((eq (P : mat_Point)) (R : mat_Point))) ((mat_or ((eq (S : mat_Point)) (R : mat_Point))) ((mat_or (((betS (S : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_or (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (R : mat_Point)) (S : mat_Point))))))) ==> ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (P : mat_Point)) (S : mat_Point))) ((mat_or ((eq (P : mat_Point)) (P : mat_Point))) ((mat_or ((eq (S : mat_Point)) (P : mat_Point))) ((mat_or (((betS (S : mat_Point)) (P : mat_Point)) (P : mat_Point))) ((mat_or (((betS (P : mat_Point)) (S : mat_Point)) (P : mat_Point))) (((betS (P : mat_Point)) (P : mat_Point)) (S : mat_Point))))))) ==> ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (U : mat_Point)) (q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))))) ==> ((((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (U : mat_Point)) (q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (U : mat_Point)) (q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (V : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (x : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (R : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (R : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (R : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (x : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))) ==> (ex (\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (v : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (v : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point))) ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point))) ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (K : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (R : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (K : mat_Point)) (P : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (R : mat_Point)) (q : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (q : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (P : mat_Point)) (q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (q : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((nCol (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((nCol (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((nCol (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((nCol (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (R : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((nCol (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((nCol (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (Q : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (Q : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((nCol (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((nCol (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((nCol (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((nCol (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((nCol (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (S : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (S : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (R : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (S : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (S : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (S : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (P : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (S : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (S : mat_Point))) ((neq (P : mat_Point)) (R : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (P : mat_Point)) (P : mat_Point))) ((mat_or ((eq (S : mat_Point)) (P : mat_Point))) ((mat_or (((betS (S : mat_Point)) (P : mat_Point)) (P : mat_Point))) ((mat_or (((betS (P : mat_Point)) (S : mat_Point)) (P : mat_Point))) (((betS (P : mat_Point)) (P : mat_Point)) (S : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (S : mat_Point)) (P : mat_Point))) ((mat_or (((betS (S : mat_Point)) (P : mat_Point)) (P : mat_Point))) ((mat_or (((betS (P : mat_Point)) (S : mat_Point)) (P : mat_Point))) (((betS (P : mat_Point)) (P : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (P : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(eq (P : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (P : mat_Point)) (R : mat_Point))) ((mat_or ((eq (S : mat_Point)) (R : mat_Point))) ((mat_or (((betS (S : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_or (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (R : mat_Point)) (S : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (S : mat_Point)) (R : mat_Point))) ((mat_or (((betS (S : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_or (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (R : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (S : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_or (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (R : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (S : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) (((nCol (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) (((nCol (S : mat_Point)) (Q : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) (((nCol (S : mat_Point)) (Q : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (S : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) (((nCol (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (S : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) (((nCol (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) (((nCol (S : mat_Point)) (Q : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (S : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (S : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) (((nCol (S : mat_Point)) (Q : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) (((nCol (S : mat_Point)) (Q : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (S : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) (((nCol (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) (((nCol (S : mat_Point)) (Q : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (S : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) (((nCol (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (R : mat_Point)) (R : mat_Point))) (((betS (Q : mat_Point)) (R : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (R : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (P : mat_Point)) (P : mat_Point))) (((betS (Q : mat_Point)) (P : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (P : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)) ==> (((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)) ==> ((eq (R : mat_Point)) (R : mat_Point)))) ==> (((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))) ==> ((eq (R : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)) ==> (((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)) ==> ((eq (P : mat_Point)) (P : mat_Point)))) ==> (((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))) ==> ((eq (P : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (K : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (K : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (K : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (K : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (H30 : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (((((((rT (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)) ==> ((((out (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> (((((tS (E0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) ==> (((betS (A0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (((((((rT (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)) ==> ((((out (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> (((((tS (E0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) ==> (((betS (A0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)))))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((((rT (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (K : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    GEN `(E0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (E0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((((supp (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (E0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((((supp (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (E0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__14
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((((rT (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (E0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (E0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (q : mat_Point)) (q : mat_Point))) (((betS (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (q : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (H30 : mat_Point)) (q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H30 : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H30 : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H30 : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H30 : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (q : mat_Point)) (H30 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (K : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (K : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (K : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (K : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (G : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (G : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (G : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (G : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (G : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__9__5
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((tS (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (q : mat_Point)) (G : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (H30 : mat_Point)) (q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (q : mat_Point)) (G : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (q : mat_Point)) (G : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (q : mat_Point)) (G : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (q : mat_Point)) (G : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (K : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (K : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (K : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (K : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (K : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__9__5
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((tS (r : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (q : mat_Point)) (K : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (H30 : mat_Point)) (q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (q : mat_Point)) (K : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (q : mat_Point)) (K : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (q : mat_Point)) (K : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (q : mat_Point)) (K : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (q : mat_Point)) (q : mat_Point))) ((mat_or ((eq (H30 : mat_Point)) (q : mat_Point))) ((mat_or (((betS (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point))) ((mat_or (((betS (q : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((betS (q : mat_Point)) (q : mat_Point)) (H30 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H30 : mat_Point)) (q : mat_Point))) ((mat_or (((betS (H30 : mat_Point)) (q : mat_Point)) (q : mat_Point))) ((mat_or (((betS (q : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((betS (q : mat_Point)) (q : mat_Point)) (H30 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (q : mat_Point)) (q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (r : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (r : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (r : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (r : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (r : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (p : mat_Point)) (x : mat_Point)) (r : mat_Point))) ((mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (x : mat_Point))) (((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (p : mat_Point)) (X : mat_Point)) (r : mat_Point))) ((mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (X : mat_Point))) (((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (p : mat_Point)) (X : mat_Point)) (r : mat_Point))) ((mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (X : mat_Point))) (((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point))) (((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (p : mat_Point)) (s : mat_Point)) (r : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (p : mat_Point)) (s : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (q : mat_Point)) (p : mat_Point)) (H30 : mat_Point))) ((mat_and (((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point))) ((mat_and (((nCol (H30 : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((nCol (H30 : mat_Point)) (q : mat_Point)) (p : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point))) ((mat_and (((nCol (H30 : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((nCol (H30 : mat_Point)) (q : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (p : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (q : mat_Point)) (p : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point))) ((mat_and (((nCol (H30 : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((nCol (H30 : mat_Point)) (q : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H30 : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((nCol (H30 : mat_Point)) (q : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H30 : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((nCol (H30 : mat_Point)) (q : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (p : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((nCol (H30 : mat_Point)) (q : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (H30 : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H30 : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (p : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((nCol (H30 : mat_Point)) (q : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H30 : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (p : mat_Point)) (H30 : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (p : mat_Point)) (H30 : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (H30 : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (p : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((nCol (H30 : mat_Point)) (q : mat_Point)) (p : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H30 : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((nCol (H30 : mat_Point)) (q : mat_Point)) (p : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point))) ((mat_and (((nCol (H30 : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((nCol (H30 : mat_Point)) (q : mat_Point)) (p : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (q : mat_Point)) (p : mat_Point)) (H30 : mat_Point))) ((mat_and (((nCol (q : mat_Point)) (H30 : mat_Point)) (p : mat_Point))) ((mat_and (((nCol (H30 : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) (((nCol (H30 : mat_Point)) (q : mat_Point)) (p : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (p : mat_Point)) (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (q : mat_Point)) (H30 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (q : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (p : mat_Point)) (q : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (q : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (q : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (q : mat_Point))) ((mat_or ((eq (q : mat_Point)) (q : mat_Point))) ((mat_or (((betS (q : mat_Point)) (G : mat_Point)) (q : mat_Point))) ((mat_or (((betS (G : mat_Point)) (q : mat_Point)) (q : mat_Point))) (((betS (G : mat_Point)) (q : mat_Point)) (q : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (q : mat_Point)) (q : mat_Point))) ((mat_or (((betS (q : mat_Point)) (G : mat_Point)) (q : mat_Point))) ((mat_or (((betS (G : mat_Point)) (q : mat_Point)) (q : mat_Point))) (((betS (G : mat_Point)) (q : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (q : mat_Point)) (G : mat_Point)) (q : mat_Point))) ((mat_or (((betS (G : mat_Point)) (q : mat_Point)) (q : mat_Point))) (((betS (G : mat_Point)) (q : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (q : mat_Point)) (q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)) ==> (((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)) ==> ((eq (q : mat_Point)) (q : mat_Point)))) ==> (((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))) ==> ((eq (q : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (q : mat_Point)) (G : mat_Point))) ((mat_and (((col (p : mat_Point)) (G : mat_Point)) (q : mat_Point))) ((mat_and (((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (G : mat_Point)) (p : mat_Point))) (((col (G : mat_Point)) (p : mat_Point)) (q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (G : mat_Point)) (q : mat_Point))) ((mat_and (((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (G : mat_Point)) (p : mat_Point))) (((col (G : mat_Point)) (p : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (G : mat_Point)) (q : mat_Point))) ((mat_and (((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (G : mat_Point)) (p : mat_Point))) (((col (G : mat_Point)) (p : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (G : mat_Point)) (p : mat_Point))) (((col (G : mat_Point)) (p : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (G : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (G : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (G : mat_Point)) (p : mat_Point))) (((col (G : mat_Point)) (p : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (q : mat_Point)) (G : mat_Point)) (p : mat_Point))) (((col (G : mat_Point)) (p : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (q : mat_Point)) (G : mat_Point)) (p : mat_Point))) (((col (G : mat_Point)) (p : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (G : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (q : mat_Point)) (G : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (q : mat_Point)) (G : mat_Point)) (p : mat_Point))) (((col (G : mat_Point)) (p : mat_Point)) (q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (G : mat_Point)) (p : mat_Point))) (((col (G : mat_Point)) (p : mat_Point)) (q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (G : mat_Point)) (q : mat_Point))) ((mat_and (((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (G : mat_Point)) (p : mat_Point))) (((col (G : mat_Point)) (p : mat_Point)) (q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (q : mat_Point)) (G : mat_Point))) ((mat_and (((col (p : mat_Point)) (G : mat_Point)) (q : mat_Point))) ((mat_and (((col (G : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (G : mat_Point)) (p : mat_Point))) (((col (G : mat_Point)) (p : mat_Point)) (q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (p : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (p : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (p : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (p : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (p : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (s : mat_Point)) (q : mat_Point)) (H30 : mat_Point))) ((mat_and (((col (s : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) ((mat_and (((col (H30 : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point))) (((col (H30 : mat_Point)) (s : mat_Point)) (q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (s : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) ((mat_and (((col (H30 : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point))) (((col (H30 : mat_Point)) (s : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (s : mat_Point)) (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (s : mat_Point)) (q : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (s : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) ((mat_and (((col (H30 : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point))) (((col (H30 : mat_Point)) (s : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H30 : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point))) (((col (H30 : mat_Point)) (s : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (s : mat_Point)) (H30 : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (s : mat_Point)) (H30 : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H30 : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point))) (((col (H30 : mat_Point)) (s : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point))) (((col (H30 : mat_Point)) (s : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H30 : mat_Point)) (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H30 : mat_Point)) (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point))) (((col (H30 : mat_Point)) (s : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H30 : mat_Point)) (s : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H30 : mat_Point)) (s : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point))) (((col (H30 : mat_Point)) (s : mat_Point)) (q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H30 : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point))) (((col (H30 : mat_Point)) (s : mat_Point)) (q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (s : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) ((mat_and (((col (H30 : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point))) (((col (H30 : mat_Point)) (s : mat_Point)) (q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (s : mat_Point)) (q : mat_Point)) (H30 : mat_Point))) ((mat_and (((col (s : mat_Point)) (H30 : mat_Point)) (q : mat_Point))) ((mat_and (((col (H30 : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and (((col (q : mat_Point)) (H30 : mat_Point)) (s : mat_Point))) (((col (H30 : mat_Point)) (s : mat_Point)) (q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (P : mat_Point)) (x : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (x : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (x : mat_Point)) (Z : mat_Point)))))))))) ==> (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (P : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (P : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (P : mat_Point)) (S : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (S : mat_Point)) (x : mat_Point)))))))) ==> (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (P : mat_Point)) (S : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (S : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (P : mat_Point)) (S : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (S : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((((supp (P : mat_Point)) (S : mat_Point)) (x : mat_Point)) (V : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (x : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (S : mat_Point)) (R : mat_Point)))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (P : mat_Point)) (S : mat_Point)) (U : mat_Point)) (V : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (S : mat_Point)) (R : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (P : mat_Point)) (S : mat_Point)) (U : mat_Point)) (V : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (U : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (S : mat_Point)) (R : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((((supp (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (x : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (x : mat_Point)) (S : mat_Point)) (R : mat_Point)))) ==> (ex (\ V : mat_Point. ((mat_and (((((supp (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (S : mat_Point)) (R : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((((supp (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (V : mat_Point)) (S : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((((supp (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (Q : mat_Point)) (Q : mat_Point))) (((betS (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (S : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (S : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (S : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)) ==> (((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)) ==> ((eq (Q : mat_Point)) (Q : mat_Point)))) ==> (((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))) ==> ((eq (Q : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesflip
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (H30 : mat_Point)) (K : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (H30 : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((((congA (q : mat_Point)) (K : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (q : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (q : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H30 : mat_Point)) (q : mat_Point)) (K : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (H30 : mat_Point)) (q : mat_Point)) (K : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (H30 : mat_Point)) (q : mat_Point)) (K : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (H30 : mat_Point)) (q : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (q : mat_Point)) (G : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) ((((((congA (q : mat_Point)) (H30 : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (q : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (q : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (q : mat_Point)) (H30 : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (G : mat_Point)) (q : mat_Point)) (H30 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (G : mat_Point)) (q : mat_Point)) (H30 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (d : mat_Point)) (e : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (d : mat_Point)) (e : mat_Point)) (f : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H30 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (p : mat_Point)) (q : mat_Point)) (s : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (p : mat_Point)) (q : mat_Point)) (s : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point))) ((((cong (q : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ K : mat_Point. ((mat_and (((out (q : mat_Point)) (r : mat_Point)) (K : mat_Point))) ((((cong (q : mat_Point)) (K : mat_Point)) (Q : mat_Point)) (R : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (q : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (R : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (q : mat_Point)) (s : mat_Point)) (H30 : mat_Point))) ((((cong (q : mat_Point)) (H30 : mat_Point)) (Q : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ H29 : mat_Point. ((mat_and (((out (q : mat_Point)) (s : mat_Point)) (H29 : mat_Point))) ((((cong (q : mat_Point)) (H29 : mat_Point)) (Q : mat_Point)) (S : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (q : mat_Point)) (s : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (S : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point))) ((((cong (q : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ G : mat_Point. ((mat_and (((out (q : mat_Point)) (p : mat_Point)) (G : mat_Point))) ((((cong (q : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (P : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (q : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (s : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (s : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (s : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (s : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (r : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (r : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (q : mat_Point)) (s : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (s : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (s : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (s : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (s : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (s : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (r : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (r : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (q : mat_Point)) (r : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((mat_and ((neq (s : mat_Point)) (r : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (r : mat_Point)) (q : mat_Point))) ((neq (r : mat_Point)) (s : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (s : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (p : mat_Point)) (q : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (p : mat_Point)) (s : mat_Point))) ((mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (p : mat_Point)) (s : mat_Point))) ((mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (p : mat_Point)) (s : mat_Point))) ((mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (p : mat_Point)) (s : mat_Point))) ((mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (q : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (p : mat_Point)) (s : mat_Point))) ((mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (p : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (p : mat_Point)) (s : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (s : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (s : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (s : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (s : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (q : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (p : mat_Point)) (s : mat_Point))) ((mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (p : mat_Point)) (s : mat_Point))) ((mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (p : mat_Point)) (q : mat_Point))) ((mat_and ((neq (q : mat_Point)) (s : mat_Point))) ((mat_and ((neq (p : mat_Point)) (s : mat_Point))) ((mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((mat_and ((neq (s : mat_Point)) (q : mat_Point))) ((neq (s : mat_Point)) (p : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (q : mat_Point)) (s : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (p : mat_Point)) (q : mat_Point)) (s : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (Q : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (Q : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((neq (R : mat_Point)) (S : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (P : mat_Point)) (S : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (P : mat_Point))) ((mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (P : mat_Point)) (S : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (P : mat_Point))) ((mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (P : mat_Point)) (S : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (P : mat_Point))) ((mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (S : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (P : mat_Point))) ((mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (S : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (P : mat_Point))) ((mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (P : mat_Point))) ((mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (P : mat_Point))) ((mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (Q : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (P : mat_Point))) ((mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (S : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (P : mat_Point))) ((mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (P : mat_Point)) (S : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (P : mat_Point))) ((mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (S : mat_Point))) ((mat_and ((neq (P : mat_Point)) (S : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (P : mat_Point))) ((mat_and ((neq (S : mat_Point)) (Q : mat_Point))) ((neq (S : mat_Point)) (P : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)`
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                   ) (
                                                                   ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                   )))))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)`
                                                                    )))))))
                                                           ) (ASSUME `(mat_and ((((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point))) (((betS (p : mat_Point)) (s : mat_Point)) (r : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (p : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and ((((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point))) (((betS (p : mat_Point)) (s : mat_Point)) (r : mat_Point)))`
                                                     ))))
                                               ) (ASSUME `ex (\ s : mat_Point. ((mat_and ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (p : mat_Point)) (q : mat_Point)) (s : mat_Point))) ((mat_and ((((((congA (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (s : mat_Point)) (q : mat_Point)) (r : mat_Point))) (((betS (p : mat_Point)) (s : mat_Point)) (r : mat_Point)))))`
                                               )))
                                            ) (ASSUME `((((((((sumA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point)) (f : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                            ))))
                                      ) (ASSUME `(mat_and ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point)))`
                                ))))
                          ) (ASSUME `ex (\ S : mat_Point. ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (S : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((betS (P : mat_Point)) (S : mat_Point)) (R : mat_Point)))))`
                          )))
                       ) (ASSUME `((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                       )))))))))))))))))))))))
 ;;


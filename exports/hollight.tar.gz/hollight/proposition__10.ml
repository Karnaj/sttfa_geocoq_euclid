(*proposition__10 :  |- `! A : mat_Point. (! B : mat_Point. (((neq A) B) ==> (ex (\ X : mat_Point. ((mat_and (((betS A) X) B)) ((((cong X) A) X) B))))))`*)
let proposition__10 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
   (MP  
    (DISCH `ex (\ C : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
     (MP  
      (MP  
       (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
        (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ C : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
         (SPEC `\ C : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
          (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
       ) (GEN `(C : mat_Point)` 
          (DISCH `(mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
           (MP  
            (MP  
             (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
              (SPEC `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
               (SPEC `((equilateral (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (and__ind)))
             ) (DISCH `((equilateral (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (MP  
                  (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point)))))` 
                   (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                    (MP  
                     (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                      (MP  
                       (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                        (MP  
                         (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                          (MP  
                           (CONV_CONV_rule `(((eq (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point)))))` 
                            (DISCH `mat_not ((eq (C : mat_Point)) (B : mat_Point))` 
                             (MP  
                              (DISCH `ex (\ D : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
                                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                   (SPEC `\ D : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)
                                    )))
                                 ) (GEN `(D : mat_Point)` 
                                    (DISCH `(mat_and (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
                                        (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                          (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                           (MP  
                                            (MP  
                                             (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
                                              (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                               (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                 (MP  
                                                  (CONV_CONV_rule `(((eq (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point)))))` 
                                                   (DISCH `mat_not ((eq (C : mat_Point)) (A : mat_Point))` 
                                                    (MP  
                                                     (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
                                                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                                          (SPEC `\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                                            (ex__ind))))
                                                        ) (GEN `(E : mat_Point)` 
                                                           (DISCH `(mat_and (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
                                                               (SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                (SPEC `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                 (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ F : mat_Point. ((mat_and (((betS (D : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (D : mat_Point)) (x : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (x : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (D : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ F : mat_Point. ((mat_and (((betS (D : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (D : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (D : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (x : mat_Point)) (F : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (F : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (B : mat_Point)) (F : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ G : mat_Point. ((mat_and (((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (F : mat_Point))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and (((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ G : mat_Point. ((mat_and (((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((mat_and (((betS (E : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((((cut (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((((cut (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (D : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((((cong (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (X : mat_Point)) (A : mat_Point)) (X : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__interior5
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (G : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((((cong (G : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (G : mat_Point)) ==> (((((cong (F : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) ==> ((((betS (D : mat_Point)) (G : mat_Point)) (A : mat_Point)) ==> (((((cong (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (G : mat_Point)) ==> (((((cong (F : mat_Point)) (D : mat_Point)) (G : mat_Point)) (E : mat_Point)) ==> ((((betS (B : mat_Point)) (G : mat_Point)) (E : mat_Point)) ==> ((((betS (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) ==> ((((((cut (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) ==> ((((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((cong (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> ((((betS (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> (((((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> ((((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> ((((((cut (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((((cong (x : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((cong (F : mat_Point)) (B : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> ((((betS (D : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> (((((cong (F : mat_Point)) (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (F : mat_Point)) (D : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> ((((betS (B : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> ((((betS (E : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((((cut (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ G0 : mat_Point. ((((betS (A : mat_Point)) (G0 : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (G0 : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((((cong (G0 : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (G0 : mat_Point)) ==> (((((cong (F : mat_Point)) (B : mat_Point)) (G0 : mat_Point)) (A : mat_Point)) ==> ((((betS (D : mat_Point)) (G0 : mat_Point)) (A : mat_Point)) ==> (((((cong (F : mat_Point)) (A : mat_Point)) (G0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (G0 : mat_Point)) ==> (((((cong (F : mat_Point)) (D : mat_Point)) (G0 : mat_Point)) (E : mat_Point)) ==> ((((betS (B : mat_Point)) (G0 : mat_Point)) (E : mat_Point)) ==> ((((betS (E : mat_Point)) (G0 : mat_Point)) (B : mat_Point)) ==> ((((((cut (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G0 : mat_Point)) ==> ((((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((((cut (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (G : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (G : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((cut (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__twolines
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((((cut (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((cut (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (D : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (E : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennesspreserved
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (G : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__interior5
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((((cong (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__interior5
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (F : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((((cong (D : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((((cong (D : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__differenceofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ G : mat_Point. ((mat_and (((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) (F : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    proposition__03
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (F : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (B : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__5__line
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (F : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__inner
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (D : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (D : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__inner
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                   )))))
                                                             ) (ASSUME `(mat_and (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                       ))
                                                     ) (MP  
                                                        (MP  
                                                         (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (A : mat_Point))) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (SPEC `(C : mat_Point)` 
                                                              (lemma__extension
                                                              )))))
                                                         ) (ASSUME `mat_not ((eq (C : mat_Point)) (A : mat_Point))`
                                                         )
                                                        ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                        ))))
                                                  ) (DISCH `(eq (C : mat_Point)) (A : mat_Point)` 
                                                     (MP  
                                                      (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                                       (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                        (MP  
                                                         (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (col__nCol__False
                                                               )))
                                                            ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                            )
                                                           ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                           ))
                                                         ) (MP  
                                                            (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                 (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                              ))
                                                            ) (MP  
                                                               (SPEC `(A : mat_Point)` 
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (lemma__collinearorder
                                                                  )))
                                                               ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                               )))))
                                                      ) (MP  
                                                         (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                          (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                           (or__intror))
                                                         ) (MP  
                                                            (SPEC `(mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                             (SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                                              (or__intror))
                                                            ) (MP  
                                                               (SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                (SPEC `(eq (C : mat_Point)) (A : mat_Point)` 
                                                                 (or__introl)
                                                                )
                                                               ) (ASSUME `(eq (C : mat_Point)) (A : mat_Point)`
                                                               )))))))))
                                            ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                      ))))
                                ) (ASSUME `ex (\ D : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                ))
                              ) (MP  
                                 (MP  
                                  (SPEC `ex (\ D : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                   (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                    (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                      (MP  
                                       (MP  
                                        (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (B : mat_Point))) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(A : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (lemma__extension)))))
                                        ) (ASSUME `mat_not ((eq (C : mat_Point)) (B : mat_Point))`
                                        )
                                       ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                       ))))
                                 ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                 ))))
                           ) (DISCH `(eq (C : mat_Point)) (B : mat_Point)` 
                              (MP  
                               (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                 (MP  
                                  (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (MP  
                                    (MP  
                                     (SPEC `(C : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (col__nCol__False)))
                                     ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                     )
                                    ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                    ))
                                  ) (MP  
                                     (MP  
                                      (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                        (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                          (MP  
                                           (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                 (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                      (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                       (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                            (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                             (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                  (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                             ))
                                           ) (MP  
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (lemma__collinearorder)))
                                              ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                              )))))
                                     ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                     ))))
                               ) (MP  
                                  (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                   (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                    (or__intror))
                                  ) (MP  
                                     (SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                      (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                       (or__intror))
                                     ) (MP  
                                        (SPEC `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                         (SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                          (or__introl))
                                        ) (ASSUME `(eq (C : mat_Point)) (B : mat_Point)`
                                        )))))))
                         ) (MP  
                            (MP  
                             (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                               (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                 (MP  
                                  (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                       (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                              (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                               )))
                                          ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                    ))
                                  ) (MP  
                                     (SPEC `(B : mat_Point)` 
                                      (SPEC `(C : mat_Point)` 
                                       (SPEC `(C : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (lemma__congruenceflip))))
                                     ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                     )))))
                            ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                            )))
                       ) (MP  
                          (MP  
                           (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                            (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                             (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                               (MP  
                                (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                    (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                      (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                       (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                       )))
                                  ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                  ))
                                ) (MP  
                                   (SPEC `(A : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(C : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (lemma__doublereverse))))
                                   ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                   )))))
                          ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                          )))
                     ) (MP  
                        (CONV_CONV_rule `(((equilateral (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                         (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                          (MP  
                           (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                            (MP  
                             (MP  
                              (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                               (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                  (MP  
                                   (MP  
                                    (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                     (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (conj))
                                    ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                    )
                                   ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                   ))))
                             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                             ))
                           ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                           )))
                        ) (ASSUME `((equilateral (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                        ))))
                  ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  ))))
            ) (ASSUME `(mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
            ))))
      ) (ASSUME `ex (\ C : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
      ))
    ) (MP  
       (SPEC `(B : mat_Point)` (SPEC `(A : mat_Point)` (proposition__01))
       ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)))))
 ;;


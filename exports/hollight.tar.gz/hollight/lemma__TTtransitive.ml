(*lemma__TTtransitive :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! G : mat_Point. (! H : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (! S : mat_Point. (((((((((tT A) B) C) D) E) F) G) H) ==> (((((((((tT E) F) G) H) P) Q) R) S) ==> ((((((((tT A) B) C) D) P) Q) R) S))))))))))))))`*)
let lemma__TTtransitive =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(G : mat_Point)` 
       (GEN `(H : mat_Point)` 
        (GEN `(P : mat_Point)` 
         (GEN `(Q : mat_Point)` 
          (GEN `(R : mat_Point)` 
           (GEN `(S : mat_Point)` 
            (DISCH `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
             (DISCH `(((((((tT (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
              (MP  
               (CONV_CONV_rule `((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> ((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                (DISCH `ex (\ K : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point)))))` 
                 (MP  
                  (MP  
                   (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                    (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (x : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ K : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point)))))) ==> (return : bool)))` 
                     (SPEC `\ K : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point))))` 
                      (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                   ) (GEN `(K : mat_Point)` 
                      (DISCH `(mat_and (((betS (E : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point)))` 
                       (MP  
                        (MP  
                         (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                          (SPEC `(mat_and ((((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point))` 
                           (SPEC `((betS (E : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((betS (E : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                            (DISCH `(mat_and ((((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                (SPEC `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                 (SPEC `(((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                  (DISCH `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point)) ==> ((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                     (DISCH `ex (\ J : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point)))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ J : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point)))))) ==> (return : bool)))` 
                                          (SPEC `\ J : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point))))` 
                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                            (ex__ind))))
                                        ) (GEN `(J : mat_Point)` 
                                           (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                               (SPEC `(mat_and ((((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point))` 
                                                (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                 (DISCH `(mat_and ((((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                     (SPEC `(((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                      (SPEC `(((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (DISCH `(((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                        (MP  
                                                         (CONV_CONV_rule `((((((((tT (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                          (DISCH `ex (\ L : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (L : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (L : mat_Point)))))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ L : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (L : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (L : mat_Point)))))) ==> (return : bool)))` 
                                                               (SPEC `\ L : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (L : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (L : mat_Point))))` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (ex__ind))))
                                                             ) (GEN `(L : mat_Point)` 
                                                                (DISCH `(mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (L : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (L : mat_Point)))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (Q : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((betS (P : mat_Point)) (Q : mat_Point)) (L : mat_Point)` 
                                                                   (DISCH `(mat_and ((((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (L : mat_Point)) ==> ((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (x : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (M : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (E : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (E : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (K : mat_Point)) (K : mat_Point)) ==> ((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((betS (X : mat_Point)) (F : mat_Point)) (K : mat_Point))))) ==> ((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (F : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (F : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (H : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (K : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (P : mat_Point)) (L : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (A : mat_Point)) (X : mat_Point)))))) ==> ((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (X : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (X : mat_Point)))))) ==> ((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (x : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (x : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (X : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (X : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (Q : mat_Point)) (L : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (Q : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) (L : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (A : mat_Point)) (x : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (A : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (A : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (A : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (P : mat_Point)) (L : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (P : mat_Point)) (L : mat_Point)) (A : mat_Point)) (J : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__lessthantransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (K : mat_Point)) (K : mat_Point)) ==> (((neq (F : mat_Point)) (K : mat_Point)) ==> ((((out (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) ==> ((((out (F : mat_Point)) (K : mat_Point)) (K : mat_Point)) ==> (((((cong (F : mat_Point)) (K : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (K : mat_Point)) (M : mat_Point)) ==> ((((betS (E : mat_Point)) (F : mat_Point)) (K : mat_Point)) ==> (((((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> (((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point)) ==> (((((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> (((eq (K : mat_Point)) (K : mat_Point)) ==> (((neq (F : mat_Point)) (K : mat_Point)) ==> ((((out (F : mat_Point)) (K : mat_Point)) (M : mat_Point)) ==> ((((out (F : mat_Point)) (K : mat_Point)) (K : mat_Point)) ==> (((((cong (F : mat_Point)) (K : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (K : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (E : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> (((((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> (((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (M : mat_Point)) ==> (((((lt (E : mat_Point)) (M : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> (((eq (M : mat_Point)) (M : mat_Point)) ==> (((neq (F : mat_Point)) (M : mat_Point)) ==> ((((out (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) ==> ((((out (F : mat_Point)) (M : mat_Point)) (M : mat_Point)) ==> (((((cong (F : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (M : mat_Point))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (M : mat_Point)) ==> ((((betS (E : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> (((((cong (F : mat_Point)) (x : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> (((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x : mat_Point)) ==> (((((lt (E : mat_Point)) (x : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> (((eq (x : mat_Point)) (x : mat_Point)) ==> (((neq (F : mat_Point)) (x : mat_Point)) ==> ((((out (F : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> ((((out (F : mat_Point)) (x : mat_Point)) (x : mat_Point)) ==> (((((cong (F : mat_Point)) (x : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (x : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ K0 : mat_Point. ((((betS (E : mat_Point)) (F : mat_Point)) (K0 : mat_Point)) ==> (((((cong (F : mat_Point)) (K0 : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> (((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K0 : mat_Point)) ==> (((((lt (E : mat_Point)) (K0 : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> (((eq (K0 : mat_Point)) (K0 : mat_Point)) ==> (((neq (F : mat_Point)) (K0 : mat_Point)) ==> ((((out (F : mat_Point)) (K0 : mat_Point)) (M : mat_Point)) ==> ((((out (F : mat_Point)) (K0 : mat_Point)) (K0 : mat_Point)) ==> (((((cong (F : mat_Point)) (K0 : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (K0 : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (E : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (E : mat_Point)) (M : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (F : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (F : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (M : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (K : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (K : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (F : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (F : mat_Point)) (K : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (K : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (F : mat_Point)) (K : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (F : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (K : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (K : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (K : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((betS (x : mat_Point)) (F : mat_Point)) (K : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((betS (X : mat_Point)) (F : mat_Point)) (K : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (F : mat_Point)) (M : mat_Point))) (((betS (X : mat_Point)) (F : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (K : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (K : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (K : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (E : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((lt (P : mat_Point)) (L : mat_Point)) (E : mat_Point)) (M : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (L : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (L : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (L : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (L : mat_Point)))`
                                                                  ))))
                                                            ) (ASSUME `ex (\ L : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (L : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (L : mat_Point)) (R : mat_Point)) (S : mat_Point))) ((((((tG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (L : mat_Point)))))`
                                                            )))
                                                         ) (ASSUME `(((((((tT (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (S : mat_Point)`
                                                         ))))
                                                   ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point)))`
                                             ))))
                                       ) (ASSUME `ex (\ J : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (J : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (J : mat_Point)))))`
                                       )))
                                    ) (ASSUME `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point)`
                                    ))))
                              ) (ASSUME `(mat_and ((((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point))`
                              ))))
                        ) (ASSUME `(mat_and (((betS (E : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point)))`
                        ))))
                  ) (ASSUME `ex (\ K : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (K : mat_Point)))))`
                  )))
               ) (ASSUME `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
               )))))))))))))))
 ;;


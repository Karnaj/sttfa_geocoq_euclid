(*lemma__inequalitysymmetric :  |- `! A : mat_Point. (! B : mat_Point. (((neq A) B) ==> ((neq B) A)))`*)
let lemma__inequalitysymmetric =

 CONV_CONV_rule `! A0 : mat_Point. (! B0 : mat_Point. (((neq (A0 : mat_Point)) (B0 : mat_Point)) ==> ((neq (B0 : mat_Point)) (A0 : mat_Point))))` 
 (GEN `(A : mat_Point)` 
  (GEN `(B : mat_Point)` 
   (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
    (MP  
     (CONV_CONV_rule `(((eq (B : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (mat_not ((eq (B : mat_Point)) (A : mat_Point)))` 
      (DISCH `mat_not ((eq (B : mat_Point)) (A : mat_Point))` 
       (ASSUME `mat_not ((eq (B : mat_Point)) (A : mat_Point))`))
     ) (DISCH `(eq (B : mat_Point)) (A : mat_Point)` 
        (MP  
         (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
          (MP  
           (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
            (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)
           ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`))
         ) (MP  
            (SPEC `(B : mat_Point)` 
             (SPEC `(A : mat_Point)` (lemma__equalitysymmetric))
            ) (ASSUME `(eq (B : mat_Point)) (A : mat_Point)`))))))))
 ;;


(*lemma__10__12 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! H : mat_Point. ((((per A) B) C) ==> ((((per A) B) H) ==> (((((cong B) C) B) H) ==> ((((cong A) C) A) H)))))))`*)
let lemma__10__12 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(H : mat_Point)` 
    (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (DISCH `((per (A : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
      (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
       (MP  
        (CONV_CONV_rule `(((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point))` 
         (DISCH `ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
          (MP  
           (MP  
            (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))) ==> (return : bool)))` 
              (SPEC `\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
            ) (GEN `(D : mat_Point)` 
               (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
                (MP  
                 (MP  
                  (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                   (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                    (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                     (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                      (MP  
                       (MP  
                        (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                         (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                           (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                            (MP  
                             (MP  
                              (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                               (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                                    (MP  
                                     (CONV_CONV_rule `(((per (A : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point))` 
                                      (DISCH `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))))) ==> (return : bool)))` 
                                           (SPEC `\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))))` 
                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                             (ex__ind))))
                                         ) (GEN `(F : mat_Point)` 
                                            (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))` 
                                                 (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                  (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                      (SPEC `(mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))` 
                                                       (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                        (DISCH `(mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                            (SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                             (SPEC `(((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)` 
                                                              (DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                                                               (MP  
                                                                (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (C : mat_Point)) (H : mat_Point))) ((neq (C : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (C : mat_Point)) (H : mat_Point))) ((neq (C : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (C : mat_Point)) (H : mat_Point))) ((neq (C : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (H : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (H : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((per (A : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> (((((cong (B : mat_Point)) (H : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) ==> (((neq (B : mat_Point)) (H : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (A : mat_Point)) (H : mat_Point)) ==> ((((cong (A : mat_Point)) (H : mat_Point)) (A : mat_Point)) (H : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (H : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (H : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. ((((per (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (B : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (D : mat_Point)) (C0 : mat_Point)) ==> (((neq (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> ((((cong (A : mat_Point)) (C0 : mat_Point)) (A : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (H : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (H : mat_Point)) (A : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (H : mat_Point)) (A : mat_Point)) (H : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (H : mat_Point)) (A : mat_Point)) (H : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ F0 : mat_Point. ((((betS (A : mat_Point)) (B : mat_Point)) (F0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (F0 : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (H : mat_Point)) (A : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (H : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (H : mat_Point))) ((((cong (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) (H : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (M : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__rightreverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (M : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> (((neq (B : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (H : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point)) ==> ((((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((per (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((per (A : mat_Point)) (M : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)) ==> (((neq (M : mat_Point)) (C : mat_Point)) ==> (((neq (M : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> (((neq (M : mat_Point)) (H : mat_Point)) ==> (((neq (A : mat_Point)) (M : mat_Point)) ==> (((((cong (D : mat_Point)) (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((((cong (D : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> (((((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)) ==> ((((per (C : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) ==> ((((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (M : mat_Point)) ==> ((((per (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((per (A : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (C : mat_Point)) ==> (((neq (x : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (H : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> (((((cong (D : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (D : mat_Point)) (x : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x : mat_Point)) ==> ((((per (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> ((((betS (C : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> ((((cong (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) (H : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. ((((per (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((per (A : mat_Point)) (B0 : mat_Point)) (H : mat_Point)) ==> (((((cong (B0 : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) (B0 : mat_Point)) ==> (((neq (B0 : mat_Point)) (C : mat_Point)) ==> (((neq (B0 : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (B0 : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (F : mat_Point)) (B0 : mat_Point)) ==> (((neq (B0 : mat_Point)) (H : mat_Point)) ==> (((neq (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (D : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (D : mat_Point)) (B0 : mat_Point)) (F : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (F : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (B0 : mat_Point)) (H : mat_Point)) (B0 : mat_Point)) ==> ((((per (C : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) ==> ((((betS (C : mat_Point)) (B0 : mat_Point)) (H : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) (H : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (M : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> ((((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (D : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)) ==> ((((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> ((((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ F0 : mat_Point. (((((cong (A : mat_Point)) (M : mat_Point)) (F0 : mat_Point)) (M : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (F0 : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (F0 : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (F0 : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (M : mat_Point)) (F0 : mat_Point)) (M : mat_Point)) ==> ((((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (D : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (M : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> (((neq (B : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (H : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point)) ==> ((((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((betS (C : mat_Point)) (B : mat_Point)) (H : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((per (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((per (A : mat_Point)) (M : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)) ==> (((neq (M : mat_Point)) (C : mat_Point)) ==> (((neq (M : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> (((neq (M : mat_Point)) (H : mat_Point)) ==> (((neq (A : mat_Point)) (M : mat_Point)) ==> (((((cong (D : mat_Point)) (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((((cong (D : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> (((((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)) ==> ((((per (C : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> (((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (M : mat_Point)) ==> ((((per (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((per (A : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (C : mat_Point)) ==> (((neq (x : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (H : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> (((((cong (D : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (D : mat_Point)) (x : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (F : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x : mat_Point)) ==> ((((per (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> (((betS (C : mat_Point)) (x : mat_Point)) (H : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. ((((per (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((per (A : mat_Point)) (B0 : mat_Point)) (H : mat_Point)) ==> (((((cong (B0 : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) (B0 : mat_Point)) ==> (((neq (B0 : mat_Point)) (C : mat_Point)) ==> (((neq (B0 : mat_Point)) (H : mat_Point)) ==> ((((betS (A : mat_Point)) (B0 : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (F : mat_Point)) (B0 : mat_Point)) ==> (((neq (B0 : mat_Point)) (H : mat_Point)) ==> (((neq (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (D : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (D : mat_Point)) (B0 : mat_Point)) (F : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (F : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (B0 : mat_Point)) (H : mat_Point)) (B0 : mat_Point)) ==> ((((per (C : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) ==> (((betS (C : mat_Point)) (B0 : mat_Point)) (H : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (M : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) ==> (((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (D : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)) ==> (((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> (((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ F0 : mat_Point. (((((cong (A : mat_Point)) (M : mat_Point)) (F0 : mat_Point)) (M : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (F0 : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (F0 : mat_Point)) (H : mat_Point)) ==> (((((cong (M : mat_Point)) (F0 : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((cong (D : mat_Point)) (M : mat_Point)) (F0 : mat_Point)) (M : mat_Point)) ==> (((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (D : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (F : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (M : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (M : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point))))))) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (M : mat_Point))))))) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (H : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (H : mat_Point))) ((((cong (D : mat_Point)) (H : mat_Point)) (H : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ F0 : mat_Point. ((((betS (A : mat_Point)) (B : mat_Point)) (F0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (F0 : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__linereflectionisometry
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (M : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (M : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (M : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (M : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((neq (B : mat_Point)) (M : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((neq (B : mat_Point)) (M : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((neq (B : mat_Point)) (M : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ F0 : mat_Point. ((((betS (A : mat_Point)) (B : mat_Point)) (F0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (F0 : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((neq (B : mat_Point)) (M : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (M : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (D : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (A : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (D : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (D : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__interior5
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (H : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (H : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (H : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((((cong (A : mat_Point)) (H : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (H : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((((cong (A : mat_Point)) (H : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((((cong (A : mat_Point)) (H : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (H : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (H : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((((cong (A : mat_Point)) (H : mat_Point)) (H : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H : mat_Point)) (A : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (H : mat_Point)) (A : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((((cong (A : mat_Point)) (H : mat_Point)) (H : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (M : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (M : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((((cong (M : mat_Point)) (C : mat_Point)) (H : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((((cong (M : mat_Point)) (C : mat_Point)) (H : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((((cong (M : mat_Point)) (C : mat_Point)) (H : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (C : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (M : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (M : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (C : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((((cong (M : mat_Point)) (C : mat_Point)) (H : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((((cong (M : mat_Point)) (C : mat_Point)) (H : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (M : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (M : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (M : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    eq__or__neq
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (H : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (C : mat_Point)) (M : mat_Point)) (H : mat_Point))) ((((cong (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    proposition__10
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (C : mat_Point)) (H : mat_Point))) ((neq (C : mat_Point)) (H : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (C : mat_Point)) (H : mat_Point))) ((neq (C : mat_Point)) (H : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (C : mat_Point)) (H : mat_Point))) ((neq (C : mat_Point)) (H : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    eq__or__neq
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ F0 : mat_Point. ((((betS (A : mat_Point)) (B : mat_Point)) (F0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (H : mat_Point)) (F0 : mat_Point)) (H : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (F0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (H : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__extensionunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                  )))
                                                                ) (MP  
                                                                   (DISCH `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                   ))))))
                                                          ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))`
                                              ))))
                                        ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))))`
                                        )))
                                     ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                     ))
                                   ) (MP  
                                      (CONV_CONV_rule `(((per (A : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> ((neq (B : mat_Point)) (H : mat_Point))` 
                                       (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (X : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))))` 
                                        (MP  
                                         (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (X : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (X : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))))) ==> (return : bool)))` 
                                              (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (X : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))))` 
                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                (ex__ind))))
                                            ) (GEN `(x : mat_Point)` 
                                               (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                   (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))` 
                                                    (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)` 
                                                     (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                         (SPEC `(mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))` 
                                                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)` 
                                                           (DISCH `(mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                               (SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                (SPEC `(((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point)` 
                                                                 (DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `(((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((neq (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point)))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (x : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))`
                                                 ))))
                                           ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (X : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))))`
                                           ))
                                         ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (H : mat_Point)) (X : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (H : mat_Point))))))`
                                         )))
                                      ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                      )))))
                             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                             ))))
                       ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                       ))))
                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))`
                 ))))
           ) (ASSUME `ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
           )))
        ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`))
      ))))))
 ;;


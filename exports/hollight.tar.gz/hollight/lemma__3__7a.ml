(*lemma__3__7a :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((betS A) B) C) ==> ((((betS B) C) D) ==> (((betS A) C) D))))))`*)
let lemma__3__7a =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
      (MP  
       (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
        (MP  
         (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
          (MP  
           (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
            (MP  
             (MP  
              (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                (SPEC `\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
              ) (GEN `(E : mat_Point)` 
                 (DISCH `(mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                  (MP  
                   (MP  
                    (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                     (SPEC `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                      (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                       (DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                        (MP  
                         (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                          (MP  
                           (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                            (MP  
                             (DISCH `(eq (D : mat_Point)) (E : mat_Point)` 
                              (MP  
                               (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                )
                               ) (MP  
                                  (MP  
                                   (MP  
                                    (MP  
                                     (MP  
                                      (CONV_CONV_rule `((eq (D : mat_Point)) (E : mat_Point)) ==> ((((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (C : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))))` 
                                       (SPEC `(D : mat_Point)` 
                                        (MP  
                                         (CONV_CONV_rule `((((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((neq (C : mat_Point)) (E : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (E : mat_Point)) ==> ((((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (x : mat_Point))))))))` 
                                          (SPEC `\ D0 : mat_Point. ((((betS (B : mat_Point)) (C : mat_Point)) (D0 : mat_Point)) ==> (((neq (C : mat_Point)) (D0 : mat_Point)) ==> (((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D0 : mat_Point)) ==> (((((cong (C : mat_Point)) (D0 : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (D0 : mat_Point))))))` 
                                           (SPEC `(E : mat_Point)` 
                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                             (eq__ind__r))))
                                         ) (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                            (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                             (DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                              (DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                               (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                               )))))))
                                      ) (ASSUME `(eq (D : mat_Point)) (E : mat_Point)`
                                      )
                                     ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                     )
                                    ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                    )
                                   ) (ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                   )
                                  ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                  )))
                             ) (MP  
                                (MP  
                                 (MP  
                                  (SPEC `(E : mat_Point)` 
                                   (SPEC `(D : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (lemma__extensionunique))))
                                  ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                  )
                                 ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                 )
                                ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                )))
                           ) (MP  
                              (MP  
                               (SPEC `(E : mat_Point)` 
                                (SPEC `(C : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(A : mat_Point)` (lemma__3__6a))))
                               ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                               )
                              ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                              )))
                         ) (MP  
                            (SPEC `(D : mat_Point)` 
                             (SPEC `(E : mat_Point)` 
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(C : mat_Point)` 
                                (lemma__congruencesymmetric))))
                            ) (ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                            )))))
                   ) (ASSUME `(mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                   ))))
             ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
             ))
           ) (MP  
              (MP  
               (SPEC `(D : mat_Point)` 
                (SPEC `(C : mat_Point)` 
                 (SPEC `(A : mat_Point)` (lemma__localextension)))
               ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`)
              ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`)))
         ) (MP  
            (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
             (MP  
              (MP  
               (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                 (SPEC `(neq (C : mat_Point)) (D : mat_Point)` (and__ind)))
               ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                  (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                   (MP  
                    (MP  
                     (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                      (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                       (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                        (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                         (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`)))
                    ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))`
                    ))))
              ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))`
              ))
            ) (MP  
               (SPEC `(D : mat_Point)` 
                (SPEC `(C : mat_Point)` 
                 (SPEC `(B : mat_Point)` (lemma__betweennotequal)))
               ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
               ))))
       ) (MP  
          (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
           (MP  
            (MP  
             (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
              (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
               (SPEC `(neq (B : mat_Point)) (C : mat_Point)` (and__ind)))
             ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                 (MP  
                  (MP  
                   (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                    (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)
                     ))
                   ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                      (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                       (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`)))
                  ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                  ))))
            ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
            ))
          ) (MP  
             (SPEC `(C : mat_Point)` 
              (SPEC `(B : mat_Point)` 
               (SPEC `(A : mat_Point)` (lemma__betweennotequal)))
             ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
             )))))))))
 ;;


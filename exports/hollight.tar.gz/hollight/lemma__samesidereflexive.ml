(*lemma__samesidereflexive :  |- `! A : mat_Point. (! B : mat_Point. (! P : mat_Point. ((((nCol A) B) P) ==> ((((oS P) P) A) B))))`*)
let lemma__samesidereflexive =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(P : mat_Point)` 
   (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
    (MP  
     (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((((oS (P : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
      (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
       (MP  
        (CONV_CONV_rule `(((eq (P : mat_Point)) (A : mat_Point)) ==> mat_false) ==> ((((oS (P : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
         (DISCH `mat_not ((eq (P : mat_Point)) (A : mat_Point))` 
          (MP  
           (DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
            (MP  
             (DISCH `ex (\ C : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (P : mat_Point))))` 
              (MP  
               (MP  
                (SPEC `(((oS (P : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (P : mat_Point))) ==> (return : bool))) ==> ((ex (\ C : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (P : mat_Point))))) ==> (return : bool)))` 
                  (SPEC `\ C : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                ) (GEN `(C : mat_Point)` 
                   (DISCH `(mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                    (MP  
                     (MP  
                      (SPEC `(((oS (P : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                       (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                        (SPEC `((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                         (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                          (MP  
                           (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))))) ==> ((((oS (P : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                            (DISCH `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                             (MP  
                              (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))))) ==> ((((oS (P : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                               (DISCH `(((oS (P : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                (ASSUME `(((oS (P : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                ))
                              ) (MP  
                                 (SPEC `(C : mat_Point)` 
                                  (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))))))` 
                                   (SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))))))))` 
                                    (PINST [(`:mat_Point`,`:A`)] [] (
                                                                    ex__intro
                                                                    ))))
                                 ) (MP  
                                    (SPEC `(A : mat_Point)` 
                                     (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (C : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))))` 
                                      (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (C : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))))))` 
                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                        (ex__intro))))
                                    ) (MP  
                                       (SPEC `(A : mat_Point)` 
                                        (CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))` 
                                         (SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))))` 
                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                           (ex__intro))))
                                       ) (MP  
                                          (MP  
                                           (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                            (SPEC `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                             (conj))
                                           ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                           )
                                          ) (MP  
                                             (MP  
                                              (SPEC `(mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                               (SPEC `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                (conj))
                                              ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                              )
                                             ) (MP  
                                                (MP  
                                                 (SPEC `(mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                  (SPEC `((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                   (conj))
                                                 ) (ASSUME `((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                 )
                                                ) (MP  
                                                   (MP  
                                                    (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                     (SPEC `((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                      (conj))
                                                    ) (ASSUME `((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                    )
                                                   ) (MP  
                                                      (MP  
                                                       (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                        (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                         (conj))
                                                       ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                       )
                                                      ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                      )))))))))))
                           ) (MP  
                              (SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                               (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                (or__intror))
                              ) (MP  
                                 (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                  (SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                   (or__introl))
                                 ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                 ))))))
                     ) (ASSUME `(mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (P : mat_Point))`
                     ))))
               ) (ASSUME `ex (\ C : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (P : mat_Point))))`
               ))
             ) (MP  
                (MP  
                 (CONV_CONV_rule `(mat_not ((eq (P : mat_Point)) (A : mat_Point))) ==> (((neq (A : mat_Point)) (P : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (P : mat_Point))))))` 
                  (SPEC `(P : mat_Point)` 
                   (SPEC `(A : mat_Point)` 
                    (SPEC `(A : mat_Point)` 
                     (SPEC `(P : mat_Point)` (lemma__extension)))))
                 ) (ASSUME `mat_not ((eq (P : mat_Point)) (A : mat_Point))`)
                ) (ASSUME `(neq (A : mat_Point)) (P : mat_Point)`)))
           ) (MP  
              (CONV_CONV_rule `(mat_not ((eq (P : mat_Point)) (A : mat_Point))) ==> ((neq (A : mat_Point)) (P : mat_Point))` 
               (SPEC `(A : mat_Point)` 
                (SPEC `(P : mat_Point)` (lemma__inequalitysymmetric)))
              ) (ASSUME `mat_not ((eq (P : mat_Point)) (A : mat_Point))`))))
        ) (DISCH `(eq (P : mat_Point)) (A : mat_Point)` 
           (MP  
            (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
             (DISCH `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
              (MP  
               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                (MP  
                 (MP  
                  (SPEC `(P : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (col__nCol__False)))
                  ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                  )
                 ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                 ))
               ) (MP  
                  (MP  
                   (CONV_CONV_rule `((eq (P : mat_Point)) (A : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                    (SPEC `(P : mat_Point)` 
                     (MP  
                      (CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)))))` 
                       (SPEC `\ P0 : mat_Point. ((((nCol (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (P0 : mat_Point)))` 
                        (SPEC `(A : mat_Point)` 
                         (PINST [(`:mat_Point`,`:A`)] [] (eq__ind__r))))
                      ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                         (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                         ))))) (ASSUME `(eq (P : mat_Point)) (A : mat_Point)`
                   )
                  ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                  ))))
            ) (MP  
               (SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__intror))
               ) (MP  
                  (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                   (SPEC `(eq (A : mat_Point)) (A : mat_Point)` (or__introl))
                  ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`)))))))
     ) (SPEC `(A : mat_Point)` (PINST [(`:mat_Point`,`:A`)] [] (eq__refl)))))
  ))
 ;;


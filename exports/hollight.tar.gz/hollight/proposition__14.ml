(*proposition__14 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (((((((rT A) B) C) D) B) E) ==> ((((out B) C) D) ==> (((((tS E) D) B) A) ==> ((mat_and (((((supp A) B) C) D) E)) (((betS A) B) E)))))))))`*)
let proposition__14 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (DISCH `(((((rT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
      (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
       (DISCH `(((tS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
        (MP  
         (DISCH `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
          (MP  
           (MP  
            (SPEC `(mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))) ==> (return : bool)))` 
              (SPEC `\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))))))` 
               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
            ) (GEN `(a : mat_Point)` 
               (DISCH `ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))` 
                (MP  
                 (MP  
                  (SPEC `(mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (x : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (x : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (x : mat_Point)) (e : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))) ==> (return : bool)))` 
                    (SPEC `\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))))` 
                     (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                  ) (GEN `(b : mat_Point)` 
                     (DISCH `ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))` 
                      (MP  
                       (MP  
                        (SPEC `(mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (x : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))) ==> (return : bool)))` 
                          (SPEC `\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))` 
                           (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                        ) (GEN `(c : mat_Point)` 
                           (DISCH `ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))` 
                            (MP  
                             (MP  
                              (SPEC `(mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (x : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x : mat_Point)) (b : mat_Point)) (e : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))) ==> (return : bool)))` 
                                (SPEC `\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))` 
                                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                              ) (GEN `(d : mat_Point)` 
                                 (DISCH `ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                     (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))) ==> (return : bool)))` 
                                      (SPEC `\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))` 
                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                        (ex__ind))))
                                    ) (GEN `(e : mat_Point)` 
                                       (DISCH `(mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                           (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))` 
                                            (SPEC `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                             (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                 (SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                  (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                   (DISCH `(((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                    (MP  
                                                     (DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (MP  
                                                       (DISCH `(((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                        (MP  
                                                         (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                            (MP  
                                                             (DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `ex (\ T : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (E : mat_Point))) ==> (return : bool))) ==> ((ex (\ T : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (B : mat_Point)) (E : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ T : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (T : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (T : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) ==> ((mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    DISCH `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (B : mat_Point)) (T : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (T : mat_Point))) ((mat_or ((eq (B : mat_Point)) (T : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((betS (A : mat_Point)) (T : mat_Point)) (B : mat_Point))))))) ==> ((mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> ((mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (T : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> ((mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (T : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (T : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (T : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (D : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> ((mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    DISCH `ex (\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (T : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (T : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (E : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point))))))))))))) ==> ((mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    DISCH `(((oS (T : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (T : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ==> ((mat_and (((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    DISCH `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (T : mat_Point)) (E : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point)) ==> (((((cong (B : mat_Point)) (T : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (T : mat_Point)) ==> (((((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (T : mat_Point)) ==> (((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (T : mat_Point)) ==> (((((((congA (D : mat_Point)) (B : mat_Point)) (T : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)) ==> (((neq (B : mat_Point)) (T : mat_Point)) ==> (((neq (T : mat_Point)) (B : mat_Point)) ==> ((((nCol (T : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)) ==> ((((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point)) ==> (((((cong (D : mat_Point)) (T : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((((cong (T : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> (((((cong (T : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> ((((betS (T : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((oS (T : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((neq (B : mat_Point)) (E : mat_Point)) ==> (((neq (E : mat_Point)) (B : mat_Point)) ==> ((((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (D : mat_Point)) (E : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((((cong (E : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> (((((cong (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> ((((betS (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((oS (E : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (E : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((((congA (D : mat_Point)) (B : mat_Point)) (x : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((((nCol (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((nCol (D : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (D : mat_Point)) (x : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((((cong (x : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((oS (x : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ T0 : mat_Point. ((((betS (A : mat_Point)) (B : mat_Point)) (T0 : mat_Point)) ==> (((((cong (B : mat_Point)) (T0 : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (T0 : mat_Point)) ==> (((((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (T0 : mat_Point)) ==> (((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (T0 : mat_Point)) ==> (((((((congA (D : mat_Point)) (B : mat_Point)) (T0 : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (T0 : mat_Point)) ==> (((neq (B : mat_Point)) (T0 : mat_Point)) ==> (((neq (T0 : mat_Point)) (B : mat_Point)) ==> ((((nCol (T0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (C : mat_Point)) (B : mat_Point)) (T0 : mat_Point)) ==> ((((nCol (D : mat_Point)) (B : mat_Point)) (T0 : mat_Point)) ==> (((((cong (D : mat_Point)) (T0 : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((((cong (T0 : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> (((((cong (T0 : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> ((((betS (T0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((oS (T0 : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (E : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (E : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (T : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (T : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (B : mat_Point)) (T : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (T : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (T : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (T : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (T : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (T : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (T : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (T : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    proposition__07
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (T : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (T : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (T : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (T : mat_Point))) ((mat_and ((neq (C : mat_Point)) (T : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (T : mat_Point))) ((mat_and ((neq (C : mat_Point)) (T : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (T : mat_Point))) ((mat_and ((neq (C : mat_Point)) (T : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (T : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (T : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (T : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (T : mat_Point))) ((mat_and ((neq (C : mat_Point)) (T : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (T : mat_Point))) ((mat_and ((neq (C : mat_Point)) (T : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (T : mat_Point)) (B : mat_Point))) ((neq (T : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (T : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (E : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (T : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (E : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (T : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (E : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (T : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and (((betS (E : mat_Point)) (V : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (T : mat_Point)) (U : mat_Point)) (A : mat_Point))) ((mat_and (((betS (E : mat_Point)) (V : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (T : mat_Point)) (U : mat_Point)) (A : mat_Point))) ((mat_and (((betS (E : mat_Point)) (V : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (D : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((betS (E : mat_Point)) (V : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((betS (E : mat_Point)) (V : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((betS (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (T : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (T : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (T : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (D : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (D : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (D : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (T : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (T : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (T : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (T : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (T : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (T : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (T : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (T : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (T : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (T : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (T : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (T : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (T : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (T : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (T : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (T : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (E : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (T : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (T : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (T : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (T : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (T : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (T : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (T : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (T : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (T : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (T : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (T : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (T : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (T : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (T : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (T : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (T : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (T : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (T : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (T : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (T : mat_Point)) (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (T : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (D : mat_Point)) (T : mat_Point)) (E : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (T : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a0 : mat_Point. (! b0 : mat_Point. (! c0 : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a0 : mat_Point. (! b0 : mat_Point. (! c0 : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))))))))))`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (T : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (B : mat_Point)) (T : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(a0 : mat_Point)` 
                                                                    (
                                                                    GEN `(b0 : mat_Point)` 
                                                                    (
                                                                    GEN `(c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) (b0 : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) (b0 : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(b0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(a0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (T : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (T : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (T : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (T : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (T : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (T : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (T : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (T : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (T : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (T : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (T : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (T : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (T : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (T : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (T : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (T : mat_Point))) ((mat_or ((eq (B : mat_Point)) (T : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((betS (A : mat_Point)) (T : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (T : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((betS (A : mat_Point)) (T : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (T : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((betS (A : mat_Point)) (T : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) (((betS (A : mat_Point)) (T : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (T : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__supplements
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `ex (\ T : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (T : mat_Point))) ((((cong (B : mat_Point)) (T : mat_Point)) (B : mat_Point)) (E : mat_Point))))`
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                               ) (MP  
                                                                  (DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (D : mat_Point))))))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                  ))))
                                                             ) (MP  
                                                                (SPEC `(E : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (nCol__notCol
                                                                   )))
                                                                ) (MP  
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                   ) (
                                                                   ASSUME `(((((congA (d : mat_Point)) (b : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                   )))))
                                                           ) (MP  
                                                              (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                  (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                 ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                 ))))
                                                         ) (MP  
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (nCol__notCol)
                                                              ))
                                                            ) (MP  
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(B : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (nCol__not__Col
                                                                  )))
                                                               ) (MP  
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                  ) (
                                                                  ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                  )))))
                                                       ) (MP  
                                                          (SPEC `(e : mat_Point)` 
                                                           (SPEC `(b : mat_Point)` 
                                                            (SPEC `(d : mat_Point)` 
                                                             (SPEC `(E : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (lemma__equalanglessymmetric
                                                                ))))))
                                                          ) (ASSUME `(((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                          )))
                                                     ) (MP  
                                                        (SPEC `(c : mat_Point)` 
                                                         (SPEC `(b : mat_Point)` 
                                                          (SPEC `(a : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (lemma__equalanglessymmetric
                                                              ))))))
                                                        ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                        )))))
                                               ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))`
                                         ))))
                                   ) (ASSUME `ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))`
                                   ))))
                             ) (ASSUME `ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))`
                             ))))
                       ) (ASSUME `ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))`
                       ))))
                 ) (ASSUME `ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))`
                 ))))
           ) (ASSUME `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))`
           ))
         ) (MP  
            (CONV_CONV_rule `((((((rT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))))))))` 
             (DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
              (MP  
               (DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                (MP  
                 (MP  
                  (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))) ==> (return : bool)))` 
                    (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))))` 
                     (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                  ) (GEN `(x : mat_Point)` 
                     (DISCH `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))` 
                      (MP  
                       (MP  
                        (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                         (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool)))` 
                          (SPEC `\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))` 
                           (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                        ) (GEN `(x0 : mat_Point)` 
                           (DISCH `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))` 
                            (MP  
                             (MP  
                              (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                               (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool)))` 
                                (SPEC `\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point))))))))` 
                                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                              ) (GEN `(x1 : mat_Point)` 
                                 (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                     (CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))) ==> (return : bool)))` 
                                      (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))))))` 
                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                        (ex__ind))))
                                    ) (GEN `(x2 : mat_Point)` 
                                       (DISCH `ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                           (CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))) ==> (return : bool)))` 
                                            (SPEC `\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))))` 
                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                              (ex__ind))))
                                          ) (GEN `(x3 : mat_Point)` 
                                             (DISCH `(mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))` 
                                              (MP  
                                               (MP  
                                                (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                 (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                  (SPEC `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                   (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                       (SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                        (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                         (DISCH `(((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                          (MP  
                                                           (SPEC `(x : mat_Point)` 
                                                            (CONV_CONV_rule `! x4 : mat_Point. ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))) ==> (ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))))` 
                                                             (SPEC `\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))))))` 
                                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                                               (ex__intro))))
                                                           ) (MP  
                                                              (SPEC `(x0 : mat_Point)` 
                                                               (CONV_CONV_rule `! x4 : mat_Point. ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x4 : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x4 : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (x4 : mat_Point)) (e : mat_Point)))))))))) ==> (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point)))))))))))))` 
                                                                (SPEC `\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (e : mat_Point))))))))))` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (ex__intro)
                                                                 )))
                                                              ) (MP  
                                                                 (SPEC `(x2 : mat_Point)` 
                                                                  (CONV_CONV_rule `! x4 : mat_Point. ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x4 : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x4 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (x0 : mat_Point)) (e : mat_Point)))))))) ==> (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (x0 : mat_Point)) (e : mat_Point)))))))))))` 
                                                                   (SPEC `\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (c : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (c : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (x0 : mat_Point)) (e : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(x3 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x4 : mat_Point. ((ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x4 : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x4 : mat_Point)) (x0 : mat_Point)) (e : mat_Point)))))) ==> (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (x0 : mat_Point)) (e : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (d : mat_Point)) (x0 : mat_Point)) (e : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x1 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x4 : mat_Point. (((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x4 : mat_Point)))) ==> (ex (\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (e : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ e : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (e : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)`
                                                                    )))))))))
                                                      )
                                                     ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))`
                                               ))))
                                         ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))`
                                         ))))
                                   ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))`
                                   ))))
                             ) (ASSUME `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))`
                             ))))
                       ) (ASSUME `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))`
                       ))))
                 ) (ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
                 ))
               ) (ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
               )))
            ) (ASSUME `(((((rT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)`
            ))))))))))
 ;;


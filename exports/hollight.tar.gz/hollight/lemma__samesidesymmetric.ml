(*lemma__samesidesymmetric :  |- `! A : mat_Point. (! B : mat_Point. (! P : mat_Point. (! Q : mat_Point. (((((oS P) Q) A) B) ==> ((mat_and ((((oS Q) P) A) B)) ((mat_and ((((oS P) Q) B) A)) ((((oS Q) P) B) A)))))))`*)
let lemma__samesidesymmetric =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(P : mat_Point)` 
   (GEN `(Q : mat_Point)` 
    (DISCH `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
     (MP  
      (DISCH `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
       (MP  
        (MP  
         (SPEC `(mat_and ((((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))) ==> (return : bool)))` 
           (SPEC `\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))))` 
            (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
         ) (GEN `(E : mat_Point)` 
            (DISCH `ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))` 
             (MP  
              (MP  
               (SPEC `(mat_and ((((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))) ==> (return : bool)))` 
                 (SPEC `\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))` 
                  (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
               ) (GEN `(F : mat_Point)` 
                  (DISCH `ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))` 
                   (MP  
                    (MP  
                     (SPEC `(mat_and ((((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))) ==> (return : bool)))` 
                       (SPEC `\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))` 
                        (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                     ) (GEN `(G : mat_Point)` 
                        (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))` 
                         (MP  
                          (MP  
                           (SPEC `(mat_and ((((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                            (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                             (SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                              (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                               (MP  
                                (MP  
                                 (SPEC `(mat_and ((((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                  (SPEC `(mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                   (SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                    (DISCH `(mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(mat_and ((((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                        (SPEC `(mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                         (SPEC `((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                          (DISCH `(mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(mat_and ((((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                              (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                               (SPEC `((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(mat_and ((((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                    (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                     (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                      (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))))) ==> ((mat_and ((((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                         (DISCH `(((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                          (MP  
                                                           (DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                            (MP  
                                                             (DISCH `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                              (MP  
                                                               (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))))))))))))) ==> ((mat_and ((((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    DISCH `(((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))))))))))) ==> ((mat_and ((((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    DISCH `(((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((oS (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((oS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )))))))))
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                   ))))))))))
                                                                 ) (MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((nCol (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((nCol (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((nCol (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((nCol (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((nCol (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((nCol (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((nCol (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((nCol (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((nCol (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((nCol (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((nCol (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                               ) (MP  
                                                                  (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((nCol (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(P : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                  ))))
                                                             ) (MP  
                                                                (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                   ))))
                                                           ) (MP  
                                                              (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                  (SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                   (SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(E : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                 ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                 )))))
                                                        ) (MP  
                                                           (SPEC `(G : mat_Point)` 
                                                            (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))))))` 
                                                             (SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))))))))` 
                                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                                               (ex__intro))))
                                                           ) (MP  
                                                              (SPEC `(F : mat_Point)` 
                                                               (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))))` 
                                                                (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (U : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))))))` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (ex__intro)
                                                                 )))
                                                              ) (MP  
                                                                 (SPEC `(E : mat_Point)` 
                                                                  (CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))` 
                                                                   (SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))))))))
                                                       )))
                                                  ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))`
                                            ))))
                                      ) (ASSUME `(mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))`
                                ))))
                          ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))`
                          ))))
                    ) (ASSUME `ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))`
                    ))))
              ) (ASSUME `ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))`
              ))))
        ) (ASSUME `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))`
        ))
      ) (MP  
         (CONV_CONV_rule `((((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))))))` 
          (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
           (MP  
            (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
             (MP  
              (MP  
               (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))) ==> (return : bool)))` 
                 (SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))))` 
                  (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
               ) (GEN `(x : mat_Point)` 
                  (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))` 
                   (MP  
                    (MP  
                     (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                      (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))) ==> (return : bool)))` 
                       (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))` 
                        (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                     ) (GEN `(x0 : mat_Point)` 
                        (DISCH `ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))` 
                         (MP  
                          (MP  
                           (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                            (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))) ==> (return : bool)))` 
                             (SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))` 
                              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                           ) (GEN `(x1 : mat_Point)` 
                              (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))` 
                               (MP  
                                (MP  
                                 (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                  (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                                   (SPEC `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                    (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                        (SPEC `(mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                         (SPEC `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                          (DISCH `(mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                              (SPEC `(mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                               (SPEC `((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                (DISCH `(mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                                    (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                     (SPEC `((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                      (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                                          (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                           (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                            (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                             (MP  
                                                              (SPEC `(x0 : mat_Point)` 
                                                               (CONV_CONV_rule `! x2 : mat_Point. ((ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x2 : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))) ==> (ex (\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))))` 
                                                                (SPEC `\ E : mat_Point. (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))))` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (ex__intro)
                                                                 )))
                                                              ) (MP  
                                                                 (SPEC `(x1 : mat_Point)` 
                                                                  (CONV_CONV_rule `! x2 : mat_Point. ((ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x2 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))) ==> (ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                                                   (SPEC `\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(x : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x2 : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))) ==> (ex (\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ G : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (G : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))))))
                                                            ))
                                                        ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))`
                                            ))))
                                      ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))`
                                ))))
                          ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))`
                          ))))
                    ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))`
                    ))))
              ) (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))`
              ))
            ) (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (Q : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))`
            )))
         ) (ASSUME `(((oS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
         )))))))
 ;;


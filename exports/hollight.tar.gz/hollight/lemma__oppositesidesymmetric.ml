(*lemma__oppositesidesymmetric :  |- `! A : mat_Point. (! B : mat_Point. (! P : mat_Point. (! Q : mat_Point. (((((tS P) A) B) Q) ==> ((((tS Q) A) B) P)))))`*)
let lemma__oppositesidesymmetric =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(P : mat_Point)` 
   (GEN `(Q : mat_Point)` 
    (DISCH `(((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
     (MP  
      (CONV_CONV_rule `((((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
       (DISCH `ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
        (MP  
         (MP  
          (SPEC `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))) ==> (return : bool))) ==> ((ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))) ==> (return : bool)))` 
            (SPEC `\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
          ) (GEN `(R : mat_Point)` 
             (DISCH `(mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
              (MP  
               (MP  
                (SPEC `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                 (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                  (SPEC `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                   (and__ind)))
                ) (DISCH `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                   (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                    (MP  
                     (MP  
                      (SPEC `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                       (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                        (SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                         (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                          (MP  
                           (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                            (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                             (MP  
                              (DISCH `((betS (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                               (MP  
                                (CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> ((((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                 (DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                  (MP  
                                   (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (Q : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))) ==> ((((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                    (DISCH `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                     (ASSUME `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                     ))
                                   ) (MP  
                                      (SPEC `(R : mat_Point)` 
                                       (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (Q : mat_Point)) (x : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (Q : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))` 
                                        (SPEC `\ X : mat_Point. ((mat_and (((betS (Q : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                         (PINST [(`:mat_Point`,`:A`)] [] 
                                          (ex__intro))))
                                      ) (MP  
                                         (MP  
                                          (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                           (SPEC `((betS (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                            (conj))
                                          ) (ASSUME `((betS (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)`
                                          )
                                         ) (MP  
                                            (MP  
                                             (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                              (SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                               (conj))
                                             ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                             )
                                            ) (MP  
                                               (SPEC `(Q : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (nCol__notCol)))
                                               ) (ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                               )))))))
                                ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `((mat_or ((eq (P : mat_Point)) (R : mat_Point))) ((mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (R : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))))) ==> mat_false` 
                                     (DISCH `((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                      (MP  
                                       (DISCH `((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                        (MP  
                                         (DISCH `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                          (MP  
                                           (DISCH `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                            (MP  
                                             (DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                              (MP  
                                               (DISCH `((col (R : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                (MP  
                                                 (DISCH `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                  (MP  
                                                   (DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                    (MP  
                                                     (DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(P : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (col__nCol__False)
                                                          ))
                                                        ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                        )
                                                       ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                       ))
                                                     ) (MP  
                                                        (DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)))))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                            (SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))))` 
                                                             (SPEC `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                              (DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                  (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)))` 
                                                                   (SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))))`
                                                                ))))
                                                          ) (ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)))))`
                                                          ))
                                                        ) (MP  
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(P : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (lemma__collinearorder
                                                              )))
                                                           ) (ASSUME `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                           ))))
                                                   ) (MP  
                                                      (DISCH `(mat_or ((eq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (B : mat_Point))` 
                                                       (MP  
                                                        (DISCH `(mat_or ((eq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (B : mat_Point))` 
                                                         (MP  
                                                          (DISCH `(mat_or ((eq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (B : mat_Point))` 
                                                           (MP  
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `(neq (R : mat_Point)) (B : mat_Point)` 
                                                                (SPEC `(eq (R : mat_Point)) (B : mat_Point)` 
                                                                 (or__ind)))
                                                              ) (DISCH `(eq (R : mat_Point)) (B : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (P : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (R : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((betS (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)) ==> ((((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)) ==> (((neq (Q : mat_Point)) (R : mat_Point)) ==> ((((col (R : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (R : mat_Point)) (Q : mat_Point)) ==> ((neq (B : mat_Point)) (Q : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((betS (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((neq (Q : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (B : mat_Point)) (Q : mat_Point)) ==> ((neq (B : mat_Point)) (Q : mat_Point))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (Q : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((((col (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (Q : mat_Point)) (x : mat_Point)) ==> ((((col (Q : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> (((neq (Q : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (x : mat_Point)) (Q : mat_Point)) ==> ((neq (B : mat_Point)) (Q : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ R0 : mat_Point. ((((betS (P : mat_Point)) (R0 : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (R0 : mat_Point)) ==> ((((betS (Q : mat_Point)) (R0 : mat_Point)) (P : mat_Point)) ==> ((((col (P : mat_Point)) (R0 : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (Q : mat_Point)) (R0 : mat_Point)) ==> ((((col (Q : mat_Point)) (R0 : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (R0 : mat_Point)) (P : mat_Point)) ==> (((neq (Q : mat_Point)) (R0 : mat_Point)) ==> ((((col (R0 : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((col (R0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (R0 : mat_Point)) (Q : mat_Point)) ==> ((neq (B : mat_Point)) (Q : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (R : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (R : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (R : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (R : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (R : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((betS (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)) ==> ((((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)) ==> (((neq (Q : mat_Point)) (R : mat_Point)) ==> ((((col (R : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((betS (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((neq (Q : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (Q : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((((col (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (Q : mat_Point)) (x : mat_Point)) ==> ((((col (Q : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> (((neq (Q : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ R0 : mat_Point. ((((betS (P : mat_Point)) (R0 : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (R0 : mat_Point)) ==> ((((betS (Q : mat_Point)) (R0 : mat_Point)) (P : mat_Point)) ==> ((((col (P : mat_Point)) (R0 : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (Q : mat_Point)) (R0 : mat_Point)) ==> ((((col (Q : mat_Point)) (R0 : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (R0 : mat_Point)) (P : mat_Point)) ==> (((neq (Q : mat_Point)) (R0 : mat_Point)) ==> ((((col (R0 : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((col (R0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (R : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((col (R : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                  ))))
                                                             ) (DISCH `(neq (R : mat_Point)) (B : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                   ))))
                                                                 ) (MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (R : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                            ) (ASSUME `(mat_or ((eq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (B : mat_Point))`
                                                            ))
                                                          ) (ASSUME `(mat_or ((eq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (B : mat_Point))`
                                                          ))
                                                        ) (ASSUME `(mat_or ((eq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (B : mat_Point))`
                                                        ))
                                                      ) (SPEC `(B : mat_Point)` 
                                                         (SPEC `(R : mat_Point)` 
                                                          (eq__or__neq)))))
                                                 ) (MP  
                                                    (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                        (SPEC `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                         (SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                          (DISCH `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                              (SPEC `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                               (SPEC `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                (DISCH `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                      ))
                                                    ) (MP  
                                                       (SPEC `(R : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (lemma__collinearorder
                                                          )))
                                                       ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                       ))))
                                               ) (MP  
                                                  (CONV_CONV_rule `((((nCol (R : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> mat_false) ==> (((col (R : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                   (SPEC `(P : mat_Point)` 
                                                    (SPEC `(B : mat_Point)` 
                                                     (SPEC `(R : mat_Point)` 
                                                      (not__nCol__Col))))
                                                  ) (DISCH `((nCol (R : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(P : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(R : mat_Point)` 
                                                          (col__nCol__False))
                                                        )
                                                       ) (ASSUME `((nCol (R : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                       )
                                                      ) (MP  
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(P : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (SPEC `(R : mat_Point)` 
                                                              (SPEC `(Q : mat_Point)` 
                                                               (lemma__collinear4
                                                               ))))
                                                           ) (ASSUME `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)`
                                                           )
                                                          ) (ASSUME `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)`
                                                          )
                                                         ) (ASSUME `(neq (Q : mat_Point)) (R : mat_Point)`
                                                         ))))))
                                             ) (MP  
                                                (DISCH `(mat_and ((neq (R : mat_Point)) (P : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (Q : mat_Point)) (P : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                    (SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (Q : mat_Point)) (P : mat_Point))` 
                                                     (SPEC `(neq (R : mat_Point)) (P : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(neq (R : mat_Point)) (P : mat_Point)` 
                                                      (DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (Q : mat_Point)) (P : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                          (SPEC `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                           (SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                            (DISCH `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                             (ASSUME `(neq (Q : mat_Point)) (R : mat_Point)`
                                                             )))
                                                        ) (ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (Q : mat_Point)) (P : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((neq (R : mat_Point)) (P : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((neq (Q : mat_Point)) (P : mat_Point)))`
                                                  ))
                                                ) (MP  
                                                   (SPEC `(P : mat_Point)` 
                                                    (SPEC `(R : mat_Point)` 
                                                     (SPEC `(Q : mat_Point)` 
                                                      (lemma__betweennotequal
                                                      )))
                                                   ) (ASSUME `((betS (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)`
                                                   ))))
                                           ) (MP  
                                              (DISCH `(mat_and (((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                  (SPEC `(mat_and (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))))` 
                                                   (SPEC `((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                    (DISCH `(mat_and (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                        (SPEC `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))` 
                                                         (SPEC `((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                          (DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                              (SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))` 
                                                               (SPEC `((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point)` 
                                                                (DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                   (DISCH `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point))))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((col (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (R : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (R : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) (((col (Q : mat_Point)) (R : mat_Point)) (P : mat_Point)))))`
                                                ))
                                              ) (MP  
                                                 (SPEC `(Q : mat_Point)` 
                                                  (SPEC `(R : mat_Point)` 
                                                   (SPEC `(P : mat_Point)` 
                                                    (lemma__collinearorder)))
                                                 ) (ASSUME `((col (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                 ))))
                                         ) (MP  
                                            (DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                (SPEC `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                 (SPEC `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                  (DISCH `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                      (SPEC `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                       (SPEC `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                        (DISCH `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                            (SPEC `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                             (SPEC `((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                              (DISCH `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                  (SPEC `((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                   (SPEC `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                ) (ASSUME `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))`
                                                                ))))
                                                          ) (ASSUME `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))`
                                              ))
                                            ) (MP  
                                               (SPEC `(R : mat_Point)` 
                                                (SPEC `(Q : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (lemma__collinearorder)))
                                               ) (ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                               ))))
                                       ) (MP  
                                          (CONV_CONV_rule `((((nCol (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                           (SPEC `(R : mat_Point)` 
                                            (SPEC `(Q : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (not__nCol__Col))))
                                          ) (DISCH `((nCol (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                             (MP  
                                              (MP  
                                               (SPEC `(R : mat_Point)` 
                                                (SPEC `(Q : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (col__nCol__False)))
                                               ) (ASSUME `((nCol (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                               )
                                              ) (MP  
                                                 (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(R : mat_Point)` 
                                                     (SPEC `(Q : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (lemma__collinear4)))
                                                     )
                                                    ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                    )
                                                   ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                   ))
                                                 ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                 )))))))
                                    ) (MP  
                                       (SPEC `(mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (R : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))` 
                                        (SPEC `(eq (P : mat_Point)) (R : mat_Point)` 
                                         (or__intror))
                                       ) (MP  
                                          (SPEC `(mat_or ((eq (R : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))))` 
                                           (SPEC `(eq (P : mat_Point)) (Q : mat_Point)` 
                                            (or__intror))
                                          ) (MP  
                                             (SPEC `(mat_or (((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)))` 
                                              (SPEC `(eq (R : mat_Point)) (Q : mat_Point)` 
                                               (or__intror))
                                             ) (MP  
                                                (SPEC `(mat_or (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                 (SPEC `((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                  (or__intror))
                                                ) (MP  
                                                   (SPEC `((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                    (SPEC `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                     (or__introl))
                                                   ) (ASSUME `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                   )))))))))
                              ) (MP  
                                 (SPEC `(Q : mat_Point)` 
                                  (SPEC `(R : mat_Point)` 
                                   (SPEC `(P : mat_Point)` 
                                    (axiom__betweennesssymmetry)))
                                 ) (ASSUME `((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                 ))))
                           ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                              (MP  
                               (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                (DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                 (MP  
                                  (MP  
                                   (SPEC `(P : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(A : mat_Point)` 
                                      (col__nCol__False)))
                                   ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                   )
                                  ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                  )))
                               ) (MP  
                                  (SPEC `(mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))))` 
                                   (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                    (or__introl))
                                  ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                  )))))))
                     ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                     ))))
               ) (ASSUME `(mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))`
               ))))
         ) (ASSUME `ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))`
         )))
      ) (ASSUME `(((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
      ))))))
 ;;


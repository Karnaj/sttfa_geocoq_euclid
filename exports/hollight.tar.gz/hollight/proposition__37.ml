(*proposition__37 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((par A) D) B) C) ==> ((((((eT A) B) C) D) B) C)))))`*)
let proposition__37 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (MP  
      (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
       (MP  
        (DISCH `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
         (MP  
          (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
           (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
            (MP  
             (CONV_CONV_rule `((eq (D : mat_Point)) (D : mat_Point)) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
              (DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
               (MP  
                (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (D : mat_Point))))))) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                 (DISCH `((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                  (MP  
                   (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))))))) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                    (DISCH `((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                     (MP  
                      (DISCH `ex (\ E : mat_Point. ((mat_and ((((pG (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                       (MP  
                        (MP  
                         (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((pG (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and ((((pG (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))))) ==> (return : bool)))` 
                           (SPEC `\ E : mat_Point. ((mat_and ((((pG (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                            (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                         ) (GEN `(E : mat_Point)` 
                            (DISCH `(mat_and ((((pG (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (SPEC `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                 (SPEC `(((pG (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(((pG (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                   (MP  
                                    (DISCH `ex (\ F : mat_Point. ((mat_and ((((pG (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (F : mat_Point))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((pG (D : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and ((((pG (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (F : mat_Point))))) ==> (return : bool)))` 
                                         (SPEC `\ F : mat_Point. ((mat_and ((((pG (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (F : mat_Point)))` 
                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                           (ex__ind))))
                                       ) (GEN `(F : mat_Point)` 
                                          (DISCH `(mat_and ((((pG (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (SPEC `((col (A : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                               (SPEC `(((pG (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((pG (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (DISCH `((col (A : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((pG (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (MP  
                                                      (DISCH `((col (D : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                       (MP  
                                                        (DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                               (MP  
                                                                (DISCH `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((cong__3 (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((cong__3 (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (A : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ m : mat_Point. ((mat_and (((betS (F : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. ((mat_and (((betS (F : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ m : mat_Point. ((mat_and (((betS (F : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (F : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (F : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (M : mat_Point)) (A : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (M : mat_Point))))))) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (m : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (m : mat_Point)) (D : mat_Point))) ((mat_or (((betS (m : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (m : mat_Point))))))) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)))))) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((tS (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point)))))) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((tS (F : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__halvesofequals
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__congruentequal
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((cong__3 (B : mat_Point)) (F : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__congruentequal
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((cong__3 (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (F : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (F : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (F : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (F : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (F : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (F : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (F : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (F : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (F : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (F : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (F : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (F : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (F : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (F : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (F : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (D : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (F : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (F : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (F : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> ((((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> ((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (m : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point))) (((col (D : mat_Point)) (m : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point))) (((col (D : mat_Point)) (m : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point))) (((col (D : mat_Point)) (m : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point))) (((col (D : mat_Point)) (m : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point))) (((col (D : mat_Point)) (m : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point))) (((col (D : mat_Point)) (m : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point))) (((col (D : mat_Point)) (m : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point))) (((col (D : mat_Point)) (m : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point))) (((col (D : mat_Point)) (m : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point))) (((col (D : mat_Point)) (m : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (m : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (m : mat_Point))) (((col (D : mat_Point)) (m : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (m : mat_Point)) (D : mat_Point))) ((mat_or (((betS (m : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (m : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (m : mat_Point)) (D : mat_Point))) ((mat_or (((betS (m : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (m : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (m : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (m : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (m : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (m : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (D : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (M : mat_Point)) (A : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (A : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (F : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ m : mat_Point. ((mat_and (((betS (F : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (m : mat_Point)) (D : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__diagonalsmeet
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (E : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (A : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__diagonalsmeet
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                                                    (
                                                                    ASSUME `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                                                    (
                                                                    ASSUME `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((cong (A00 : mat_Point)) (C00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point))) ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                                                    (
                                                                    ASSUME `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__34
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                                                    (
                                                                    ASSUME `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                                                    (
                                                                    ASSUME `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((cong (A00 : mat_Point)) (C00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point))) ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                                                    (
                                                                    ASSUME `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__34
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    proposition__35
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                  ))))
                                                                ) (MP  
                                                                   (CONV_CONV_rule `((((nCol (A : mat_Point)) (F : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                   ) (
                                                                   DISCH `((nCol (A : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                              ) (MP  
                                                                 (SPEC `(D : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (lemma__inequalitysymmetric
                                                                   ))
                                                                 ) (ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                 )))
                                                            ) (MP  
                                                               (DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                   (SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))))`
                                                                 ))
                                                               ) (MP  
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                  ))))
                                                          ) (MP  
                                                             (DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                 (SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                  (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                   (DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(D : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                ) (ASSUME `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                ))))
                                                        ) (MP  
                                                           (DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                               (SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                (SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                 (DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                             ))
                                                           ) (MP  
                                                              (SPEC `(E : mat_Point)` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (lemma__collinearorder
                                                                 )))
                                                              ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                              ))))
                                                      ) (MP  
                                                         (DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((col (D : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                             (SPEC `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                              (SPEC `((col (D : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((col (D : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                               (DISCH `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((col (D : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                   (SPEC `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((col (D : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((col (D : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (D : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) (((col (F : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(F : mat_Point)` 
                                                             (SPEC `(D : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (lemma__collinearorder
                                                               )))
                                                            ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                            ))))
                                                    ) (MP  
                                                       (SPEC `(C : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(F : mat_Point)` 
                                                          (SPEC `(D : mat_Point)` 
                                                           (lemma__PGrotate))
                                                         ))
                                                       ) (ASSUME `(((pG (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                       )))
                                                  ) (MP  
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(E : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (lemma__PGrotate))))
                                                     ) (ASSUME `(((pG (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                     )))))
                                            ) (ASSUME `(mat_and ((((pG (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (F : mat_Point))`
                                            ))))
                                      ) (ASSUME `ex (\ F : mat_Point. ((mat_and ((((pG (D : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (F : mat_Point))))`
                                      ))
                                    ) (MP  
                                       (MP  
                                        (SPEC `(D : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (SPEC `(C : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (lemma__triangletoparallelogram)
                                            ))))
                                        ) (ASSUME `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                        )
                                       ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                       )))))
                              ) (ASSUME `(mat_and ((((pG (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))`
                              ))))
                        ) (ASSUME `ex (\ E : mat_Point. ((mat_and ((((pG (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))))`
                        ))
                      ) (MP  
                         (MP  
                          (SPEC `(D : mat_Point)` 
                           (SPEC `(A : mat_Point)` 
                            (SPEC `(C : mat_Point)` 
                             (SPEC `(B : mat_Point)` 
                              (SPEC `(A : mat_Point)` 
                               (lemma__triangletoparallelogram)))))
                          ) (ASSUME `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                          )
                         ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                         ))))
                   ) (MP  
                      (SPEC `(mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point)))))` 
                       (SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                        (or__intror))
                      ) (MP  
                         (SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))))` 
                          (SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                           (or__intror))
                         ) (MP  
                            (SPEC `(mat_or (((betS (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point)))` 
                             (SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                              (or__introl))
                            ) (ASSUME `(eq (D : mat_Point)) (D : mat_Point)`)
                         )))))
                ) (MP  
                   (SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (D : mat_Point)))))` 
                    (SPEC `(eq (A : mat_Point)) (D : mat_Point)` (or__intror)
                    )
                   ) (MP  
                      (SPEC `(mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                       (SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                        (or__introl))
                      ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`)))))
             ) (SPEC `(D : mat_Point)` 
                (PINST [(`:mat_Point`,`:A`)] [] (eq__refl)))))
          ) (SPEC `(A : mat_Point)` 
             (PINST [(`:mat_Point`,`:A`)] [] (eq__refl))))
        ) (MP  
           (DISCH `(mat_and ((((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
            (MP  
             (MP  
              (SPEC `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
               (SPEC `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                (SPEC `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                 (and__ind)))
              ) (DISCH `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                 (DISCH `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                  (MP  
                   (MP  
                    (SPEC `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                     (SPEC `(((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                      (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                       (DISCH `(((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                        (ASSUME `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                        )))
                   ) (ASSUME `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                   ))))
             ) (ASSUME `(mat_and ((((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
             ))
           ) (MP  
              (SPEC `(D : mat_Point)` 
               (SPEC `(A : mat_Point)` 
                (SPEC `(C : mat_Point)` 
                 (SPEC `(B : mat_Point)` (lemma__parallelflip))))
              ) (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
              ))))
      ) (MP  
         (SPEC `(C : mat_Point)` 
          (SPEC `(B : mat_Point)` 
           (SPEC `(D : mat_Point)` 
            (SPEC `(A : mat_Point)` (lemma__parallelsymmetric))))
         ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
         )))))))
 ;;


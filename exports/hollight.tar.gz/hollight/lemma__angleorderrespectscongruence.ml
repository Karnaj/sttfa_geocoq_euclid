(*lemma__angleorderrespectscongruence :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (((((((ltA A) B) C) D) E) F) ==> (((((((congA P) Q) R) D) E) F) ==> ((((((ltA A) B) C) P) Q) R)))))))))))`*)
let lemma__angleorderrespectscongruence =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(P : mat_Point)` 
       (GEN `(Q : mat_Point)` 
        (GEN `(R : mat_Point)` 
         (DISCH `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
          (DISCH `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
           (MP  
            (CONV_CONV_rule `((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
             (DISCH `ex (\ G : mat_Point. (ex (\ H1 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H1 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H1 : mat_Point))))))))))` 
              (MP  
               (MP  
                (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ H2 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (x : mat_Point)) (H2 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H2 : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. (ex (\ H2 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H2 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H2 : mat_Point))))))))))) ==> (return : bool)))` 
                  (SPEC `\ G : mat_Point. (ex (\ H2 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H2 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H2 : mat_Point)))))))))` 
                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                ) (GEN `(G : mat_Point)` 
                   (DISCH `ex (\ H2 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H2 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H2 : mat_Point))))))))` 
                    (MP  
                     (MP  
                      (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (x : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ H3 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point))))))))) ==> (return : bool)))` 
                        (SPEC `\ H3 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)))))))` 
                         (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                      ) (GEN `(H3 : mat_Point)` 
                         (DISCH `ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point))))))` 
                          (MP  
                           (MP  
                            (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (G : mat_Point)) (H3 : mat_Point)) (x : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point))))) ==> (return : bool))) ==> ((ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point))))))) ==> (return : bool)))` 
                              (SPEC `\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)))))` 
                               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                            ) (GEN `(J : mat_Point)` 
                               (DISCH `(mat_and (((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                   (SPEC `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)))` 
                                    (SPEC `((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point)` 
                                     (DISCH `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                         (SPEC `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point))` 
                                          (SPEC `((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                           (DISCH `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                               (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)` 
                                                (SPEC `((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                 (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))` 
                                                    (MP  
                                                     (DISCH `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                      (MP  
                                                       (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))` 
                                                        (MP  
                                                         (DISCH `(neq (E : mat_Point)) (G : mat_Point)` 
                                                          (MP  
                                                           (DISCH `ex (\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (G : mat_Point))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))))) ==> (return : bool)))` 
                                                                (SPEC `\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point)))` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (ex__ind)))
                                                               )
                                                              ) (GEN `(U : mat_Point)` 
                                                                 (DISCH `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((cong (Q : mat_Point)) (V : mat_Point)) (E : mat_Point)) (J : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x : mat_Point))) ((((cong (Q : mat_Point)) (x : mat_Point)) (E : mat_Point)) (J : mat_Point))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((cong (Q : mat_Point)) (V : mat_Point)) (E : mat_Point)) (J : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((cong (Q : mat_Point)) (V : mat_Point)) (E : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((cong (Q : mat_Point)) (V : mat_Point)) (E : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (V : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (V : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (H3 : mat_Point)) (G : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (X : mat_Point)) (J : mat_Point))) ((((cong (G : mat_Point)) (X : mat_Point)) (G : mat_Point)) (H3 : mat_Point))))) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `(((lt (G : mat_Point)) (H3 : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (G : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (E : mat_Point)) (J : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((((cong (U : mat_Point)) (W : mat_Point)) (G : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (U : mat_Point)) (x : mat_Point)) (V : mat_Point))) ((((cong (U : mat_Point)) (x : mat_Point)) (G : mat_Point)) (H3 : mat_Point))) ==> (return : bool))) ==> ((ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((((cong (U : mat_Point)) (W : mat_Point)) (G : mat_Point)) (H3 : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((((cong (U : mat_Point)) (W : mat_Point)) (G : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(W : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((((cong (U : mat_Point)) (W : mat_Point)) (G : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (W : mat_Point)) (G : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (W : mat_Point)) (G : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (H3 : mat_Point)) (H3 : mat_Point)) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (H3 : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (E : mat_Point)) (H3 : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (U : mat_Point)) (V : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (Q : mat_Point)) (Q : mat_Point)) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (E : mat_Point)) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (U : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (G : mat_Point)) (E : mat_Point)) ==> mat_false) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (G : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (G : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)) (E : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (G : mat_Point)) (J : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)) (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (E : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)) (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)) (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)) (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)) (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (Q : mat_Point)) (W : mat_Point)) ==> mat_false) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (Q : mat_Point)) (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (Q : mat_Point)) (U : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))) ==> (ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V0 : mat_Point. ((mat_and (((betS (U : mat_Point)) (x : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))) ==> (ex (\ V0 : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (U : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (W : mat_Point)) (W : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (U : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (U : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (Q : mat_Point)) (W : mat_Point))) ==> (((out (Q : mat_Point)) (W : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (W : mat_Point)) (W : mat_Point))) (((betS (Q : mat_Point)) (W : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (W : mat_Point)) (W : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (Q : mat_Point)) (W : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (Q : mat_Point)) (U : mat_Point))) ((mat_or ((eq (Q : mat_Point)) (W : mat_Point))) ((mat_or ((eq (U : mat_Point)) (W : mat_Point))) ((mat_or (((betS (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (U : mat_Point)) (W : mat_Point))) (((betS (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ((mat_and (((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ((mat_and (((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (Q : mat_Point)) (W : mat_Point))) ((mat_or ((eq (U : mat_Point)) (W : mat_Point))) ((mat_or (((betS (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (U : mat_Point)) (W : mat_Point))) (((betS (Q : mat_Point)) (W : mat_Point)) (U : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (U : mat_Point)) (W : mat_Point))) ((mat_or (((betS (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ((mat_or (((betS (Q : mat_Point)) (U : mat_Point)) (W : mat_Point))) (((betS (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (W : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)) ==> (((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)) ==> ((eq (W : mat_Point)) (W : mat_Point)))) ==> (((mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ==> ((eq (W : mat_Point)) (W : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H3 : mat_Point)) (E : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)) (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((((((congA (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H3 : mat_Point)) (U : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (E : mat_Point)) (U : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)) (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)) (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)) (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)) (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (E : mat_Point)) (U : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (E : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (U : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (E : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (G : mat_Point)) (E : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (U : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (E : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (E : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (E : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (U : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (E : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (G : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (E : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (E : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (G : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (G : mat_Point)) (E : mat_Point)) (U : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (E : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (U : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (E : mat_Point)) (U : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (E : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (U : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (W : mat_Point)) (G : mat_Point)) (H3 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and (((col (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ((mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) ((mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) (((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ((mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) ((mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) (((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ((mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) ((mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) (((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) ((mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) (((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) ((mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) (((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) (((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) (((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) (((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) ((mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) (((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ((mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) ((mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) (((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and (((col (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ((mat_and (((col (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) ((mat_and (((col (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) (((col (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point))) (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point))) (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point))) (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point))) (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point))) (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point))) (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point))) (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point))) (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point))) (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point))) (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point))) (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ((mat_and (((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((nCol (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((nCol (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((nCol (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((nCol (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((nCol (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((nCol (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (W : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (W : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((nCol (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (Q : mat_Point)) (W : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (Q : mat_Point)) (W : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((nCol (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((nCol (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((nCol (W : mat_Point)) (U : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (U : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ((mat_and (((nCol (U : mat_Point)) (W : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (W : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((nCol (Q : mat_Point)) (W : mat_Point)) (U : mat_Point))) (((nCol (W : mat_Point)) (U : mat_Point)) (Q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)) (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)) (E : mat_Point)) (G : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (E : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (J : mat_Point)) (H3 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H3 : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (U : mat_Point)) (Q : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (U : mat_Point)) (V : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (G : mat_Point)) (E : mat_Point))) ==> (((out (G : mat_Point)) (E : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (E : mat_Point))) (((betS (G : mat_Point)) (E : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (G : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (H3 : mat_Point))) ((mat_or ((eq (G : mat_Point)) (E : mat_Point))) ((mat_or ((eq (H3 : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((betS (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)) ==> mat_false) ==> (((col (U : mat_Point)) (Q : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (E : mat_Point))) ((mat_or ((eq (H3 : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((betS (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H3 : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((betS (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (G : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (Q : mat_Point)) (Q : mat_Point))) (((betS (U : mat_Point)) (Q : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (U : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (U : mat_Point)) (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (U : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (U : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (U : mat_Point))) ((mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (U : mat_Point))) ((mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (U : mat_Point))) ((mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (U : mat_Point))) ((mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (U : mat_Point))) ((mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (U : mat_Point))) ((mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (U : mat_Point))) ((mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (V : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (V : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (U : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (U : mat_Point))) ((mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (U : mat_Point))) ((mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (U : mat_Point))) ((mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (U : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (U : mat_Point))) ((mat_and ((neq (V : mat_Point)) (Q : mat_Point))) ((neq (V : mat_Point)) (U : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (E : mat_Point)) (J : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (W : mat_Point)) (V : mat_Point))) (((betS (U : mat_Point)) (V : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (U : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (W : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (W : mat_Point))) ((neq (U : mat_Point)) (V : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (U : mat_Point)) (W : mat_Point))) ((neq (U : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (W : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (W : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (U : mat_Point)) (W : mat_Point))) ((neq (U : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (U : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (U : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (U : mat_Point)) (W : mat_Point))) ((neq (U : mat_Point)) (V : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (W : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (W : mat_Point))) ((neq (U : mat_Point)) (V : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (H3 : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (H3 : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H3 : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H3 : mat_Point)) (E : mat_Point))) (((nCol (H3 : mat_Point)) (E : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H3 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (H3 : mat_Point)) (H3 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H3 : mat_Point)) (H3 : mat_Point))) (((betS (E : mat_Point)) (H3 : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (H3 : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (H3 : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (H3 : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (H3 : mat_Point)) (H3 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (H3 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((((cong (U : mat_Point)) (W : mat_Point)) (G : mat_Point)) (H3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((((cong (U : mat_Point)) (W : mat_Point)) (G : mat_Point)) (H3 : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((((cong (U : mat_Point)) (W : mat_Point)) (G : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((((cong (U : mat_Point)) (W : mat_Point)) (G : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    proposition__03
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (G : mat_Point)) (H3 : mat_Point)) (G : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (G : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H3 : mat_Point)) (J : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H3 : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (H3 : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H3 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H3 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (H3 : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (H3 : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H3 : mat_Point)) (J : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H3 : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (U : mat_Point)) (V : mat_Point))) ((((((congA (E : mat_Point)) (J : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (U : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (E : mat_Point)) (J : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (V : mat_Point)) (E : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (G : mat_Point)) (E : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (G : mat_Point)) (x : mat_Point)) (J : mat_Point))) ((((cong (G : mat_Point)) (x : mat_Point)) (G : mat_Point)) (H3 : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (X : mat_Point)) (J : mat_Point))) ((((cong (G : mat_Point)) (X : mat_Point)) (G : mat_Point)) (H3 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (X : mat_Point)) (J : mat_Point))) ((((cong (G : mat_Point)) (X : mat_Point)) (G : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H3 : mat_Point)) (G : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H3 : mat_Point)) (G : mat_Point)) (H3 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((cong (Q : mat_Point)) (V : mat_Point)) (E : mat_Point)) (J : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((cong (Q : mat_Point)) (V : mat_Point)) (E : mat_Point)) (J : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `ex (\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))))`
                                                             ))
                                                           ) (MP  
                                                              (MP  
                                                               (SPEC `ex (\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                                (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((((cong (Q : mat_Point)) (U : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))`
                                                              )))
                                                         ) (MP  
                                                            (MP  
                                                             (SPEC `(neq (E : mat_Point)) (G : mat_Point)` 
                                                              (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))`
                                                            )))
                                                       ) (MP  
                                                          (MP  
                                                           (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))` 
                                                            (SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                             (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                              (DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))` 
                                                                  (SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                   (SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (D : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (H3 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (D : mat_Point)) (H3 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                                ))))
                                                          ) (ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                          )))
                                                     ) (MP  
                                                        (MP  
                                                         (SPEC `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                          (SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                           (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                            (DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                (SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                 (SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                              ))))
                                                        ) (ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                        )))
                                                   ) (MP  
                                                      (MP  
                                                       (SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                        (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                         (conj))
                                                       ) (MP  
                                                          (DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                              (SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                               (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                (DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                   (DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                            ))
                                                          ) (MP  
                                                             (SPEC `(F : mat_Point)` 
                                                              (SPEC `(E : mat_Point)` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (SPEC `(R : mat_Point)` 
                                                                 (SPEC `(Q : mat_Point)` 
                                                                  (SPEC `(P : mat_Point)` 
                                                                   (lemma__angledistinct
                                                                   ))))))
                                                             ) (ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                             )))
                                                      ) (MP  
                                                         (MP  
                                                          (SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                           (SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                            (conj))
                                                          ) (MP  
                                                             (DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                 (SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                  (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                   (DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (Q : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(F : mat_Point)` 
                                                                 (SPEC `(E : mat_Point)` 
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                ) (ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                )))
                                                         ) (MP  
                                                            (MP  
                                                             (SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                              (SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                               (conj))
                                                             ) (MP  
                                                                (DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                   (DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (P : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                   ) (
                                                                   ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                   )))
                                                            ) (MP  
                                                               (MP  
                                                                (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                 (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                  (conj))
                                                                ) (MP  
                                                                   (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (H3 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (D : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H3 : mat_Point))) ((neq (D : mat_Point)) (H3 : mat_Point))))))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(H3 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                   ) (
                                                                   ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)`
                                                                   )))
                                                               ) (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   MP  
                                                                   (DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                   ) (
                                                                   ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                   )))
                                                                  ) (
                                                                  MP  
                                                                  (DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (D : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (R : mat_Point))) ((mat_and ((neq (P : mat_Point)) (R : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(F : mat_Point)` 
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                  ) (
                                                                  ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                  )))))))))))
                                             ) (ASSUME `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point))`
                                             ))))
                                       ) (ASSUME `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point)))`
                                       ))))
                                 ) (ASSUME `(mat_and (((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point))))`
                                 ))))
                           ) (ASSUME `ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H3 : mat_Point))))))`
                           ))))
                     ) (ASSUME `ex (\ H2 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H2 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H2 : mat_Point))))))))`
                     ))))
               ) (ASSUME `ex (\ G : mat_Point. (ex (\ H1 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H1 : mat_Point)) (J : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H1 : mat_Point))))))))))`
               )))
            ) (ASSUME `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
            ))))))))))))
 ;;


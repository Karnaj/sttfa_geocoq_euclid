(*lemma__9__5a :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (((((tS P) A) B) C) ==> ((((betS R) P) Q) ==> ((((nCol R) Q) C) ==> ((((col A) B) R) ==> ((((tS Q) A) B) C))))))))))`*)
let lemma__9__5a =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(P : mat_Point)` 
    (GEN `(Q : mat_Point)` 
     (GEN `(R : mat_Point)` 
      (DISCH `(((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (DISCH `((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
        (DISCH `((nCol (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
         (DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
          (MP  
           (CONV_CONV_rule `((((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
            (DISCH `ex (\ S : mat_Point. ((mat_and (((betS (P : mat_Point)) (S : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
             (MP  
              (MP  
               (SPEC `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))) ==> (return : bool))) ==> ((ex (\ S : mat_Point. ((mat_and (((betS (P : mat_Point)) (S : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))) ==> (return : bool)))` 
                 (SPEC `\ S : mat_Point. ((mat_and (((betS (P : mat_Point)) (S : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                  (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
               ) (GEN `(S : mat_Point)` 
                  (DISCH `(mat_and (((betS (P : mat_Point)) (S : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                   (MP  
                    (MP  
                     (SPEC `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                       (SPEC `((betS (P : mat_Point)) (S : mat_Point)) (C : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((betS (P : mat_Point)) (S : mat_Point)) (C : mat_Point)` 
                        (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                         (MP  
                          (MP  
                           (SPEC `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                             (SPEC `((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                              (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                               (MP  
                                (DISCH `((betS (C : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                 (MP  
                                  (DISCH `ex (\ F : mat_Point. ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (Q : mat_Point))) (((betS (R : mat_Point)) (S : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point))))) ==> (return : bool)))` 
                                       (SPEC `\ F : mat_Point. ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point)))` 
                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                         (ex__ind))))
                                     ) (GEN `(F : mat_Point)` 
                                        (DISCH `(mat_and (((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (SPEC `((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point)` 
                                             (SPEC `((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                              (DISCH `((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point)` 
                                               (MP  
                                                (CONV_CONV_rule `((mat_or ((eq (R : mat_Point)) (S : mat_Point))) ((mat_or ((eq (R : mat_Point)) (F : mat_Point))) ((mat_or ((eq (S : mat_Point)) (F : mat_Point))) ((mat_or (((betS (S : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_or (((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point))) (((betS (R : mat_Point)) (F : mat_Point)) (S : mat_Point))))))) ==> ((((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                 (DISCH `((col (R : mat_Point)) (S : mat_Point)) (F : mat_Point)` 
                                                  (MP  
                                                   (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                    (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                                                     (MP  
                                                      (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                       (MP  
                                                        (DISCH `((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(neq (R : mat_Point)) (S : mat_Point)` 
                                                             (MP  
                                                              (DISCH `((col (S : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                               (MP  
                                                                (DISCH `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> ((((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (Q : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))) ==> ((((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((tS (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (Q : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (Q : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (Q : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (F : mat_Point))) ((mat_or ((eq (C : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (F : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (F : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (R : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (R : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (R : mat_Point)) (Q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (R : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (Q : mat_Point)) (R : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (Q : mat_Point)) (R : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (Q : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (Q : mat_Point)) (R : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (Q : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (F : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (F : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (F : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (F : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (F : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (F : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((betS (C : mat_Point)) (Q : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((mat_and (((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (R : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (A : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (R : mat_Point)) (Q : mat_Point))) ((mat_and (((col (F : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_and (((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point))) (((col (Q : mat_Point)) (F : mat_Point)) (R : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (R : mat_Point)) (F : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (R : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (R : mat_Point)) (F : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (R : mat_Point))) ==> (((col (R : mat_Point)) (F : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (R : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (R : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((neq (B : mat_Point)) (A : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)) ==> ((((col (S : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> ((((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> (((col (A : mat_Point)) (R : mat_Point)) (Q : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (R : mat_Point)) ==> (((((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((neq (B : mat_Point)) (A : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)) ==> ((((col (S : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> ((((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> (((col (A : mat_Point)) (R : mat_Point)) (Q : mat_Point))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((tS (P : mat_Point)) (A : mat_Point)) (R : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (R : mat_Point)) (R : mat_Point)) ==> ((((col (A : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((nCol (A : mat_Point)) (R : mat_Point)) (P : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (R : mat_Point))) ==> (((neq (R : mat_Point)) (A : mat_Point)) ==> ((((col (R : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (R : mat_Point)) ==> ((((col (S : mat_Point)) (F : mat_Point)) (R : mat_Point)) ==> ((((col (S : mat_Point)) (R : mat_Point)) (A : mat_Point)) ==> ((((col (S : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (R : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((col (R : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (R : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (R : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (R : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> ((((col (R : mat_Point)) (A : mat_Point)) (Q : mat_Point)) ==> ((((col (R : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> (((col (A : mat_Point)) (R : mat_Point)) (Q : mat_Point)))))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (R : mat_Point)) ==> (((((tS (P : mat_Point)) (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (R : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (S : mat_Point)) ==> ((((nCol (A : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (A : mat_Point)) ==> ((((col (x : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (x : mat_Point)) ==> ((((col (S : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> ((((col (S : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> ((((col (S : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((col (x : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((col (x : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (x : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (x : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (x : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> ((((col (x : mat_Point)) (A : mat_Point)) (Q : mat_Point)) ==> ((((col (x : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> (((col (A : mat_Point)) (R : mat_Point)) (Q : mat_Point))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. (((((tS (P : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (R : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (S : mat_Point)) ==> ((((nCol (A : mat_Point)) (B0 : mat_Point)) (P : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (B0 : mat_Point))) ==> (((neq (B0 : mat_Point)) (A : mat_Point)) ==> ((((col (B0 : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (B0 : mat_Point)) ==> ((((col (S : mat_Point)) (F : mat_Point)) (B0 : mat_Point)) ==> ((((col (S : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) ==> ((((col (S : mat_Point)) (B0 : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (Q : mat_Point)) ==> ((((col (B0 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((col (B0 : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (B0 : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (B0 : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (B0 : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> ((((col (B0 : mat_Point)) (A : mat_Point)) (Q : mat_Point)) ==> ((((col (B0 : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> (((col (A : mat_Point)) (R : mat_Point)) (Q : mat_Point))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((tS (P : mat_Point)) (A : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((neq (B : mat_Point)) (A : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)) ==> ((((col (S : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> ((((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((col (A : mat_Point)) (R : mat_Point)) (F : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (R : mat_Point)) ==> (((((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((neq (B : mat_Point)) (A : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)) ==> ((((col (S : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> ((((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((col (A : mat_Point)) (R : mat_Point)) (F : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((tS (P : mat_Point)) (A : mat_Point)) (R : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (R : mat_Point)) (R : mat_Point)) ==> ((((col (A : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((nCol (A : mat_Point)) (R : mat_Point)) (P : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (R : mat_Point))) ==> (((neq (R : mat_Point)) (A : mat_Point)) ==> ((((col (R : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (R : mat_Point)) ==> ((((col (S : mat_Point)) (F : mat_Point)) (R : mat_Point)) ==> ((((col (S : mat_Point)) (R : mat_Point)) (A : mat_Point)) ==> ((((col (S : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (R : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((col (R : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (R : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (R : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (R : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((col (A : mat_Point)) (R : mat_Point)) (F : mat_Point)))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (R : mat_Point)) ==> (((((tS (P : mat_Point)) (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (R : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (S : mat_Point)) ==> ((((nCol (A : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (A : mat_Point)) ==> ((((col (x : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (x : mat_Point)) ==> ((((col (S : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> ((((col (S : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> ((((col (S : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((col (x : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((col (x : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (x : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (x : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (x : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((col (A : mat_Point)) (R : mat_Point)) (F : mat_Point))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. (((((tS (P : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (R : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (S : mat_Point)) ==> ((((nCol (A : mat_Point)) (B0 : mat_Point)) (P : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (B0 : mat_Point))) ==> (((neq (B0 : mat_Point)) (A : mat_Point)) ==> ((((col (B0 : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (B0 : mat_Point)) ==> ((((col (S : mat_Point)) (F : mat_Point)) (B0 : mat_Point)) ==> ((((col (S : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) ==> ((((col (S : mat_Point)) (B0 : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (F : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (Q : mat_Point)) ==> ((((col (B0 : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> ((((col (B0 : mat_Point)) (R : mat_Point)) (Q : mat_Point)) ==> ((((col (B0 : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> ((((col (B0 : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (B0 : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((col (A : mat_Point)) (R : mat_Point)) (F : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((tS (P : mat_Point)) (A : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (R : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (R : mat_Point)) (F : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (R : mat_Point)) ==> (((eq (R : mat_Point)) (B : mat_Point)) ==> ((eq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__trans
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (R : mat_Point)) ==> ((eq (R : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__sym))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (R : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (((col (R : mat_Point)) (Q : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (R : mat_Point)) (Q : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (R : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    eq__or__neq
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (R : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (R : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((col (B : mat_Point)) (R : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (Q : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (Q : mat_Point))) (((col (R : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((col (B : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (S : mat_Point)) (B : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (S : mat_Point)) (B : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (S : mat_Point)) (B : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (S : mat_Point)) (B : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (S : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (R : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (R : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (R : mat_Point)) (B : mat_Point))) ==> (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (R : mat_Point)) (B : mat_Point))`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(eq (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (R : mat_Point)) (S : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(eq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (R : mat_Point)) (S : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (R : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (R : mat_Point)) (S : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (R : mat_Point)) (S : mat_Point)) ==> (((neq (R : mat_Point)) (S : mat_Point)) ==> ((neq (R : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (R : mat_Point)) (B : mat_Point)) ==> ((((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> ((((nCol (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)) ==> (((neq (R : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((eq (R : mat_Point)) (S : mat_Point)) ==> (((neq (R : mat_Point)) (S : mat_Point)) ==> ((neq (R : mat_Point)) (B : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> ((((nCol (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((betS (B : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (S : mat_Point)) ==> ((((col (B : mat_Point)) (S : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (S : mat_Point)) ==> ((((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((eq (B : mat_Point)) (S : mat_Point)) ==> (((neq (B : mat_Point)) (S : mat_Point)) ==> ((neq (B : mat_Point)) (B : mat_Point))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((betS (x : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> ((((nCol (x : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (x : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (x : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (S : mat_Point)) ==> ((((col (x : mat_Point)) (S : mat_Point)) (B : mat_Point)) ==> (((neq (x : mat_Point)) (S : mat_Point)) ==> ((((col (x : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((eq (x : mat_Point)) (S : mat_Point)) ==> (((neq (x : mat_Point)) (S : mat_Point)) ==> ((neq (x : mat_Point)) (B : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ R0 : mat_Point. ((((betS (R0 : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> ((((nCol (R0 : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (R0 : mat_Point)) ==> ((((betS (R0 : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (R0 : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (R0 : mat_Point)) (S : mat_Point)) ==> ((((col (R0 : mat_Point)) (S : mat_Point)) (B : mat_Point)) ==> (((neq (R0 : mat_Point)) (S : mat_Point)) ==> ((((col (R0 : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (R0 : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (R0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((eq (R0 : mat_Point)) (S : mat_Point)) ==> (((neq (R0 : mat_Point)) (S : mat_Point)) ==> ((neq (R0 : mat_Point)) (B : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (S : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (S : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (S : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)) ==> ((((betS (C : mat_Point)) (S : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((betS (B : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> (((neq (B : mat_Point)) (S : mat_Point)) ==> ((((col (B : mat_Point)) (S : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (S : mat_Point)) ==> ((((col (S : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> ((((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)) ==> ((((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> (((neq (B : mat_Point)) (S : mat_Point)) ==> (((eq (B : mat_Point)) (S : mat_Point)) ==> ((neq (B : mat_Point)) (B : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((betS (B : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((neq (B : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((neq (B : mat_Point)) (B : mat_Point)) ==> (((eq (B : mat_Point)) (B : mat_Point)) ==> ((neq (B : mat_Point)) (B : mat_Point))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (C : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> ((((betS (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> (((eq (B : mat_Point)) (x : mat_Point)) ==> ((neq (B : mat_Point)) (B : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ S0 : mat_Point. ((((betS (P : mat_Point)) (S0 : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (S0 : mat_Point)) ==> ((((betS (C : mat_Point)) (S0 : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (S0 : mat_Point)) (F : mat_Point)) ==> ((((betS (B : mat_Point)) (S0 : mat_Point)) (F : mat_Point)) ==> (((neq (B : mat_Point)) (S0 : mat_Point)) ==> ((((col (B : mat_Point)) (S0 : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (S0 : mat_Point)) ==> ((((col (S0 : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> ((((col (S0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (S0 : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (S0 : mat_Point)) ==> ((((col (B : mat_Point)) (S0 : mat_Point)) (F : mat_Point)) ==> (((neq (B : mat_Point)) (S0 : mat_Point)) ==> (((eq (B : mat_Point)) (S0 : mat_Point)) ==> ((neq (B : mat_Point)) (B : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (S : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (S : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (S : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (S : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (B : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (S : mat_Point)`
                                                                    )))))))))
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (R : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (R : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (R : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (R : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (F : mat_Point))) ((mat_and ((neq (R : mat_Point)) (S : mat_Point))) ((neq (R : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (R : mat_Point)) (S : mat_Point))) ((neq (R : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (R : mat_Point)) (S : mat_Point))) ((neq (R : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (R : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (R : mat_Point)) (S : mat_Point))) ((neq (R : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (F : mat_Point))) ((mat_and ((neq (R : mat_Point)) (S : mat_Point))) ((neq (R : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (R : mat_Point)) (B : mat_Point)) ==> (((eq (B : mat_Point)) (S : mat_Point)) ==> ((eq (R : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__trans
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (R : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (S : mat_Point)) (B : mat_Point)) ==> ((eq (B : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__sym))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (S : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (S : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (S : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)) ==> ((((betS (C : mat_Point)) (S : mat_Point)) (P : mat_Point)) ==> ((((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)) ==> (((neq (R : mat_Point)) (S : mat_Point)) ==> ((((col (S : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> ((((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)) ==> ((((col (R : mat_Point)) (S : mat_Point)) (F : mat_Point)) ==> (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((betS (R : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (B : mat_Point)) ==> ((((col (R : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((neq (R : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (C : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((((betS (R : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> ((((col (R : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (x : mat_Point)) ==> ((((col (R : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((neq (R : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((col (R : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ S0 : mat_Point. ((((betS (P : mat_Point)) (S0 : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (S0 : mat_Point)) ==> ((((betS (C : mat_Point)) (S0 : mat_Point)) (P : mat_Point)) ==> ((((betS (R : mat_Point)) (S0 : mat_Point)) (F : mat_Point)) ==> ((((col (R : mat_Point)) (S0 : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (R : mat_Point)) (S0 : mat_Point)) ==> ((((col (R : mat_Point)) (S0 : mat_Point)) (B : mat_Point)) ==> (((neq (R : mat_Point)) (S0 : mat_Point)) ==> ((((col (S0 : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> ((((col (S0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (S0 : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (S0 : mat_Point)) ==> ((((col (R : mat_Point)) (S0 : mat_Point)) (F : mat_Point)) ==> (((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (R : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (R : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))))))
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(eq (S : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (S : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (S : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (R : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point))) ((mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point))) ((mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (S : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (S : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point))) ((mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point))) ((mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point))) ((mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (S : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (S : mat_Point)) (B : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (S : mat_Point)) (B : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (S : mat_Point)) (B : mat_Point))) ((neq (S : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    eq__or__neq
                                                                    )))))
                                                                  ) (
                                                                  MP  
                                                                  (DISCH `(mat_and (((col (F : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (S : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (S : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (F : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (S : mat_Point)))))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((col (S : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                  ))))
                                                                ) (MP  
                                                                   (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (A : mat_Point))) ((mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (A : mat_Point))) ((mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (A : mat_Point))) ((mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (S : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (S : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (A : mat_Point))) ((mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (S : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (A : mat_Point))) ((mat_and (((col (S : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (S : mat_Point)) (B : mat_Point))) (((col (S : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)`
                                                                   ))))
                                                              ) (MP  
                                                                 (CONV_CONV_rule `((((nCol (S : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (S : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                 ) (DISCH `((nCol (S : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (S : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (R : mat_Point)) (S : mat_Point)`
                                                                    ))))))
                                                            ) (MP  
                                                               (DISCH `(mat_and ((neq (S : mat_Point)) (F : mat_Point))) ((mat_and ((neq (R : mat_Point)) (S : mat_Point))) ((neq (R : mat_Point)) (F : mat_Point)))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                   (SPEC `(mat_and ((neq (R : mat_Point)) (S : mat_Point))) ((neq (R : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(neq (S : mat_Point)) (F : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (R : mat_Point)) (S : mat_Point))) ((neq (R : mat_Point)) (F : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (R : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (R : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (R : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (R : mat_Point)) (S : mat_Point))) ((neq (R : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((neq (S : mat_Point)) (F : mat_Point))) ((mat_and ((neq (R : mat_Point)) (S : mat_Point))) ((neq (R : mat_Point)) (F : mat_Point)))`
                                                                 ))
                                                               ) (MP  
                                                                  (SPEC `(F : mat_Point)` 
                                                                   (SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                                  ))))
                                                          ) (MP  
                                                             (DISCH `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_and (((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (R : mat_Point)) (B : mat_Point)))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (R : mat_Point)) (B : mat_Point))))` 
                                                                  (SPEC `((col (R : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (R : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (R : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (R : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (R : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (R : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (R : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (R : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (R : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (R : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (S : mat_Point))) ((mat_and (((col (R : mat_Point)) (S : mat_Point)) (B : mat_Point))) ((mat_and (((col (S : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (S : mat_Point)) (R : mat_Point))) (((col (S : mat_Point)) (R : mat_Point)) (B : mat_Point)))))`
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(S : mat_Point)` 
                                                                 (SPEC `(R : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (lemma__collinearorder
                                                                   )))
                                                                ) (ASSUME `((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point)`
                                                                ))))
                                                        ) (MP  
                                                           (CONV_CONV_rule `((((nCol (B : mat_Point)) (R : mat_Point)) (S : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                            (SPEC `(S : mat_Point)` 
                                                             (SPEC `(R : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (not__nCol__Col
                                                               ))))
                                                           ) (DISCH `((nCol (B : mat_Point)) (R : mat_Point)) (S : mat_Point)` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(S : mat_Point)` 
                                                                 (SPEC `(R : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (col__nCol__False
                                                                   )))
                                                                ) (ASSUME `((nCol (B : mat_Point)) (R : mat_Point)) (S : mat_Point)`
                                                                )
                                                               ) (MP  
                                                                  (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((col (B : mat_Point)) (R : mat_Point)) (S : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point)`
                                                                    ))
                                                                  ) (
                                                                  ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                  ))))))
                                                      ) (MP  
                                                         (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((neq (B : mat_Point)) (A : mat_Point))` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (lemma__inequalitysymmetric
                                                            )))
                                                         ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                         ))))
                                                   ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                      (MP  
                                                       (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                        (DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(P : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (col__nCol__False
                                                              )))
                                                           ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                           )
                                                          ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                          )))
                                                       ) (MP  
                                                          (SPEC `(mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))))` 
                                                           (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                            (or__introl))
                                                          ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                          ))))))
                                                ) (MP  
                                                   (SPEC `(mat_or ((eq (R : mat_Point)) (F : mat_Point))) ((mat_or ((eq (S : mat_Point)) (F : mat_Point))) ((mat_or (((betS (S : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_or (((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point))) (((betS (R : mat_Point)) (F : mat_Point)) (S : mat_Point)))))` 
                                                    (SPEC `(eq (R : mat_Point)) (S : mat_Point)` 
                                                     (or__intror))
                                                   ) (MP  
                                                      (SPEC `(mat_or ((eq (S : mat_Point)) (F : mat_Point))) ((mat_or (((betS (S : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_or (((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point))) (((betS (R : mat_Point)) (F : mat_Point)) (S : mat_Point))))` 
                                                       (SPEC `(eq (R : mat_Point)) (F : mat_Point)` 
                                                        (or__intror))
                                                      ) (MP  
                                                         (SPEC `(mat_or (((betS (S : mat_Point)) (R : mat_Point)) (F : mat_Point))) ((mat_or (((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point))) (((betS (R : mat_Point)) (F : mat_Point)) (S : mat_Point)))` 
                                                          (SPEC `(eq (S : mat_Point)) (F : mat_Point)` 
                                                           (or__intror))
                                                         ) (MP  
                                                            (SPEC `(mat_or (((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point))) (((betS (R : mat_Point)) (F : mat_Point)) (S : mat_Point))` 
                                                             (SPEC `((betS (S : mat_Point)) (R : mat_Point)) (F : mat_Point)` 
                                                              (or__intror))
                                                            ) (MP  
                                                               (SPEC `((betS (R : mat_Point)) (F : mat_Point)) (S : mat_Point)` 
                                                                (SPEC `((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point)` 
                                                                 (or__introl)
                                                                )
                                                               ) (ASSUME `((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point)`
                                                               )))))))))
                                          ) (ASSUME `(mat_and (((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point))`
                                          ))))
                                    ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (Q : mat_Point))) (((betS (R : mat_Point)) (S : mat_Point)) (F : mat_Point))))`
                                    ))
                                  ) (MP  
                                     (MP  
                                      (MP  
                                       (SPEC `(Q : mat_Point)` 
                                        (SPEC `(S : mat_Point)` 
                                         (SPEC `(P : mat_Point)` 
                                          (SPEC `(R : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (postulate__Pasch__outer)))))
                                       ) (ASSUME `((betS (C : mat_Point)) (S : mat_Point)) (P : mat_Point)`
                                       )
                                      ) (ASSUME `((betS (R : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                      )
                                     ) (ASSUME `((nCol (R : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                     )))
                                ) (MP  
                                   (SPEC `(C : mat_Point)` 
                                    (SPEC `(S : mat_Point)` 
                                     (SPEC `(P : mat_Point)` 
                                      (axiom__betweennesssymmetry)))
                                   ) (ASSUME `((betS (P : mat_Point)) (S : mat_Point)) (C : mat_Point)`
                                   )))))
                          ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                          ))))
                    ) (ASSUME `(mat_and (((betS (P : mat_Point)) (S : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))`
                    ))))
              ) (ASSUME `ex (\ S : mat_Point. ((mat_and (((betS (P : mat_Point)) (S : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (S : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))`
              )))
           ) (ASSUME `(((tS (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
           )))))))))))
 ;;


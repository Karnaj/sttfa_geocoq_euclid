(*lemma__crossimpliesopposite :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((cR A) B) C) D) ==> ((((nCol A) C) D) ==> ((mat_and ((((tS A) C) D) B)) ((mat_and ((((tS A) D) C) B)) ((mat_and ((((tS B) C) D) A)) ((((tS B) D) C) A)))))))))`*)
let lemma__crossimpliesopposite =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((cR (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
      (MP  
       (CONV_CONV_rule `((((cR (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
        (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
         (MP  
          (MP  
           (SPEC `(mat_and ((((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
             (SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point)))` 
              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
           ) (GEN `(M : mat_Point)` 
              (DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
               (MP  
                (MP  
                 (SPEC `(mat_and ((((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                  (SPEC `((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                   (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                    (DISCH `((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                     (MP  
                      (CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (M : mat_Point)) (D : mat_Point))) ((mat_or (((betS (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (M : mat_Point))))))) ==> ((mat_and ((((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                       (DISCH `((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                        (MP  
                         (DISCH `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                          (MP  
                           (DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                            (MP  
                             (DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                              (MP  
                               (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))) ==> ((mat_and ((((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                (DISCH `(((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                 (MP  
                                  (DISCH `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))) ==> ((mat_and ((((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                     (DISCH `(((tS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                      (MP  
                                       (DISCH `(((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                        (MP  
                                         (DISCH `(((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                          (MP  
                                           (MP  
                                            (SPEC `(mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                             (SPEC `(((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                              (conj))
                                            ) (ASSUME `(((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                            )
                                           ) (MP  
                                              (MP  
                                               (SPEC `(mat_and ((((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                (SPEC `(((tS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                 (conj))
                                               ) (ASSUME `(((tS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                               )
                                              ) (MP  
                                                 (MP  
                                                  (SPEC `(((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                   (SPEC `(((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                    (conj))
                                                  ) (ASSUME `(((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                  )
                                                 ) (ASSUME `(((tS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                 ))))
                                         ) (MP  
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(D : mat_Point)` 
                                                (lemma__oppositesidesymmetric
                                                ))))
                                            ) (ASSUME `(((tS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                            )))
                                       ) (MP  
                                          (SPEC `(B : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (SPEC `(C : mat_Point)` 
                                              (lemma__oppositesidesymmetric))
                                            ))
                                          ) (ASSUME `(((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                          ))))
                                    ) (MP  
                                       (SPEC `(M : mat_Point)` 
                                        (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))))` 
                                         (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                           (ex__intro))))
                                       ) (MP  
                                          (MP  
                                           (SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                            (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                             (conj))
                                           ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                           )
                                          ) (MP  
                                             (MP  
                                              (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                               (SPEC `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                (conj))
                                              ) (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                              )
                                             ) (ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                             )))))
                                  ) (MP  
                                     (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                         (SPEC `(mat_and (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                          (SPEC `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                           (DISCH `(mat_and (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                               (SPEC `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                (SPEC `((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                 (DISCH `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                     (SPEC `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                      (SPEC `((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (DISCH `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                           (SPEC `((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                            (SPEC `((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                             (DISCH `((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                              (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                              )))
                                                         ) (ASSUME `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                             ))))
                                       ) (ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                       ))
                                     ) (MP  
                                        (SPEC `(M : mat_Point)` 
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(C : mat_Point)` 
                                           (lemma__collinearorder)))
                                        ) (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                        )))))
                               ) (MP  
                                  (SPEC `(M : mat_Point)` 
                                   (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
                                    (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__intro))))
                                  ) (MP  
                                     (MP  
                                      (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                       (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                        (conj))
                                      ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                      )
                                     ) (MP  
                                        (MP  
                                         (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                          (SPEC `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                           (conj))
                                         ) (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                         )
                                        ) (ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                        )))))
                             ) (MP  
                                (DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                    (SPEC `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                     (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                      (DISCH `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                          (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                           (SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                (SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                 (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                      (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                        (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                         (ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                              ))))
                                        ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                        ))))
                                  ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                  ))
                                ) (MP  
                                   (SPEC `(A : mat_Point)` 
                                    (SPEC `(D : mat_Point)` 
                                     (SPEC `(C : mat_Point)` (lemma__NCorder)
                                     ))
                                   ) (ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                   ))))
                           ) (MP  
                              (DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                               (MP  
                                (MP  
                                 (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                  (SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                   (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                    (DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                        (SPEC `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                         (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                          (DISCH `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                              (SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                               (SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                (DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                    (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                     (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                       (ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                       )))
                                                  ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                            ))))
                                      ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                      ))))
                                ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                ))
                              ) (MP  
                                 (SPEC `(D : mat_Point)` 
                                  (SPEC `(C : mat_Point)` 
                                   (SPEC `(A : mat_Point)` (lemma__NCorder)))
                                 ) (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                 ))))
                         ) (MP  
                            (DISCH `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point)))))` 
                             (MP  
                              (MP  
                               (SPEC `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                (SPEC `(mat_and (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))))` 
                                 (SPEC `((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                  (DISCH `(mat_and (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                      (SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point)))` 
                                       (SPEC `((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                        (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point)))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                            (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                             (SPEC `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                              (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                  (SPEC `((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                    (DISCH `((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                     (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                     )))
                                                ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))`
                                                ))))
                                          ) (ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point)))`
                                          ))))
                                    ) (ASSUME `(mat_and (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))))`
                                    ))))
                              ) (ASSUME `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point)))))`
                              ))
                            ) (MP  
                               (SPEC `(D : mat_Point)` 
                                (SPEC `(M : mat_Point)` 
                                 (SPEC `(C : mat_Point)` 
                                  (lemma__collinearorder)))
                               ) (ASSUME `((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                               )))))
                      ) (MP  
                         (SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (M : mat_Point)) (D : mat_Point))) ((mat_or (((betS (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (M : mat_Point)))))` 
                          (SPEC `(eq (C : mat_Point)) (M : mat_Point)` 
                           (or__intror))
                         ) (MP  
                            (SPEC `(mat_or ((eq (M : mat_Point)) (D : mat_Point))) ((mat_or (((betS (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (M : mat_Point))))` 
                             (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                              (or__intror))
                            ) (MP  
                               (SPEC `(mat_or (((betS (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (M : mat_Point)))` 
                                (SPEC `(eq (M : mat_Point)) (D : mat_Point)` 
                                 (or__intror))
                               ) (MP  
                                  (SPEC `(mat_or (((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                   (SPEC `((betS (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                    (or__intror))
                                  ) (MP  
                                     (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                      (SPEC `((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                       (or__introl))
                                     ) (ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                     )))))))))
                ) (ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point))`
                ))))
          ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (D : mat_Point))))`
          )))
       ) (ASSUME `(((cR (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
       )))))))
 ;;


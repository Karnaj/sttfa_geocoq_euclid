(*lemma__legsmallerhypotenuse :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((per A) B) C) ==> ((mat_and ((((lt A) B) A) C)) ((((lt B) C) A) C)))))`*)
let lemma__legsmallerhypotenuse =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (DISCH `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
      (MP  
       (CONV_CONV_rule `(((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
        (DISCH `ex (\ D : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))` 
         (MP  
          (MP  
           (SPEC `(mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))) ==> (return : bool)))` 
             (SPEC `\ D : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))))` 
              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
           ) (GEN `(D : mat_Point)` 
              (DISCH `(mat_and (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))` 
               (MP  
                (MP  
                 (SPEC `(mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                  (SPEC `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))` 
                   (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                    (DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))` 
                     (MP  
                      (MP  
                       (SPEC `(mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                        (SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                         (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                          (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                           (MP  
                            (MP  
                             (SPEC `(mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                              (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                               (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                 (MP  
                                  (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                     (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (CONV_CONV_rule `((((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                        (DISCH `mat_not (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                         (MP  
                                          (CONV_CONV_rule `(((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                           (DISCH `((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                            (MP  
                                             (DISCH `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                              (MP  
                                               (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                (MP  
                                                 (DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                    (MP  
                                                     (CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                      (DISCH `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
                                                       (MP  
                                                        (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                           (MP  
                                                            (DISCH `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                             (MP  
                                                              (DISCH `((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                               (MP  
                                                                (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))))) ==> ((mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false) ==> ((mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `mat_not (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((mat_and ((((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `((triangle (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    proposition__19
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((triangle (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence2
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__19
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))) ==> (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                   (DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                  ) (
                                                                  ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                  )))
                                                                ) (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    )))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                   )))
                                                              ) (MP  
                                                                 (MP  
                                                                  (SPEC `((out (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                   (SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                  (DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                 )))
                                                            ) (MP  
                                                               (MP  
                                                                (SPEC `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                 (SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                  (SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                   (DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                               )))
                                                          ) (MP  
                                                             (MP  
                                                              (SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                               (SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                (SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                 (DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                             )))
                                                        ) (MP  
                                                           (MP  
                                                            (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                             (SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                              (SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                               (DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                           ) (ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                           ))))
                                                     ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                        (MP  
                                                         (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                          (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (MP  
                                                            (CONV_CONV_rule `(((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                             (ASSUME `mat_not (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                             )
                                                            ) (MP  
                                                               (CONV_CONV_rule `((((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                (SPEC `(B : mat_Point)` 
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (not__nCol__Col
                                                                   ))))
                                                               ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                   ))))))
                                                         ) (MP  
                                                            (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                             (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                              (or__intror))
                                                            ) (MP  
                                                               (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                 (or__intror)
                                                                )
                                                               ) (MP  
                                                                  (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                   (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                  )))))))
                                                   ) (MP  
                                                      (MP  
                                                       (CONV_CONV_rule `(((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((eq (D : mat_Point)) (D : mat_Point)))) ==> (((mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ==> ((eq (D : mat_Point)) (D : mat_Point)))` 
                                                        (SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                         (SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                          (SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                           (and__ind))))
                                                       ) (DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                          (DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `(D : mat_Point)` 
                                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                                             (eq__refl)))))
                                                      ) (ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                      )))
                                                 ) (MP  
                                                    (MP  
                                                     (CONV_CONV_rule `(((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((eq (C : mat_Point)) (C : mat_Point)))) ==> (((mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ==> ((eq (C : mat_Point)) (C : mat_Point)))` 
                                                      (SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                        (SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                         (and__ind))))
                                                     ) (DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                        (DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                         (SPEC `(C : mat_Point)` 
                                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                                           (eq__refl)))))
                                                    ) (ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                    )))
                                               ) (MP  
                                                  (MP  
                                                   (CONV_CONV_rule `(((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((eq (A : mat_Point)) (A : mat_Point)))) ==> (((mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ==> ((eq (A : mat_Point)) (A : mat_Point)))` 
                                                    (SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                     (SPEC `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                       (and__ind))))
                                                   ) (DISCH `(((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                      (DISCH `(((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                                         (eq__refl)))))
                                                  ) (ASSUME `(mat_and ((((((ltA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((((ltA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                  )))
                                             ) (MP  
                                                (MP  
                                                 (SPEC `(D : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(C : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (proposition__16))))
                                                 ) (ASSUME `((triangle (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                 )
                                                ) (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                ))))
                                          ) (MP  
                                             (SPEC `(B : mat_Point)` 
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (nCol__notCol)))
                                             ) (ASSUME `mat_not (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                             ))))
                                       ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                          (MP  
                                           (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (MP  
                                             (MP  
                                              (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false)` 
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (col__nCol__False))))
                                              ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                              )
                                             ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                             ))
                                           ) (MP  
                                              (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                   (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                    (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                         (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                          (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                               (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                                ))
                                              ) (MP  
                                                 (SPEC `(B : mat_Point)` 
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (lemma__collinearorder)))
                                                 ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                 )))))))
                                    ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                    ))
                                  ) (MP  
                                     (SPEC `(C : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (lemma__rightangleNC)))
                                     ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                     )))))
                            ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))`
                            ))))
                      ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))`
                      ))))
                ) (ASSUME `(mat_and (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))`
                ))))
          ) (ASSUME `ex (\ D : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))`
          )))
       ) (ASSUME `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`))
     ) (MP  
        (SPEC `(C : mat_Point)` 
         (SPEC `(B : mat_Point)` (SPEC `(A : mat_Point)` (lemma__8__2)))
        ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`))
    ))))
 ;;


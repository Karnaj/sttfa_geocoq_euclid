(*lemma__PGrectangle :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((pG A) C) D) B) ==> ((((per B) A) C) ==> ((((rE A) C) D) B))))))`*)
let lemma__PGrectangle =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((pG (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
     (DISCH `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
      (MP  
       (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
        (MP  
         (DISCH `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
          (MP  
           (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
            (MP  
             (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
              (MP  
               (DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                (MP  
                 (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                  (MP  
                   (DISCH `((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                    (MP  
                     (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                      (MP  
                       (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                        (MP  
                         (DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                          (MP  
                           (DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                            (MP  
                             (DISCH `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                              (MP  
                               (DISCH `((per (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                (MP  
                                 (DISCH `((per (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                  (MP  
                                   (DISCH `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                    (MP  
                                     (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                      (MP  
                                       (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (MP  
                                         (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                          (MP  
                                           (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                            (MP  
                                             (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                                  (SPEC `\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                    (ex__ind))))
                                                ) (GEN `(E : mat_Point)` 
                                                   (DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                       (SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                        (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                         (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                             (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                   (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                  (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((rT (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (x : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(p : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (x : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (x : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (x : mat_Point)) (t : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(q : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (x : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (x : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(r : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (x : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x : mat_Point)) (q : mat_Point)) (t : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(s : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(t : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (p : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (s : mat_Point)) (q : mat_Point)) (t : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (s : mat_Point)) (q : mat_Point)) (t : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (x : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (B : mat_Point))))) ==> ((((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(((cR (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> ((((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((rE (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cR (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (x : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__diagonalsmeet
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equaltorightisright
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(t : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    lemma__equaltorightisright
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((per (s : mat_Point)) (q : mat_Point)) (t : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(t : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (! F : mat_Point. ((((((supp (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (F : mat_Point)) ==> ((((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> (((per (D0 : mat_Point)) (B0 : mat_Point)) (F : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(t : mat_Point)` 
                                                                    (
                                                                    SPEC `(s : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (! F : mat_Point. ((((((supp (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (F : mat_Point)) ==> ((((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> (((per (D0 : mat_Point)) (B0 : mat_Point)) (F : mat_Point))))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (p : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    GEN `(F : mat_Point)` 
                                                                    (
                                                                    DISCH `((((supp (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D0 : mat_Point)) (B0 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (D0 : mat_Point)) (B0 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (F : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (F : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (D0 : mat_Point)) (B0 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (D0 : mat_Point)) (B0 : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    lemma__supplementofright
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((((supp (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__equaltorightisright
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((rT (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point))))))))))))))` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool))) ==> ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x4 : mat_Point. ((ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (x4 : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x4 : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))) ==> (ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (p : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x0 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x4 : mat_Point. ((ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x4 : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x4 : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (x4 : mat_Point)) (t : mat_Point)))))))))) ==> (ex (\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (x : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ q : mat_Point. (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (x : mat_Point)) (q : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (q : mat_Point)) (t : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x2 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x4 : mat_Point. ((ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x4 : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x4 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (x0 : mat_Point)) (t : mat_Point)))))))) ==> (ex (\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (x0 : mat_Point)) (t : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ r : mat_Point. (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (r : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (r : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (x0 : mat_Point)) (t : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x3 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x4 : mat_Point. ((ex (\ t : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x4 : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x4 : mat_Point)) (x0 : mat_Point)) (t : mat_Point)))))) ==> (ex (\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (x0 : mat_Point)) (t : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ s : mat_Point. (ex (\ t : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (s : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (s : mat_Point)) (x0 : mat_Point)) (t : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x1 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x4 : mat_Point. (((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x4 : mat_Point)))) ==> (ex (\ t : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (t : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ t : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (t : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (t : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (x3 : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x1 : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (x0 : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x0 : mat_Point)) (Z : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((rT (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! B0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G : mat_Point. (! H33 : mat_Point. (((((par (G : mat_Point)) (B0 : mat_Point)) (H33 : mat_Point)) (D0 : mat_Point)) ==> (((((oS (B0 : mat_Point)) (D0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) ==> ((((((rT (B0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (D0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    ASSUME `! B0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G : mat_Point. (! H33 : mat_Point. (((((par (G : mat_Point)) (B0 : mat_Point)) (H33 : mat_Point)) (D0 : mat_Point)) ==> (((((oS (B0 : mat_Point)) (D0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) ==> ((((((rT (B0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (D0 : mat_Point)))))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    GEN `(E0 : mat_Point)` 
                                                                    (
                                                                    GEN `(G : mat_Point)` 
                                                                    (
                                                                    GEN `(H33 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (B0 : mat_Point)) (H33 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (B0 : mat_Point)) (D0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((rT (B0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((rT (B0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E0 : mat_Point)) (G : mat_Point)) (B0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E0 : mat_Point)) (G : mat_Point)) (B0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (B0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((rT (B0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)) (D0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H33 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    proposition__29C
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (B0 : mat_Point)) (H33 : mat_Point)) (D0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (B0 : mat_Point)) (D0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E0 : mat_Point)) (G : mat_Point)) (H33 : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                     ))))
                                               ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                               ))
                                             ) (MP  
                                                (MP  
                                                 (SPEC `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                  (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                   (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                    (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                        (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                         (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                          (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                              (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                               (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                   (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                            ))))
                                                      ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                )))
                                           ) (MP  
                                              (MP  
                                               (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                 (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                      (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                       (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                        (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                            (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                             (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                              (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                  (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                ))))
                                                          ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                              )))
                                         ) (MP  
                                            (CONV_CONV_rule `((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                             (MP  
                                              (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                               (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                 (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                      (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                       (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                            (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                             (and__ind)))
                                                          ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                             (DISCH `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                 (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                  (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((((oS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                   )))))
                                            ) (ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                            )))
                                       ) (MP  
                                          (MP  
                                           (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                             (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                              (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                   (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                    (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                        (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                         (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                          (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                              (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                 (MP  
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__paralleldef2B
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                  ))))
                                                            ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                            ))))
                                                      ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                ))))
                                          ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                          )))
                                     ) (MP  
                                        (MP  
                                         (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                           (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                 (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                  (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                       (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                        (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                            (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                             (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                              (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `((((pG (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                 (MP  
                                                                  (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                   ))))
                                                                ) (ASSUME `(((pG (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                ))))
                                                          ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                              ))))
                                        ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                        )))
                                   ) (MP  
                                      (MP  
                                       (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                        (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                         (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                              (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                               (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                    (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                     (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                          (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                           (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                            (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(mat_and ((((par (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                  (SPEC `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                   (SPEC `(((par (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(((par (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and ((((par (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((par (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                 ) (ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                 )))))
                                                        ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                  ))))
                                            ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                            ))))
                                      ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                      )))
                                 ) (MP  
                                    (MP  
                                     (SPEC `((per (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                      (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                       (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((per (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                            (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                             (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                              (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((per (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                  (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                   (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                    (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((per (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                        (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                         (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                          (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                           (MP  
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(D : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (lemma__8__2))
                                                             )
                                                            ) (ASSUME `((per (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                            ))))
                                                      ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                ))))
                                          ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                          ))))
                                    ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                    )))
                               ) (MP  
                                  (MP  
                                   (SPEC `((per (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                    (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                     (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                      (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((per (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                          (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                           (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                            (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((per (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                 (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                  (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((per (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                        (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(D : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (SPEC `(B : mat_Point)` 
                                                                 (lemma__equaltorightisright
                                                                 ))))))
                                                           ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                           )
                                                          ) (ASSUME `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                              ))))
                                        ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                        ))))
                                  ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                  )))
                             ) (MP  
                                (MP  
                                 (SPEC `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                  (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                   (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                    (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                         (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                          (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                              (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                               (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                    (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                      (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                       (MP  
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (lemma__equalanglessymmetric
                                                              ))))))
                                                        ) (ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                            ))))
                                      ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                      ))))
                                ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                )))
                           ) (MP  
                              (MP  
                               (SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                 (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                  (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                       (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                        (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                            (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                             (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                              (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                    (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(C : mat_Point)` 
                                                        (SPEC `(D : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(C : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (lemma__equalanglestransitive
                                                                )))))))))
                                                       ) (ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                      ))))
                                                ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                ))))
                                          ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                          ))))
                                    ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                    ))))
                              ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                              )))
                         ) (MP  
                            (MP  
                             (SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                              (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                               (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                    (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                     (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                      (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                          (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                           (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                  (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                   (MP  
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (SPEC `(C : mat_Point)` 
                                                          (lemma__equalanglessymmetric
                                                          ))))))
                                                    ) (ASSUME `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                    ))))
                                              ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                        ))))
                                  ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                  ))))
                            ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                            )))
                       ) (MP  
                          (MP  
                           (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                            (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                             (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                              (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                  (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                   (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                    (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                        (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                         (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                              (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (lemma__inequalitysymmetric
                                                    ))
                                                  ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                  ))))
                                            ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                      ))))
                                ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                ))))
                          ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                          )))
                     ) (MP  
                        (MP  
                         (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                          (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                           (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                            (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                             (MP  
                              (MP  
                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                 (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                  (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                      (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                       (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                        (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                            (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                             (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                              (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                               (MP  
                                                (DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                    (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
                                                     (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                      (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                          (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
                                                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                            (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                 (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))`
                                                              ))))
                                                        ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
                                                  ))
                                                ) (MP  
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (SPEC `(C : mat_Point)` 
                                                      (lemma__NCdistinct)))
                                                   ) (ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                   )))))
                                          ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                    ))))
                              ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                              ))))
                        ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                        )))
                   ) (MP  
                      (MP  
                       (SPEC `((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                        (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                         (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                          (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                           (MP  
                            (MP  
                             (SPEC `((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                              (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                               (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                    (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                     (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                      (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                          (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                            (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (lemma__8__2)))
                                              ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                              ))))
                                        ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                        ))))
                                  ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                  ))))
                            ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                            ))))
                      ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                      )))
                 ) (MP  
                    (MP  
                     (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                      (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                       (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                        (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                         (MP  
                          (MP  
                           (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                            (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                             (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                              (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                               (MP  
                                (MP  
                                 (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                  (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                   (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                    (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                         (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                          (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (SPEC `(C : mat_Point)` 
                                               (lemma__ABCequalsCBA)))
                                            ) (ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                            ))))
                                      ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                ))))
                          ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                          ))))
                    ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                    )))
               ) (MP  
                  (MP  
                   (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                    (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                     (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                      (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                       (MP  
                        (MP  
                         (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                          (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                           (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                            (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                             (MP  
                              (MP  
                               (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                 (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                  (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                      (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                       (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                        (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                         (MP  
                                          (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                              (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                               (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                    (SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                     (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                      (DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                          (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                           (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                            (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                 (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                   (ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                   )))
                                                              ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                            ))
                                          ) (MP  
                                             (SPEC `(C : mat_Point)` 
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (lemma__NCorder)))
                                             ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                             )))))
                                    ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                    ))))
                              ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                              ))))
                        ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                        ))))
                  ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                  )))
             ) (MP  
                (MP  
                 (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                  (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                   (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                    (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                     (MP  
                      (MP  
                       (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                         (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                          (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                           (MP  
                            (MP  
                             (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                               (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                      (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                       (MP  
                                        (DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (SPEC `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                             (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                              (DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                   (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                    (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                         (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                          (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                               (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                 (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                 )))
                                                            ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                ))))
                                          ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                          ))
                                        ) (MP  
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (lemma__NCorder)))
                                           ) (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                           )))))
                                  ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                  ))))
                            ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                            ))))
                      ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                      ))))
                ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                )))
           ) (MP  
              (MP  
               (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                 (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (and__ind)))
               ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                   (MP  
                    (MP  
                     (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                      (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                       (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                        (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                            (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                             (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                              (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                               (MP  
                                (MP  
                                 (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                  (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                   (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                    (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                     (MP  
                                      (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                          (SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                           (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                (SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                 (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                  (DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                      (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                       (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                        (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                         (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                              ))))
                                        ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                        ))
                                      ) (MP  
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(D : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (SPEC `(A : mat_Point)` 
                                             (lemma__parallelNC))))
                                         ) (ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                         )))))
                                ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                          ))))
                    ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                    ))))
              ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
              )))
         ) (MP  
            (MP  
             (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
              (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
               (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (and__ind)))
             ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                 (MP  
                  (MP  
                   (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                    (SPEC `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                     (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                      (DISCH `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                       (MP  
                        (MP  
                         (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                          (SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                           (SPEC `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                            (DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                (SPEC `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                 (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                  (DISCH `(((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `((((pG (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> ((((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                     (MP  
                                      (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                       (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (SPEC `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                         (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (ASSUME `(((par (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                          ))))
                                    ) (ASSUME `(((pG (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                    ))))
                              ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                              ))))
                        ) (ASSUME `(mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                        ))))
                  ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                  ))))
            ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((((cong__3 (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
            )))
       ) (MP  
          (SPEC `(D : mat_Point)` 
           (SPEC `(C : mat_Point)` 
            (SPEC `(B : mat_Point)` 
             (SPEC `(A : mat_Point)` (proposition__34))))
          ) (ASSUME `(((pG (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
          ))))))))
 ;;


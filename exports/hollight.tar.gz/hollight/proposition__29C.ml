(*proposition__29C :  |- `! B : mat_Point. (! D : mat_Point. (! E : mat_Point. (! G : mat_Point. (! H : mat_Point. (((((par G) B) H) D) ==> (((((oS B) D) G) H) ==> ((((betS E) G) H) ==> ((mat_and ((((((congA E) G) B) G) H) D)) ((((((rT B) G) H) G) H) D)))))))))`*)
let proposition__29C =

 GEN `(B : mat_Point)` 
 (GEN `(D : mat_Point)` 
  (GEN `(E : mat_Point)` 
   (GEN `(G : mat_Point)` 
    (GEN `(H : mat_Point)` 
     (DISCH `(((par (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
      (DISCH `(((oS (B : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
       (DISCH `((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
        (MP  
         (DISCH `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
          (MP  
           (CONV_CONV_rule `(((eq (G : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
            (DISCH `mat_not ((eq (G : mat_Point)) (B : mat_Point))` 
             (MP  
              (DISCH `(neq (B : mat_Point)) (G : mat_Point)` 
               (MP  
                (DISCH `ex (\ A : mat_Point. ((mat_and (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))))` 
                 (MP  
                  (MP  
                   (SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                    (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((((cong (G : mat_Point)) (x : mat_Point)) (B : mat_Point)) (G : mat_Point))) ==> (return : bool))) ==> ((ex (\ A : mat_Point. ((mat_and (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))))) ==> (return : bool)))` 
                     (SPEC `\ A : mat_Point. ((mat_and (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))` 
                      (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                   ) (GEN `(A : mat_Point)` 
                      (DISCH `(mat_and (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                       (MP  
                        (MP  
                         (SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                          (SPEC `(((cong (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                           (SPEC `((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                            (DISCH `(((cong (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                             (MP  
                              (DISCH `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                               (MP  
                                (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                 (MP  
                                  (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (G : mat_Point))) ((mat_or ((eq (B : mat_Point)) (G : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))))))) ==> ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                   (DISCH `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                    (MP  
                                     (DISCH `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                      (MP  
                                       (DISCH `(((par (H : mat_Point)) (D : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                        (MP  
                                         (DISCH `(((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                          (MP  
                                           (DISCH `(((par (H : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                            (MP  
                                             (DISCH `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                              (MP  
                                               (DISCH `(neq (G : mat_Point)) (A : mat_Point)` 
                                                (MP  
                                                 (DISCH `(((par (H : mat_Point)) (D : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                    (MP  
                                                     (DISCH `(((par (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                      (MP  
                                                       (CONV_CONV_rule `((((par (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                        (DISCH `ex (\ a : mat_Point. (ex (\ g : mat_Point. (ex (\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))))))))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ g : mat_Point. (ex (\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (x : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ a : mat_Point. (ex (\ g : mat_Point. (ex (\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                             (SPEC `\ a : mat_Point. (ex (\ g : mat_Point. (ex (\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))))))))))))))))` 
                                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                                               (ex__ind))))
                                                           ) (GEN `(a : mat_Point)` 
                                                              (DISCH `ex (\ g : mat_Point. (ex (\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((mat_and ((neq (a : mat_Point)) (x : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (x : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ g : mat_Point. (ex (\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                   (SPEC `\ g : mat_Point. (ex (\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                   ))
                                                                 ) (GEN `(g : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (x : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (x : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(h : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and ((neq (h : mat_Point)) (x : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (x : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(d : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (x : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (x : mat_Point)) (g : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (h : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (h : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ C : mat_Point. ((mat_and (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (D : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((((cong (H : mat_Point)) (x : mat_Point)) (D : mat_Point)) (H : mat_Point))) ==> (return : bool))) ==> ((ex (\ C : mat_Point. ((mat_and (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ C : mat_Point. ((mat_and (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (H : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (G : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (G : mat_Point)) (B : mat_Point))) ((mat_or (((betS (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point))))))) ==> ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (D : mat_Point)) (H : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (H : mat_Point)) (C : mat_Point))) ((mat_or (((betS (H : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (H : mat_Point))))))) ==> ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (G : mat_Point)) (G : mat_Point)) ==> ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `(eq (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or ((eq (G : mat_Point)) (G : mat_Point))) ((mat_or ((eq (H : mat_Point)) (G : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((betS (G : mat_Point)) (G : mat_Point)) (H : mat_Point))))))) ==> ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))))) ==> ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `(((tS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ==> mat_false) ==> ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) ==> (((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) ==> mat_false)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    ASSUME `((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) ==> mat_false`
                                                                    ) (
                                                                    ASSUME `(((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    ASSUME `((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) ==> (((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) ==> mat_false)`
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) (mat_not (((betS (H : mat_Point)) (G : mat_Point)) (B : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((mat_and (mat_not (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point)))) ((mat_and (mat_not (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__29
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__planeseparation
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (B : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (H : mat_Point)) (B : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (H : mat_Point)) (B : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (H : mat_Point)) (B : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (H : mat_Point)) (B : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (H : mat_Point)) (B : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (H : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (H : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (H : mat_Point)) (B : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (H : mat_Point)) (B : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (H : mat_Point)) (B : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (H : mat_Point)) (B : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (G : mat_Point))) ((mat_or ((eq (H : mat_Point)) (G : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((betS (G : mat_Point)) (G : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (G : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((betS (G : mat_Point)) (G : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (G : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((neq (a : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x : mat_Point)))))))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (a : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (a : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(h : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x : mat_Point)) (X : mat_Point)) (g : mat_Point)))))))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (g : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (g : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and ((neq (h : mat_Point)) (x : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (X : mat_Point)) (x : mat_Point))) (((betS (h : mat_Point)) (X : mat_Point)) (g : mat_Point)))))))))))))) ==> (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (h : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (h : mat_Point)) (X : mat_Point)) (g : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (h : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (h : mat_Point)) (X : mat_Point)) (g : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (x : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (x : mat_Point)) (g : mat_Point)))))))))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (X : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (X : mat_Point)) (g : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (X : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (X : mat_Point)) (g : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (g : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (g : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (h : mat_Point)) (d : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (h : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (x : mat_Point))) (((col (H : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (X : mat_Point))) (((col (H : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (M : mat_Point))) (((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (M : mat_Point))) (((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (G : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and (((col (M : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (M : mat_Point)) (H : mat_Point))) (((col (M : mat_Point)) (H : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and (((col (M : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (M : mat_Point)) (H : mat_Point))) (((col (M : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and (((col (M : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (M : mat_Point)) (H : mat_Point))) (((col (M : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (M : mat_Point)) (H : mat_Point))) (((col (M : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (M : mat_Point)) (H : mat_Point))) (((col (M : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (M : mat_Point)) (H : mat_Point))) (((col (M : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (M : mat_Point)) (H : mat_Point))) (((col (M : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (M : mat_Point)) (H : mat_Point))) (((col (M : mat_Point)) (H : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (M : mat_Point)) (H : mat_Point))) (((col (M : mat_Point)) (H : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and (((col (M : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (M : mat_Point)) (H : mat_Point))) (((col (M : mat_Point)) (H : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (D : mat_Point)) (M : mat_Point))) ((mat_and (((col (H : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((mat_and (((col (M : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (M : mat_Point)) (H : mat_Point))) (((col (M : mat_Point)) (H : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (H : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (H : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (H : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (H : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (G : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (G : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (G : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (D : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((col (M : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (M : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (d : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (C : mat_Point)) (h : mat_Point)) (D : mat_Point))) ((mat_and (((col (h : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (h : mat_Point)) (C : mat_Point))) (((col (h : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (h : mat_Point)) (D : mat_Point))) ((mat_and (((col (h : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (h : mat_Point)) (C : mat_Point))) (((col (h : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (h : mat_Point)) (D : mat_Point))) ((mat_and (((col (h : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (h : mat_Point)) (C : mat_Point))) (((col (h : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (h : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (h : mat_Point)) (C : mat_Point))) (((col (h : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (h : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (h : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (h : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (h : mat_Point)) (C : mat_Point))) (((col (h : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (h : mat_Point)) (C : mat_Point))) (((col (h : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (h : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (h : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (h : mat_Point)) (C : mat_Point))) (((col (h : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (h : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (h : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (h : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (h : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (h : mat_Point)) (C : mat_Point))) (((col (h : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (h : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (h : mat_Point)) (C : mat_Point))) (((col (h : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (h : mat_Point)) (D : mat_Point))) ((mat_and (((col (h : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (h : mat_Point)) (C : mat_Point))) (((col (h : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (C : mat_Point)) (h : mat_Point)) (D : mat_Point))) ((mat_and (((col (h : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (h : mat_Point)) (C : mat_Point))) (((col (h : mat_Point)) (C : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(h : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (h : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (C : mat_Point)) (h : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (C : mat_Point)) (h : mat_Point))` 
                                                                    (
                                                                    SPEC `(h : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(h : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (h : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(h : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (H : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (H : mat_Point)) (C : mat_Point))) ((mat_or (((betS (H : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (C : mat_Point))) ((mat_or (((betS (H : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (H : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (g : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (g : mat_Point))` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (g : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (A : mat_Point)) (g : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (g : mat_Point))) ((mat_and (((col (G : mat_Point)) (g : mat_Point)) (A : mat_Point))) ((mat_and (((col (g : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (g : mat_Point)) (G : mat_Point))) (((col (g : mat_Point)) (G : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (g : mat_Point)) (A : mat_Point))) ((mat_and (((col (g : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (g : mat_Point)) (G : mat_Point))) (((col (g : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (g : mat_Point)) (A : mat_Point))) ((mat_and (((col (g : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (g : mat_Point)) (G : mat_Point))) (((col (g : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (g : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (g : mat_Point)) (G : mat_Point))) (((col (g : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (g : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (g : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (g : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (g : mat_Point)) (G : mat_Point))) (((col (g : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (g : mat_Point)) (G : mat_Point))) (((col (g : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (g : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (g : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (g : mat_Point)) (G : mat_Point))) (((col (g : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (g : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (g : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (g : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (g : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (A : mat_Point)) (g : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (g : mat_Point)) (G : mat_Point))) (((col (g : mat_Point)) (G : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (g : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (g : mat_Point)) (G : mat_Point))) (((col (g : mat_Point)) (G : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (g : mat_Point)) (A : mat_Point))) ((mat_and (((col (g : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (g : mat_Point)) (G : mat_Point))) (((col (g : mat_Point)) (G : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (g : mat_Point))) ((mat_and (((col (G : mat_Point)) (g : mat_Point)) (A : mat_Point))) ((mat_and (((col (g : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (g : mat_Point)) (G : mat_Point))) (((col (g : mat_Point)) (G : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (G : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (G : mat_Point))) (((col (a : mat_Point)) (G : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (G : mat_Point))) (((col (a : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (G : mat_Point))) (((col (a : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (G : mat_Point))) (((col (a : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (G : mat_Point))) (((col (a : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (G : mat_Point))) (((col (a : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (G : mat_Point))) (((col (a : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (a : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (a : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (G : mat_Point))) (((col (a : mat_Point)) (G : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (G : mat_Point))) (((col (a : mat_Point)) (G : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (G : mat_Point))) (((col (a : mat_Point)) (G : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (G : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (G : mat_Point))) (((col (a : mat_Point)) (G : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (G : mat_Point)) (B : mat_Point))) ((mat_or (((betS (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (B : mat_Point))) ((mat_or (((betS (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (E : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((neq (H : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((neq (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((neq (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((neq (H : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (E : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((neq (H : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (H : mat_Point)) (G : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ C : mat_Point. ((mat_and (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                ) (ASSUME `ex (\ g : mat_Point. (ex (\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))))))`
                                                                ))))
                                                          ) (ASSUME `ex (\ a : mat_Point. (ex (\ g : mat_Point. (ex (\ h : mat_Point. (ex (\ d : mat_Point. (ex (\ m : mat_Point. ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (g : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (h : mat_Point))) ((mat_and (((col (H : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (h : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (d : mat_Point))) (((betS (h : mat_Point)) (m : mat_Point)) (g : mat_Point)))))))))))))))))))))`
                                                          )))
                                                       ) (ASSUME `(((par (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                       ))
                                                     ) (MP  
                                                        (SPEC `(G : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (SPEC `(D : mat_Point)` 
                                                           (SPEC `(H : mat_Point)` 
                                                            (lemma__parallelsymmetric
                                                            ))))
                                                        ) (ASSUME `(((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                        )))
                                                   ) (MP  
                                                      (DISCH `(mat_and ((((par (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and ((((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((((par (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (G : mat_Point)))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                          (SPEC `(mat_and ((((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((((par (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (G : mat_Point))` 
                                                           (SPEC `(((par (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(((par (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                            (DISCH `(mat_and ((((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((((par (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (G : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                (SPEC `(((par (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                 (SPEC `(((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                  (DISCH `(((par (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                   (ASSUME `(((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                   )))
                                                              ) (ASSUME `(mat_and ((((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((((par (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (G : mat_Point))`
                                                              ))))
                                                        ) (ASSUME `(mat_and ((((par (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and ((((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((((par (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (G : mat_Point)))`
                                                        ))
                                                      ) (MP  
                                                         (SPEC `(A : mat_Point)` 
                                                          (SPEC `(G : mat_Point)` 
                                                           (SPEC `(D : mat_Point)` 
                                                            (SPEC `(H : mat_Point)` 
                                                             (lemma__parallelflip
                                                             ))))
                                                         ) (ASSUME `(((par (H : mat_Point)) (D : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                         ))))
                                                 ) (MP  
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(A : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(G : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(H : mat_Point)` 
                                                           (lemma__collinearparallel
                                                           )))))
                                                      ) (ASSUME `(((par (H : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                      )
                                                     ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                     )
                                                    ) (ASSUME `(neq (G : mat_Point)) (A : mat_Point)`
                                                    )))
                                               ) (MP  
                                                  (DISCH `(mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(neq (G : mat_Point)) (A : mat_Point)` 
                                                      (SPEC `(mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                                                       (SPEC `(neq (G : mat_Point)) (A : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(neq (G : mat_Point)) (A : mat_Point)` 
                                                        (DISCH `(mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(neq (G : mat_Point)) (A : mat_Point)` 
                                                            (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                             (SPEC `(neq (B : mat_Point)) (G : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(neq (B : mat_Point)) (G : mat_Point)` 
                                                              (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                               (ASSUME `(neq (G : mat_Point)) (A : mat_Point)`
                                                               )))
                                                          ) (ASSUME `(mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (G : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))`
                                                    ))
                                                  ) (MP  
                                                     (SPEC `(A : mat_Point)` 
                                                      (SPEC `(G : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (lemma__betweennotequal
                                                        )))
                                                     ) (ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                     ))))
                                             ) (MP  
                                                (DISCH `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                    (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))))` 
                                                     (SPEC `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                      (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                          (SPEC `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))` 
                                                           (SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                            (DISCH `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                (SPEC `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                 (SPEC `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))))`
                                                  ))
                                                ) (MP  
                                                   (SPEC `(A : mat_Point)` 
                                                    (SPEC `(B : mat_Point)` 
                                                     (SPEC `(G : mat_Point)` 
                                                      (lemma__collinearorder)
                                                     ))
                                                   ) (ASSUME `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                   ))))
                                           ) (MP  
                                              (DISCH `(mat_and ((((par (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((par (H : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (H : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(((par (H : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                  (SPEC `(mat_and ((((par (H : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (H : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                   (SPEC `(((par (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(((par (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                    (DISCH `(mat_and ((((par (H : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (H : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(((par (H : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                        (SPEC `(((par (D : mat_Point)) (H : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                         (SPEC `(((par (H : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(((par (H : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                          (DISCH `(((par (D : mat_Point)) (H : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                           (ASSUME `(((par (H : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                           )))
                                                      ) (ASSUME `(mat_and ((((par (H : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (H : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((((par (D : mat_Point)) (H : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((par (H : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (H : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                ))
                                              ) (MP  
                                                 (SPEC `(B : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (SPEC `(D : mat_Point)` 
                                                    (SPEC `(H : mat_Point)` 
                                                     (lemma__parallelflip))))
                                                 ) (ASSUME `(((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                 ))))
                                         ) (MP  
                                            (MP  
                                             (MP  
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(G : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (SPEC `(D : mat_Point)` 
                                                  (SPEC `(H : mat_Point)` 
                                                   (lemma__collinearparallel)
                                                  ))))
                                              ) (ASSUME `(((par (H : mat_Point)) (D : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                              )
                                             ) (ASSUME `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                             )
                                            ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                            )))
                                       ) (MP  
                                          (SPEC `(D : mat_Point)` 
                                           (SPEC `(H : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(G : mat_Point)` 
                                              (lemma__parallelsymmetric))))
                                          ) (ASSUME `(((par (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                          )))
                                     ) (MP  
                                        (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                            (SPEC `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                             (SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                              (DISCH `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                  (SPEC `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                   (SPEC `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                    (DISCH `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                        (SPEC `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                         (SPEC `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                          (DISCH `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                              (SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                               (SPEC `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                (DISCH `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                 (ASSUME `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                 )))
                                                            ) (ASSUME `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                ))))
                                          ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                          ))
                                        ) (MP  
                                           (SPEC `(G : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (lemma__collinearorder)))
                                           ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                           )))))
                                  ) (MP  
                                     (SPEC `(mat_or ((eq (A : mat_Point)) (G : mat_Point))) ((mat_or ((eq (B : mat_Point)) (G : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)))))` 
                                      (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                       (or__intror))
                                     ) (MP  
                                        (SPEC `(mat_or ((eq (B : mat_Point)) (G : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                         (SPEC `(eq (A : mat_Point)) (G : mat_Point)` 
                                          (or__intror))
                                        ) (MP  
                                           (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                            (SPEC `(eq (B : mat_Point)) (G : mat_Point)` 
                                             (or__intror))
                                           ) (MP  
                                              (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                               (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                (or__intror))
                                              ) (MP  
                                                 (SPEC `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                  (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                   (or__intror))
                                                 ) (ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                 )))))))
                                ) (MP  
                                   (DISCH `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                       (SPEC `(mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                        (SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(neq (G : mat_Point)) (B : mat_Point)` 
                                         (DISCH `(mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                              (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(neq (A : mat_Point)) (G : mat_Point)` 
                                               (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                )))
                                           ) (ASSUME `(mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                           ))))
                                     ) (ASSUME `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                     ))
                                   ) (MP  
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(G : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (lemma__betweennotequal)))
                                      ) (ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                      ))))
                              ) (MP  
                                 (SPEC `(A : mat_Point)` 
                                  (SPEC `(G : mat_Point)` 
                                   (SPEC `(B : mat_Point)` 
                                    (axiom__betweennesssymmetry)))
                                 ) (ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                 )))))
                        ) (ASSUME `(mat_and (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))`
                        ))))
                  ) (ASSUME `ex (\ A : mat_Point. ((mat_and (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point))))`
                  ))
                ) (MP  
                   (MP  
                    (SPEC `(G : mat_Point)` 
                     (SPEC `(B : mat_Point)` 
                      (SPEC `(G : mat_Point)` 
                       (SPEC `(B : mat_Point)` (lemma__extension))))
                    ) (ASSUME `(neq (B : mat_Point)) (G : mat_Point)`)
                   ) (ASSUME `(neq (B : mat_Point)) (G : mat_Point)`)))
              ) (MP  
                 (CONV_CONV_rule `(mat_not ((eq (G : mat_Point)) (B : mat_Point))) ==> ((neq (B : mat_Point)) (G : mat_Point))` 
                  (SPEC `(B : mat_Point)` 
                   (SPEC `(G : mat_Point)` (lemma__inequalitysymmetric)))
                 ) (ASSUME `mat_not ((eq (G : mat_Point)) (B : mat_Point))`))
             ))
           ) (DISCH `(eq (G : mat_Point)) (B : mat_Point)` 
              (MP  
               (CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (B : mat_Point))) ((mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or ((eq (B : mat_Point)) (H : mat_Point))) ((mat_or (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_or (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point))) (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                (DISCH `((col (G : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                 (MP  
                  (MP  
                   (SPEC `(H : mat_Point)` 
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(G : mat_Point)` (col__nCol__False)))
                   ) (ASSUME `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                   )
                  ) (ASSUME `((col (G : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                  )))
               ) (MP  
                  (SPEC `(mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or ((eq (B : mat_Point)) (H : mat_Point))) ((mat_or (((betS (B : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_or (((betS (G : mat_Point)) (B : mat_Point)) (H : mat_Point))) (((betS (G : mat_Point)) (H : mat_Point)) (B : mat_Point)))))` 
                   (SPEC `(eq (G : mat_Point)) (B : mat_Point)` (or__introl))
                  ) (ASSUME `(eq (G : mat_Point)) (B : mat_Point)`)))))
         ) (MP  
            (DISCH `(mat_and (((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (D : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
             (MP  
              (MP  
               (SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                (SPEC `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (D : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                 (SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                  (and__ind)))
               ) (DISCH `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                  (DISCH `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (D : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                   (MP  
                    (MP  
                     (SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                      (SPEC `(mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (D : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                       (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                        (DISCH `(mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (D : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                         (MP  
                          (MP  
                           (SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)` 
                            (SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                             (SPEC `((nCol (B : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((nCol (B : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                              (DISCH `((nCol (G : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                               (ASSUME `((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point)`
                               )))
                          ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (D : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                          ))))
                    ) (ASSUME `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (D : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                    ))))
              ) (ASSUME `(mat_and (((nCol (G : mat_Point)) (B : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (H : mat_Point)) (D : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
              ))
            ) (MP  
               (SPEC `(D : mat_Point)` 
                (SPEC `(H : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(G : mat_Point)` (lemma__parallelNC))))
               ) (ASSUME `(((par (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (D : mat_Point)`
               )))))))))))
 ;;


(*lemma__samenotopposite :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((oS A) B) C) D) ==> (mat_not ((((tS A) C) D) B))))))`*)
let lemma__samenotopposite =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (DISCH `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
       (MP  
        (CONV_CONV_rule `(((((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (mat_not ((((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
         (DISCH `mat_not ((((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
          (ASSUME `mat_not ((((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
          ))
        ) (DISCH `(((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
           (MP  
            (DISCH `(((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
             (MP  
              (DISCH `ex (\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
               (MP  
                (MP  
                 (SPEC `mat_false` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((((betS (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (return : bool))) ==> ((ex (\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point)))) ==> (return : bool)))` 
                   (SPEC `\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(M : mat_Point)` 
                    (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                     (MP  
                      (DISCH `mat_not (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                       (MP  
                        (CONV_CONV_rule `(((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> mat_false` 
                         (ASSUME `mat_not (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                         )
                        ) (ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                        ))
                      ) (SPEC `(M : mat_Point)` 
                         (SPEC `(B : mat_Point)` (axiom__betweennessidentity)
                         )))))
                ) (ASSUME `ex (\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                ))
              ) (MP  
                 (CONV_CONV_rule `((((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (ex (\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                  (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                   (MP  
                    (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                     (MP  
                      (MP  
                       (SPEC `ex (\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                        (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))) ==> (return : bool)))` 
                         (SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                          (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                       ) (GEN `(x : mat_Point)` 
                          (DISCH `(mat_and (((betS (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                           (MP  
                            (MP  
                             (SPEC `ex (\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                              (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                               (SPEC `((betS (B : mat_Point)) (x : mat_Point)) (B : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((betS (B : mat_Point)) (x : mat_Point)) (B : mat_Point)` 
                                (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                 (MP  
                                  (MP  
                                   (SPEC `ex (\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                    (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                     (SPEC `((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                      (DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                       (MP  
                                        (CONV_CONV_rule `((((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (ex (\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                         (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                          (MP  
                                           (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `ex (\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                               (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. (((mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))) ==> (return : bool)))` 
                                                (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                  (ex__ind))))
                                              ) (GEN `(x0 : mat_Point)` 
                                                 (DISCH `(mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `ex (\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                     (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                      (SPEC `((betS (A : mat_Point)) (x0 : mat_Point)) (B : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((betS (A : mat_Point)) (x0 : mat_Point)) (B : mat_Point)` 
                                                       (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `ex (\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                           (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                            (SPEC `((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                             (DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                              (MP  
                                                               (SPEC `(x : mat_Point)` 
                                                                (CONV_CONV_rule `! x1 : mat_Point. ((((betS (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point)) ==> (ex (\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                                                 (SPEC `\ M : mat_Point. (((betS (B : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (ex__intro
                                                                   ))))
                                                               ) (ASSUME `((betS (B : mat_Point)) (x : mat_Point)) (B : mat_Point)`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((betS (A : mat_Point)) (x0 : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                   ))))
                                             ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                             ))
                                           ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                           )))
                                        ) (ASSUME `(((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                        ))))
                                  ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                  ))))
                            ) (ASSUME `(mat_and (((betS (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                            ))))
                      ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))`
                      ))
                    ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))`
                    )))
                 ) (ASSUME `(((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                 )))
            ) (MP  
               (MP  
                (SPEC `(B : mat_Point)` 
                 (SPEC `(A : mat_Point)` 
                  (SPEC `(B : mat_Point)` 
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(C : mat_Point)` (lemma__planeseparation)))))
                ) (ASSUME `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                )
               ) (ASSUME `(((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
               )))))
      ) (MP  
         (DISCH `(mat_and ((((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
          (MP  
           (MP  
            (SPEC `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
             (SPEC `(mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
              (SPEC `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
               (and__ind)))
            ) (DISCH `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
               (DISCH `(mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                (MP  
                 (MP  
                  (SPEC `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                   (SPEC `(((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                    (SPEC `(((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `(((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                     (DISCH `(((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                      (ASSUME `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                      )))
                 ) (ASSUME `(mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                 ))))
           ) (ASSUME `(mat_and ((((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
           ))
         ) (MP  
            (SPEC `(B : mat_Point)` 
             (SPEC `(A : mat_Point)` 
              (SPEC `(D : mat_Point)` 
               (SPEC `(C : mat_Point)` (lemma__samesidesymmetric))))
            ) (ASSUME `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
            ))))))))
 ;;


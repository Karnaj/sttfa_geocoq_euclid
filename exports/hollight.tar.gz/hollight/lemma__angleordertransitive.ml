(*lemma__angleordertransitive :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! R : mat_Point. (((((((ltA A) B) C) D) E) F) ==> (((((((ltA D) E) F) P) Q) R) ==> ((((((ltA A) B) C) P) Q) R)))))))))))`*)
let lemma__angleordertransitive =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(P : mat_Point)` 
       (GEN `(Q : mat_Point)` 
        (GEN `(R : mat_Point)` 
         (DISCH `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
          (DISCH `(((((ltA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
           (MP  
            (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
             (MP  
              (MP  
               (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (x : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))) ==> (return : bool)))` 
                 (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)))))))))` 
                  (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
               ) (GEN `(U : mat_Point)` 
                  (DISCH `ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))` 
                   (MP  
                    (MP  
                     (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))) ==> (return : bool)))` 
                       (SPEC `\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)))))))` 
                        (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                     ) (GEN `(V : mat_Point)` 
                        (DISCH `ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))` 
                         (MP  
                          (MP  
                           (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (U : mat_Point)) (x : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))) ==> (return : bool)))` 
                             (SPEC `\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)))))` 
                              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                           ) (GEN `(W : mat_Point)` 
                              (DISCH `(mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                  (SPEC `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)))` 
                                   (SPEC `((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point)` 
                                    (DISCH `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                        (SPEC `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                         (SPEC `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)` 
                                          (DISCH `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                              (SPEC `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                               (SPEC `((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)` 
                                                (DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((((congA (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(neq (Q : mat_Point)) (U : mat_Point)` 
                                                           (MP  
                                                            (DISCH `ex (\ G : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (U : mat_Point))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (U : mat_Point))))) ==> (return : bool)))` 
                                                                 (SPEC `\ G : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (U : mat_Point)))` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (ex__ind))
                                                                 ))
                                                               ) (GEN `(G : mat_Point)` 
                                                                  (DISCH `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (U : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ J : mat_Point. ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((cong (E : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (W : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (Q : mat_Point)) (W : mat_Point))) ==> (return : bool))) ==> ((ex (\ J : mat_Point. ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((cong (E : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (W : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ J : mat_Point. ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((cong (E : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (W : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((cong (E : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (E : mat_Point)) (J : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (E : mat_Point)) (J : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (W : mat_Point)) (W : mat_Point)) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (Q : mat_Point)) (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (E : mat_Point)) (J : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (G : mat_Point)) (E : mat_Point)) (J : mat_Point)) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (G : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (J : mat_Point)) (U : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ H43 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H43 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H43 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (x : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ H44 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ H44 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(H44 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ T : mat_Point. ((mat_and (((betS (x : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(S : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (x : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))))) ==> (return : bool))) ==> ((ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (Q : mat_Point)) (U : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (H44 : mat_Point)) (H44 : mat_Point)) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (H44 : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (Q : mat_Point)) (H44 : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (Q : mat_Point)) (T : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (S : mat_Point)) (Q : mat_Point)) (T : mat_Point)) ==> mat_false) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (S : mat_Point)) (Q : mat_Point)) (T : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (S : mat_Point)) (Q : mat_Point)) (T : mat_Point)) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (S : mat_Point)) (Q : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (Q : mat_Point)) (S : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ K : mat_Point. ((mat_and (((out (Q : mat_Point)) (H44 : mat_Point)) (K : mat_Point))) (((betS (U : mat_Point)) (K : mat_Point)) (W : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (Q : mat_Point)) (H44 : mat_Point)) (x : mat_Point))) (((betS (U : mat_Point)) (x : mat_Point)) (W : mat_Point))) ==> (return : bool))) ==> ((ex (\ K : mat_Point. ((mat_and (((out (Q : mat_Point)) (H44 : mat_Point)) (K : mat_Point))) (((betS (U : mat_Point)) (K : mat_Point)) (W : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ K : mat_Point. ((mat_and (((out (Q : mat_Point)) (H44 : mat_Point)) (K : mat_Point))) (((betS (U : mat_Point)) (K : mat_Point)) (W : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (Q : mat_Point)) (H44 : mat_Point)) (K : mat_Point))) (((betS (U : mat_Point)) (K : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (U : mat_Point)) (K : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (H44 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (H44 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (U : mat_Point)) (K : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (U : mat_Point)) (K : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (P : mat_Point)) (P : mat_Point)) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))) ==> ((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))) ==> (ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V0 : mat_Point. ((mat_and (((betS (U : mat_Point)) (x : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (U : mat_Point)) (K : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (K : mat_Point))))) ==> (ex (\ V0 : mat_Point. ((mat_and (((betS (U : mat_Point)) (K : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (K : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. ((mat_and (((betS (U : mat_Point)) (K : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (U : mat_Point)) (K : mat_Point)) (V : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (K : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (K : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (H44 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (H44 : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (P : mat_Point)) (P : mat_Point))) (((betS (Q : mat_Point)) (P : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (P : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__3__6b
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (K : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (H44 : mat_Point)) (K : mat_Point))) (((betS (U : mat_Point)) (K : mat_Point)) (W : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ K : mat_Point. ((mat_and (((out (Q : mat_Point)) (H44 : mat_Point)) (K : mat_Point))) (((betS (U : mat_Point)) (K : mat_Point)) (W : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__crossbar
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((triangle (S : mat_Point)) (Q : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (S : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (T : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (S : mat_Point)) (Q : mat_Point)) (T : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (S : mat_Point)) (Q : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (U : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (T : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)) ==> ((((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)) ==> mat_false)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (T : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (T : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (T : mat_Point))) (((col (P : mat_Point)) (T : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (T : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (T : mat_Point))) (((col (P : mat_Point)) (T : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (T : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (T : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (T : mat_Point))) (((col (P : mat_Point)) (T : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (T : mat_Point))) (((col (P : mat_Point)) (T : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (T : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (T : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (T : mat_Point))) (((col (P : mat_Point)) (T : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (T : mat_Point))) (((col (P : mat_Point)) (T : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (T : mat_Point))) (((col (P : mat_Point)) (T : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (T : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (T : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (T : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (T : mat_Point))) (((col (P : mat_Point)) (T : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (T : mat_Point))) (((col (P : mat_Point)) (T : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (T : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (T : mat_Point))) (((col (P : mat_Point)) (T : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (T : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (T : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (T : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (T : mat_Point))) (((col (P : mat_Point)) (T : mat_Point)) (Q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (T : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (Q : mat_Point)) (T : mat_Point)) (P : mat_Point)) ==> mat_false) ==> (((col (Q : mat_Point)) (T : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (Q : mat_Point)) (T : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (Q : mat_Point)) (T : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (Q : mat_Point)) (T : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (S : mat_Point)) (Q : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (S : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (S : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) (((col (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (S : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) (((col (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (S : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) (((col (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) (((col (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (S : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) (((col (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) (((col (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) (((col (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (S : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) (((col (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) (((col (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (S : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) (((col (P : mat_Point)) (S : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (S : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (S : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (S : mat_Point))) (((col (P : mat_Point)) (S : mat_Point)) (Q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)) ==> mat_false) ==> (((col (Q : mat_Point)) (S : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (Q : mat_Point)) (S : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (U : mat_Point)) (Q : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (U : mat_Point)) (Q : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (U : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (P : mat_Point)) (U : mat_Point)) (Q : mat_Point))) ((mat_and (((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (U : mat_Point)) (P : mat_Point))) (((col (U : mat_Point)) (P : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (U : mat_Point)) (Q : mat_Point))) ((mat_and (((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (U : mat_Point)) (P : mat_Point))) (((col (U : mat_Point)) (P : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (U : mat_Point)) (Q : mat_Point))) ((mat_and (((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (U : mat_Point)) (P : mat_Point))) (((col (U : mat_Point)) (P : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (U : mat_Point)) (P : mat_Point))) (((col (U : mat_Point)) (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (U : mat_Point)) (P : mat_Point))) (((col (U : mat_Point)) (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (U : mat_Point)) (P : mat_Point))) (((col (U : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (U : mat_Point)) (P : mat_Point))) (((col (U : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (U : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (U : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (U : mat_Point)) (P : mat_Point))) (((col (U : mat_Point)) (P : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (U : mat_Point)) (P : mat_Point))) (((col (U : mat_Point)) (P : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (U : mat_Point)) (Q : mat_Point))) ((mat_and (((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (U : mat_Point)) (P : mat_Point))) (((col (U : mat_Point)) (P : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (P : mat_Point)) (U : mat_Point)) (Q : mat_Point))) ((mat_and (((col (U : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (U : mat_Point)) (P : mat_Point))) (((col (U : mat_Point)) (P : mat_Point)) (Q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and (((col (U : mat_Point)) (S : mat_Point)) (Q : mat_Point))) ((mat_and (((col (S : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (S : mat_Point)) (U : mat_Point))) (((col (S : mat_Point)) (U : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (U : mat_Point)) (S : mat_Point)) (Q : mat_Point))) ((mat_and (((col (S : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (S : mat_Point)) (U : mat_Point))) (((col (S : mat_Point)) (U : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (S : mat_Point)) (Q : mat_Point))) ((mat_and (((col (S : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (S : mat_Point)) (U : mat_Point))) (((col (S : mat_Point)) (U : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (S : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (S : mat_Point)) (U : mat_Point))) (((col (S : mat_Point)) (U : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (S : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (S : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (S : mat_Point)) (U : mat_Point))) (((col (S : mat_Point)) (U : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (S : mat_Point)) (U : mat_Point))) (((col (S : mat_Point)) (U : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (S : mat_Point)) (Q : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (S : mat_Point)) (U : mat_Point))) (((col (S : mat_Point)) (U : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (Q : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (S : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (S : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (S : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (S : mat_Point)) (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (U : mat_Point)) (Q : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (S : mat_Point)) (U : mat_Point))) (((col (S : mat_Point)) (U : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (S : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (S : mat_Point)) (U : mat_Point))) (((col (S : mat_Point)) (U : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (S : mat_Point)) (Q : mat_Point))) ((mat_and (((col (S : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (S : mat_Point)) (U : mat_Point))) (((col (S : mat_Point)) (U : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (Q : mat_Point)) (S : mat_Point))) ((mat_and (((col (U : mat_Point)) (S : mat_Point)) (Q : mat_Point))) ((mat_and (((col (S : mat_Point)) (Q : mat_Point)) (U : mat_Point))) ((mat_and (((col (Q : mat_Point)) (S : mat_Point)) (U : mat_Point))) (((col (S : mat_Point)) (U : mat_Point)) (Q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (U : mat_Point)) (S : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__ray2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (T : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(T : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (U : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (U : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (H44 : mat_Point)) (H44 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H44 : mat_Point)) (H44 : mat_Point))) (((betS (Q : mat_Point)) (H44 : mat_Point)) (H44 : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (H44 : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (H44 : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (H44 : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (H44 : mat_Point)) (H44 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (H44 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(H44 : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (U : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (U : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (U : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (U : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (U : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (U : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (U : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (U : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (U : mat_Point)) (H44 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (Q : mat_Point)) (H44 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (U : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (U : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (U : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (U : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (H44 : mat_Point))) ((neq (U : mat_Point)) (H44 : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H44 : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ H43 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H43 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H43 : mat_Point))))))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)) ==> (ex (\ H44 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point)))))))))))` 
                                                                    (
                                                                    DISCH `ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H44 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H44 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H44 : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (X : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H45 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H45 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H45 : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ V0 : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V0 : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H46 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H46 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H46 : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))) ==> (return : bool))) ==> ((ex (\ V0 : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H47 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H47 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H47 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H49 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H49 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H49 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H51 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H51 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H51 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((ltA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> (ex (\ H54 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H54 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H54 : mat_Point)))))))))))` 
                                                                    (
                                                                    DISCH `ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H54 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H54 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H54 : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H55 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H55 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H55 : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. ((ex (\ V0 : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V0 : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H56 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H56 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H56 : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. (((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x4 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point))))) ==> (return : bool))) ==> ((ex (\ V0 : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x4 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H57 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H57 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H57 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x4 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x4 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H59 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H59 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H59 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x4 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x4 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H61 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H61 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H61 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (Q : mat_Point)) (R : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (ex (\ H64 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H64 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H64 : mat_Point)))))))))))` 
                                                                    (
                                                                    DISCH `ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H64 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H64 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H64 : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x5 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x5 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H65 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H65 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H65 : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. ((ex (\ V0 : mat_Point. ((mat_and (((betS (x5 : mat_Point)) (x6 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x5 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x5 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V0 : mat_Point. ((mat_and (((betS (x5 : mat_Point)) (x6 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H66 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H66 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H66 : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. (((mat_and (((betS (x5 : mat_Point)) (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point))))) ==> (return : bool))) ==> ((ex (\ V0 : mat_Point. ((mat_and (((betS (x5 : mat_Point)) (x6 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. ((mat_and (((betS (x5 : mat_Point)) (x6 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x5 : mat_Point)) (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H67 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H67 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H67 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (x5 : mat_Point)) (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x5 : mat_Point)) (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H69 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H69 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H69 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ H71 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H71 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H71 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x0 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x8 : mat_Point. ((ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (x8 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x8 : mat_Point))))))))) ==> (ex (\ H73 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H73 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H73 : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ H73 : mat_Point. (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (H73 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (H73 : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x8 : mat_Point. ((ex (\ T : mat_Point. ((mat_and (((betS (x8 : mat_Point)) (x0 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))))) ==> (ex (\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (x0 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ S : mat_Point. (ex (\ T : mat_Point. ((mat_and (((betS (S : mat_Point)) (x0 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (S : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x1 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x8 : mat_Point. (((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x8 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (x8 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))) ==> (ex (\ T : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ T : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (T : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (T : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x5 : mat_Point)) (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V0 : mat_Point. ((mat_and (((betS (x5 : mat_Point)) (x6 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x6 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x5 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x4 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x4 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x4 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V0 : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x3 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V0 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((ltA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V0 : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U0 : mat_Point. (ex (\ X : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((betS (U0 : mat_Point)) (X : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (U : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (W : mat_Point)) (V0 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (W : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (W : mat_Point)) (W : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (E : mat_Point)) (J : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(a : mat_Point)` 
                                                                    (
                                                                    GEN `(b : mat_Point)` 
                                                                    (
                                                                    GEN `(c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((nCol (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (E : mat_Point)) (J : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (E : mat_Point)) (J : mat_Point)) (U : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (J : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (E : mat_Point)) (J : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (W : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (W : mat_Point)) (W : mat_Point))) (((betS (Q : mat_Point)) (W : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (W : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (W : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (E : mat_Point)) (J : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((cong (E : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (W : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ J : mat_Point. ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((((cong (E : mat_Point)) (J : mat_Point)) (Q : mat_Point)) (W : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (Q : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                              ) (ASSUME `ex (\ G : mat_Point. ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (Q : mat_Point)) (U : mat_Point))))`
                                                              ))
                                                            ) (MP  
                                                               (MP  
                                                                (SPEC `(U : mat_Point)` 
                                                                 (SPEC `(Q : mat_Point)` 
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                ) (ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                                                )
                                                               ) (ASSUME `(neq (Q : mat_Point)) (U : mat_Point)`
                                                               )))
                                                          ) (MP  
                                                             (SPEC `(U : mat_Point)` 
                                                              (SPEC `(P : mat_Point)` 
                                                               (SPEC `(Q : mat_Point)` 
                                                                (lemma__raystrict
                                                                )))
                                                             ) (ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point)`
                                                             )))
                                                        ) (MP  
                                                           (DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                               (SPEC `(mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                 (DISCH `(mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                             ))
                                                           ) (MP  
                                                              (SPEC `(F : mat_Point)` 
                                                               (SPEC `(E : mat_Point)` 
                                                                (SPEC `(D : mat_Point)` 
                                                                 (SPEC `(W : mat_Point)` 
                                                                  (SPEC `(Q : mat_Point)` 
                                                                   (SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__angledistinct
                                                                    ))))))
                                                              ) (ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                              ))))
                                                      ) (MP  
                                                         (SPEC `(E : mat_Point)` 
                                                          (SPEC `(D : mat_Point)` 
                                                           (lemma__inequalitysymmetric
                                                           ))
                                                         ) (ASSUME `(neq (D : mat_Point)) (E : mat_Point)`
                                                         )))
                                                    ) (MP  
                                                       (DISCH `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                           (SPEC `(mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                            (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                             (DISCH `(mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                 (SPEC `(mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                  (SPEC `(neq (Q : mat_Point)) (W : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(neq (Q : mat_Point)) (W : mat_Point)` 
                                                                   (DISCH `(mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (D : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point)))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((neq (P : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (W : mat_Point))) ((mat_and ((neq (P : mat_Point)) (W : mat_Point))) ((mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (F : mat_Point))))))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(F : mat_Point)` 
                                                           (SPEC `(E : mat_Point)` 
                                                            (SPEC `(D : mat_Point)` 
                                                             (SPEC `(W : mat_Point)` 
                                                              (SPEC `(Q : mat_Point)` 
                                                               (SPEC `(P : mat_Point)` 
                                                                (lemma__angledistinct
                                                                ))))))
                                                          ) (ASSUME `(((((congA (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                          ))))
                                                  ) (MP  
                                                     (SPEC `(W : mat_Point)` 
                                                      (SPEC `(Q : mat_Point)` 
                                                       (SPEC `(P : mat_Point)` 
                                                        (SPEC `(F : mat_Point)` 
                                                         (SPEC `(E : mat_Point)` 
                                                          (SPEC `(D : mat_Point)` 
                                                           (lemma__equalanglessymmetric
                                                           ))))))
                                                     ) (ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)`
                                                     )))))
                                            ) (ASSUME `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)))`
                                      ))))
                                ) (ASSUME `(mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))`
                                ))))
                          ) (ASSUME `ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))`
                          ))))
                    ) (ASSUME `ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))`
                    ))))
              ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))`
              ))
            ) (MP  
               (CONV_CONV_rule `((((((ltA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)))))))))))` 
                (DISCH `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))` 
                 (MP  
                  (DISCH `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))` 
                   (MP  
                    (MP  
                     (SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))) ==> (return : bool)))` 
                       (SPEC `\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point)))))))))` 
                        (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                     ) (GEN `(x : mat_Point)` 
                        (DISCH `ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))` 
                         (MP  
                          (MP  
                           (SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
                            (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))) ==> (return : bool)))` 
                             (SPEC `\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point)))))))` 
                              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                           ) (GEN `(x0 : mat_Point)` 
                              (DISCH `ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))))` 
                               (MP  
                                (MP  
                                 (SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
                                  (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))))) ==> (return : bool)))` 
                                   (SPEC `\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)))))` 
                                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)
                                    )))
                                 ) (GEN `(x1 : mat_Point)` 
                                    (DISCH `(mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
                                        (SPEC `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)))` 
                                         (SPEC `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                          (DISCH `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
                                              (SPEC `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))` 
                                               (SPEC `((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point)` 
                                                (DISCH `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
                                                    (SPEC `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)` 
                                                     (SPEC `((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point)` 
                                                      (DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)))))))))))` 
                                                         (DISCH `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))` 
                                                          (MP  
                                                           (DISCH `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
                                                               (CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))) ==> (return : bool)))` 
                                                                (SPEC `\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point)))))))))` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (ex__ind)))
                                                               )
                                                              ) (GEN `(x2 : mat_Point)` 
                                                                 (DISCH `ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. (((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x5 : mat_Point. ((ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (x5 : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x1 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x5 : mat_Point. ((ex (\ W : mat_Point. ((mat_and (((betS (x : mat_Point)) (W : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x5 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))) ==> (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (x : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and (((betS (x : mat_Point)) (W : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x0 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x5 : mat_Point. (((mat_and (((betS (x : mat_Point)) (x5 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x5 : mat_Point))))) ==> (ex (\ W : mat_Point. ((mat_and (((betS (x : mat_Point)) (W : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ W : mat_Point. ((mat_and (((betS (x : mat_Point)) (W : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (W : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x3 : mat_Point))))))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))`
                                                                   ))))
                                                             ) (ASSUME `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))`
                                                             ))
                                                           ) (ASSUME `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))`
                                                           )))
                                                        ) (ASSUME `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point)))`
                                            ))))
                                      ) (ASSUME `(mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (x1 : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))`
                                      ))))
                                ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (x0 : mat_Point))))))`
                                ))))
                          ) (ASSUME `ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))`
                          ))))
                    ) (ASSUME `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))`
                    ))
                  ) (ASSUME `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (Q : mat_Point)) (P : mat_Point)) (U : mat_Point))) ((mat_and (((out (Q : mat_Point)) (R : mat_Point)) (V : mat_Point))) ((((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (X : mat_Point))))))))))`
                  )))
               ) (ASSUME `(((((ltA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
               )))))))))))))
 ;;

